package com.carefirst.nexus.document.service;

import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import com.carefirst.enterprise.dms.documentmanagement.DocumentManagementPort;
import com.carefirst.enterprise.dms.documentmanagement.DocumentManagementServiceServiceagent;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest.Body;
import com.carefirst.enterprise.dms.getdocschema.GetDocResponse;

@RunWith(SpringRunner.class)
public class EDMSServiceTest {
	private static final Logger LOGGER = LogManager.getLogger(EDMSServiceTest.class);
	@Test
	public void testEDMSGetDocument() {

		try {
			QName qName = new QName("http://www.carefirst.com/Enterprise/DMS/DocumentManagement", "DocumentManagementService.serviceagent");
			URL wsdlurl = new URL("http://sita.gwservices.carefirst.com/dac/edms/v1?wsdl");
			DocumentManagementServiceServiceagent ds = new DocumentManagementServiceServiceagent(wsdlurl, qName);
			DocumentManagementPort documentManagementPort = ds.getDocumentManagementPortEndpoint();
			BindingProvider bp = (BindingProvider) documentManagementPort;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://sita.gwservices.carefirst.com/dac/edms/v1");
			bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, "aad7740");
			bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, "mIndia1234");
			GetDocRequest request = new GetDocRequest();
			Body body = new Body();
			body.setGuid("3091EF6F-0100-CF3E-87B8-A8E0A054E45B");
			request.setBody(body);
			GetDocResponse docResponse = documentManagementPort.getDocument(request);
			LOGGER.error("fileName >>>>>>>>>>>>>>>>>>>>>>>>>>> "+docResponse.getDocTitle());
			LOGGER.error("docResponse >>>>>>>>>>>>>>>>>>>>>>>>>>> "+docResponse.getDocData());
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Invalid service configuration");
			//			throw new ApplicationException("Invalid Config.Please contact the support team.", e, "INVALID_CONFIG");
		}
		
	}
}
