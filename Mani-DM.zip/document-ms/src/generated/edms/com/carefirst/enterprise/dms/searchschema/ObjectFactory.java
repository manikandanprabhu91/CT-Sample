
package com.carefirst.enterprise.dms.searchschema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.enterprise.dms.searchschema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SenderID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "senderID");
    private final static QName _SenderApp_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "senderApp");
    private final static QName _MsgVersion_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "msgVersion");
    private final static QName _MsgID_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "msgID");
    private final static QName _Success_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "success");
    private final static QName _MsgCode_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "msgCode");
    private final static QName _Msg_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "msg");
    private final static QName _Class_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "class");
    private final static QName _FromDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "fromDate");
    private final static QName _ToDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "toDate");
    private final static QName _VersionHistory_QNAME = new QName("http://www.carefirst.com/Enterprise/DMS/SearchSchema", "versionHistory");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.enterprise.dms.searchschema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SearchDocRequest }
     * 
     */
    public SearchDocRequest createSearchDocRequest() {
        return new SearchDocRequest();
    }

    /**
     * Create an instance of {@link Criteria }
     * 
     */
    public Criteria createCriteria() {
        return new Criteria();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link SearchDocRequest.Body }
     * 
     */
    public SearchDocRequest.Body createSearchDocRequestBody() {
        return new SearchDocRequest.Body();
    }

    /**
     * Create an instance of {@link SearchDocResponse }
     * 
     */
    public SearchDocResponse createSearchDocResponse() {
        return new SearchDocResponse();
    }

    /**
     * Create an instance of {@link DocList }
     * 
     */
    public DocList createDocList() {
        return new DocList();
    }

    /**
     * Create an instance of {@link DocProperty }
     * 
     */
    public DocProperty createDocProperty() {
        return new DocProperty();
    }

    /**
     * Create an instance of {@link Error }
     * 
     */
    public Error createError() {
        return new Error();
    }

    /**
     * Create an instance of {@link Classes }
     * 
     */
    public Classes createClasses() {
        return new Classes();
    }

    /**
     * Create an instance of {@link Criteria.Property }
     * 
     */
    public Criteria.Property createCriteriaProperty() {
        return new Criteria.Property();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "senderID")
    public JAXBElement<String> createSenderID(String value) {
        return new JAXBElement<String>(_SenderID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "senderApp")
    public JAXBElement<String> createSenderApp(String value) {
        return new JAXBElement<String>(_SenderApp_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "msgVersion")
    public JAXBElement<String> createMsgVersion(String value) {
        return new JAXBElement<String>(_MsgVersion_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "msgID")
    public JAXBElement<String> createMsgID(String value) {
        return new JAXBElement<String>(_MsgID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "success")
    public JAXBElement<Boolean> createSuccess(Boolean value) {
        return new JAXBElement<Boolean>(_Success_QNAME, Boolean.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "msgCode")
    public JAXBElement<String> createMsgCode(String value) {
        return new JAXBElement<String>(_MsgCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "msg")
    public JAXBElement<String> createMsg(String value) {
        return new JAXBElement<String>(_Msg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "class")
    public JAXBElement<String> createClass(String value) {
        return new JAXBElement<String>(_Class_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "fromDate")
    public JAXBElement<String> createFromDate(String value) {
        return new JAXBElement<String>(_FromDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link String }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "toDate")
    public JAXBElement<String> createToDate(String value) {
        return new JAXBElement<String>(_ToDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Boolean }{@code >}
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DMS/SearchSchema", name = "versionHistory")
    public JAXBElement<Boolean> createVersionHistory(Boolean value) {
        return new JAXBElement<Boolean>(_VersionHistory_QNAME, Boolean.class, null, value);
    }

}
