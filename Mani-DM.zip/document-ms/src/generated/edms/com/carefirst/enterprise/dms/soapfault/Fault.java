
package com.carefirst.enterprise.dms.soapfault;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="faultType" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="SystemUnavailableFault" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="SourceSystemInvalid" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DataNotFound" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="ApplicationException" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="SystemTimeOutException" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="PackageNotCompiled" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="AuthenticationException" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="InputDataInvalid" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                   &lt;element name="DefaultFault" minOccurs="0"&gt;
 *                     &lt;complexType&gt;
 *                       &lt;complexContent&gt;
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                           &lt;sequence&gt;
 *                             &lt;element name="faultCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                             &lt;element name="faultMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                           &lt;/sequence&gt;
 *                         &lt;/restriction&gt;
 *                       &lt;/complexContent&gt;
 *                     &lt;/complexType&gt;
 *                   &lt;/element&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "faultType"
})
@XmlRootElement(name = "fault")
public class Fault {

    protected Fault.FaultType faultType;

    /**
     * Gets the value of the faultType property.
     * 
     * @return
     *     possible object is
     *     {@link Fault.FaultType }
     *     
     */
    public Fault.FaultType getFaultType() {
        return faultType;
    }

    /**
     * Sets the value of the faultType property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fault.FaultType }
     *     
     */
    public void setFaultType(Fault.FaultType value) {
        this.faultType = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="SystemUnavailableFault" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="SourceSystemInvalid" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DataNotFound" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="ApplicationException" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="SystemTimeOutException" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="PackageNotCompiled" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="AuthenticationException" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="InputDataInvalid" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *         &lt;element name="DefaultFault" minOccurs="0"&gt;
     *           &lt;complexType&gt;
     *             &lt;complexContent&gt;
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *                 &lt;sequence&gt;
     *                   &lt;element name="faultCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                   &lt;element name="faultMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *                 &lt;/sequence&gt;
     *               &lt;/restriction&gt;
     *             &lt;/complexContent&gt;
     *           &lt;/complexType&gt;
     *         &lt;/element&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "systemUnavailableFault",
        "sourceSystemInvalid",
        "dataNotFound",
        "applicationException",
        "systemTimeOutException",
        "packageNotCompiled",
        "authenticationException",
        "inputDataInvalid",
        "defaultFault"
    })
    public static class FaultType {

        @XmlElement(name = "SystemUnavailableFault")
        protected Fault.FaultType.SystemUnavailableFault systemUnavailableFault;
        @XmlElement(name = "SourceSystemInvalid")
        protected Fault.FaultType.SourceSystemInvalid sourceSystemInvalid;
        @XmlElement(name = "DataNotFound")
        protected Fault.FaultType.DataNotFound dataNotFound;
        @XmlElement(name = "ApplicationException")
        protected Fault.FaultType.ApplicationException applicationException;
        @XmlElement(name = "SystemTimeOutException")
        protected Fault.FaultType.SystemTimeOutException systemTimeOutException;
        @XmlElement(name = "PackageNotCompiled")
        protected Fault.FaultType.PackageNotCompiled packageNotCompiled;
        @XmlElement(name = "AuthenticationException")
        protected Fault.FaultType.AuthenticationException authenticationException;
        @XmlElement(name = "InputDataInvalid")
        protected Fault.FaultType.InputDataInvalid inputDataInvalid;
        @XmlElement(name = "DefaultFault")
        protected Fault.FaultType.DefaultFault defaultFault;

        /**
         * Gets the value of the systemUnavailableFault property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.SystemUnavailableFault }
         *     
         */
        public Fault.FaultType.SystemUnavailableFault getSystemUnavailableFault() {
            return systemUnavailableFault;
        }

        /**
         * Sets the value of the systemUnavailableFault property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.SystemUnavailableFault }
         *     
         */
        public void setSystemUnavailableFault(Fault.FaultType.SystemUnavailableFault value) {
            this.systemUnavailableFault = value;
        }

        /**
         * Gets the value of the sourceSystemInvalid property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.SourceSystemInvalid }
         *     
         */
        public Fault.FaultType.SourceSystemInvalid getSourceSystemInvalid() {
            return sourceSystemInvalid;
        }

        /**
         * Sets the value of the sourceSystemInvalid property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.SourceSystemInvalid }
         *     
         */
        public void setSourceSystemInvalid(Fault.FaultType.SourceSystemInvalid value) {
            this.sourceSystemInvalid = value;
        }

        /**
         * Gets the value of the dataNotFound property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.DataNotFound }
         *     
         */
        public Fault.FaultType.DataNotFound getDataNotFound() {
            return dataNotFound;
        }

        /**
         * Sets the value of the dataNotFound property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.DataNotFound }
         *     
         */
        public void setDataNotFound(Fault.FaultType.DataNotFound value) {
            this.dataNotFound = value;
        }

        /**
         * Gets the value of the applicationException property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.ApplicationException }
         *     
         */
        public Fault.FaultType.ApplicationException getApplicationException() {
            return applicationException;
        }

        /**
         * Sets the value of the applicationException property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.ApplicationException }
         *     
         */
        public void setApplicationException(Fault.FaultType.ApplicationException value) {
            this.applicationException = value;
        }

        /**
         * Gets the value of the systemTimeOutException property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.SystemTimeOutException }
         *     
         */
        public Fault.FaultType.SystemTimeOutException getSystemTimeOutException() {
            return systemTimeOutException;
        }

        /**
         * Sets the value of the systemTimeOutException property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.SystemTimeOutException }
         *     
         */
        public void setSystemTimeOutException(Fault.FaultType.SystemTimeOutException value) {
            this.systemTimeOutException = value;
        }

        /**
         * Gets the value of the packageNotCompiled property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.PackageNotCompiled }
         *     
         */
        public Fault.FaultType.PackageNotCompiled getPackageNotCompiled() {
            return packageNotCompiled;
        }

        /**
         * Sets the value of the packageNotCompiled property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.PackageNotCompiled }
         *     
         */
        public void setPackageNotCompiled(Fault.FaultType.PackageNotCompiled value) {
            this.packageNotCompiled = value;
        }

        /**
         * Gets the value of the authenticationException property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.AuthenticationException }
         *     
         */
        public Fault.FaultType.AuthenticationException getAuthenticationException() {
            return authenticationException;
        }

        /**
         * Sets the value of the authenticationException property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.AuthenticationException }
         *     
         */
        public void setAuthenticationException(Fault.FaultType.AuthenticationException value) {
            this.authenticationException = value;
        }

        /**
         * Gets the value of the inputDataInvalid property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.InputDataInvalid }
         *     
         */
        public Fault.FaultType.InputDataInvalid getInputDataInvalid() {
            return inputDataInvalid;
        }

        /**
         * Sets the value of the inputDataInvalid property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.InputDataInvalid }
         *     
         */
        public void setInputDataInvalid(Fault.FaultType.InputDataInvalid value) {
            this.inputDataInvalid = value;
        }

        /**
         * Gets the value of the defaultFault property.
         * 
         * @return
         *     possible object is
         *     {@link Fault.FaultType.DefaultFault }
         *     
         */
        public Fault.FaultType.DefaultFault getDefaultFault() {
            return defaultFault;
        }

        /**
         * Sets the value of the defaultFault property.
         * 
         * @param value
         *     allowed object is
         *     {@link Fault.FaultType.DefaultFault }
         *     
         */
        public void setDefaultFault(Fault.FaultType.DefaultFault value) {
            this.defaultFault = value;
        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class ApplicationException {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class AuthenticationException {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class DataNotFound {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="faultCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="faultMsg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "faultCode",
            "faultMsg"
        })
        public static class DefaultFault {

            protected String faultCode;
            protected String faultMsg;

            /**
             * Gets the value of the faultCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFaultCode() {
                return faultCode;
            }

            /**
             * Sets the value of the faultCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFaultCode(String value) {
                this.faultCode = value;
            }

            /**
             * Gets the value of the faultMsg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getFaultMsg() {
                return faultMsg;
            }

            /**
             * Sets the value of the faultMsg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setFaultMsg(String value) {
                this.faultMsg = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class InputDataInvalid {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class PackageNotCompiled {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class SourceSystemInvalid {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class SystemTimeOutException {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }


        /**
         * <p>Java class for anonymous complex type.
         * 
         * <p>The following schema fragment specifies the expected content contained within this class.
         * 
         * <pre>
         * &lt;complexType&gt;
         *   &lt;complexContent&gt;
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
         *       &lt;sequence&gt;
         *         &lt;element name="msg" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *         &lt;element name="msgCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
         *       &lt;/sequence&gt;
         *     &lt;/restriction&gt;
         *   &lt;/complexContent&gt;
         * &lt;/complexType&gt;
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "msg",
            "msgCode"
        })
        public static class SystemUnavailableFault {

            protected String msg;
            protected String msgCode;

            /**
             * Gets the value of the msg property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsg() {
                return msg;
            }

            /**
             * Sets the value of the msg property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsg(String value) {
                this.msg = value;
            }

            /**
             * Gets the value of the msgCode property.
             * 
             * @return
             *     possible object is
             *     {@link String }
             *     
             */
            public String getMsgCode() {
                return msgCode;
            }

            /**
             * Sets the value of the msgCode property.
             * 
             * @param value
             *     allowed object is
             *     {@link String }
             *     
             */
            public void setMsgCode(String value) {
                this.msgCode = value;
            }

        }

    }

}
