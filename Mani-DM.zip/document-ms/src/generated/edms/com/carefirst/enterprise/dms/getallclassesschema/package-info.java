@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.carefirst.com/Enterprise/DMS/GetAllClassesSchema", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.carefirst.enterprise.dms.getallclassesschema;
