
package com.carefirst.enterprise.dms.searchcontractschema;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}subscriberID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}memberSuffix" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}versionInd"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}currentInd"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}array1" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "subscriberID",
    "memberSuffix",
    "versionInd",
    "currentInd",
    "array1"
})
@XmlRootElement(name = "criteria")
public class Criteria {

    protected String subscriberID;
    protected String memberSuffix;
    @XmlElement(required = true)
    protected String versionInd;
    protected int currentInd;
    @XmlElement(required = true)
    protected List<Array1> array1;

    /**
     * Gets the value of the subscriberID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubscriberID() {
        return subscriberID;
    }

    /**
     * Sets the value of the subscriberID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubscriberID(String value) {
        this.subscriberID = value;
    }

    /**
     * Gets the value of the memberSuffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberSuffix() {
        return memberSuffix;
    }

    /**
     * Sets the value of the memberSuffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberSuffix(String value) {
        this.memberSuffix = value;
    }

    /**
     * Gets the value of the versionInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionInd() {
        return versionInd;
    }

    /**
     * Sets the value of the versionInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionInd(String value) {
        this.versionInd = value;
    }

    /**
     * Gets the value of the currentInd property.
     * 
     */
    public int getCurrentInd() {
        return currentInd;
    }

    /**
     * Sets the value of the currentInd property.
     * 
     */
    public void setCurrentInd(int value) {
        this.currentInd = value;
    }

    /**
     * Gets the value of the array1 property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the array1 property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getArray1().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Array1 }
     * 
     * 
     */
    public List<Array1> getArray1() {
        if (array1 == null) {
            array1 = new ArrayList<Array1>();
        }
        return this.array1;
    }

}
