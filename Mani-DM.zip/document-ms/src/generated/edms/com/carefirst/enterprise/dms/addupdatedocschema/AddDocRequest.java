
package com.carefirst.enterprise.dms.addupdatedocschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}header" minOccurs="0"/&gt;
 *         &lt;element name="body"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}class"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docData"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docProp"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body"
})
@XmlRootElement(name = "AddDocRequest")
public class AddDocRequest {

    protected Header header;
    @XmlElement(required = true)
    protected AddDocRequest.Body body;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link AddDocRequest.Body }
     *     
     */
    public AddDocRequest.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddDocRequest.Body }
     *     
     */
    public void setBody(AddDocRequest.Body value) {
        this.body = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}class"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docData"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/AddUpdateDocSchema}docProp"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "clazz",
        "docData",
        "docProp"
    })
    public static class Body {

        @XmlElement(name = "class", required = true)
        protected String clazz;
        @XmlElement(required = true)
        protected byte[] docData;
        @XmlElement(required = true)
        protected DocProp docProp;

        /**
         * Gets the value of the clazz property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClazz() {
            return clazz;
        }

        /**
         * Sets the value of the clazz property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClazz(String value) {
            this.clazz = value;
        }

        /**
         * Gets the value of the docData property.
         * 
         * @return
         *     possible object is
         *     byte[]
         */
        public byte[] getDocData() {
            return docData;
        }

        /**
         * Sets the value of the docData property.
         * 
         * @param value
         *     allowed object is
         *     byte[]
         */
        public void setDocData(byte[] value) {
            this.docData = value;
        }

        /**
         * Gets the value of the docProp property.
         * 
         * @return
         *     possible object is
         *     {@link DocProp }
         *     
         */
        public DocProp getDocProp() {
            return docProp;
        }

        /**
         * Sets the value of the docProp property.
         * 
         * @param value
         *     allowed object is
         *     {@link DocProp }
         *     
         */
        public void setDocProp(DocProp value) {
            this.docProp = value;
        }

    }

}
