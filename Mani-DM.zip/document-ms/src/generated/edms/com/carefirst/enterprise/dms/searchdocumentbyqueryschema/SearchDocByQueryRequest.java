
package com.carefirst.enterprise.dms.searchdocumentbyqueryschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}header" minOccurs="0"/&gt;
 *         &lt;element name="body"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}selectList"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}className"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}whereClause" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}maxRecords" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}orderBy" minOccurs="0"/&gt;
 *                   &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}subClass" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "header",
    "body"
})
@XmlRootElement(name = "SearchDocByQueryRequest")
public class SearchDocByQueryRequest {

    protected Header header;
    @XmlElement(required = true)
    protected SearchDocByQueryRequest.Body body;

    /**
     * Gets the value of the header property.
     * 
     * @return
     *     possible object is
     *     {@link Header }
     *     
     */
    public Header getHeader() {
        return header;
    }

    /**
     * Sets the value of the header property.
     * 
     * @param value
     *     allowed object is
     *     {@link Header }
     *     
     */
    public void setHeader(Header value) {
        this.header = value;
    }

    /**
     * Gets the value of the body property.
     * 
     * @return
     *     possible object is
     *     {@link SearchDocByQueryRequest.Body }
     *     
     */
    public SearchDocByQueryRequest.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     * 
     * @param value
     *     allowed object is
     *     {@link SearchDocByQueryRequest.Body }
     *     
     */
    public void setBody(SearchDocByQueryRequest.Body value) {
        this.body = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}selectList"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}className"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}whereClause" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}maxRecords" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}orderBy" minOccurs="0"/&gt;
     *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchDocumentByQuerySchema}subClass" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "selectList",
        "className",
        "whereClause",
        "maxRecords",
        "orderBy",
        "subClass"
    })
    public static class Body {

        @XmlElement(required = true)
        protected String selectList;
        @XmlElement(required = true)
        protected String className;
        protected String whereClause;
        protected Integer maxRecords;
        protected String orderBy;
        protected Boolean subClass;

        /**
         * Gets the value of the selectList property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSelectList() {
            return selectList;
        }

        /**
         * Sets the value of the selectList property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSelectList(String value) {
            this.selectList = value;
        }

        /**
         * Gets the value of the className property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getClassName() {
            return className;
        }

        /**
         * Sets the value of the className property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setClassName(String value) {
            this.className = value;
        }

        /**
         * Gets the value of the whereClause property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getWhereClause() {
            return whereClause;
        }

        /**
         * Sets the value of the whereClause property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setWhereClause(String value) {
            this.whereClause = value;
        }

        /**
         * Gets the value of the maxRecords property.
         * 
         * @return
         *     possible object is
         *     {@link Integer }
         *     
         */
        public Integer getMaxRecords() {
            return maxRecords;
        }

        /**
         * Sets the value of the maxRecords property.
         * 
         * @param value
         *     allowed object is
         *     {@link Integer }
         *     
         */
        public void setMaxRecords(Integer value) {
            this.maxRecords = value;
        }

        /**
         * Gets the value of the orderBy property.
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getOrderBy() {
            return orderBy;
        }

        /**
         * Sets the value of the orderBy property.
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setOrderBy(String value) {
            this.orderBy = value;
        }

        /**
         * Gets the value of the subClass property.
         * 
         * @return
         *     possible object is
         *     {@link Boolean }
         *     
         */
        public Boolean isSubClass() {
            return subClass;
        }

        /**
         * Sets the value of the subClass property.
         * 
         * @param value
         *     allowed object is
         *     {@link Boolean }
         *     
         */
        public void setSubClass(Boolean value) {
            this.subClass = value;
        }

    }

}
