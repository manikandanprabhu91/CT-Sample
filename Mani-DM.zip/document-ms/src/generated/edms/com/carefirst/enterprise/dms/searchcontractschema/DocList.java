
package com.carefirst.enterprise.dms.searchcontractschema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}class"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}groupID"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}subGroupID"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}groupName"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}productName"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}filenetName"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}productCategory"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}effStartDate"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}effEndDate"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}pubDate"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}guid"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}ContractStatus" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}documentName" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}documentType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}documentSubType" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DMS/SearchContractSchema}arrayResponse1" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "clazz",
    "groupID",
    "subGroupID",
    "groupName",
    "productName",
    "filenetName",
    "productCategory",
    "effStartDate",
    "effEndDate",
    "pubDate",
    "guid",
    "contractStatus",
    "documentName",
    "documentType",
    "documentSubType",
    "arrayResponse1"
})
@XmlRootElement(name = "docList")
public class DocList {

    @XmlElement(name = "class", required = true)
    protected String clazz;
    @XmlElement(required = true)
    protected String groupID;
    @XmlElement(required = true)
    protected String subGroupID;
    @XmlElement(required = true)
    protected String groupName;
    @XmlElement(required = true)
    protected String productName;
    @XmlElement(required = true)
    protected String filenetName;
    @XmlElement(required = true)
    protected String productCategory;
    @XmlElement(required = true)
    protected String effStartDate;
    @XmlElement(required = true)
    protected String effEndDate;
    @XmlElement(required = true)
    protected String pubDate;
    @XmlElement(required = true)
    protected String guid;
    @XmlElement(name = "ContractStatus")
    protected String contractStatus;
    protected String documentName;
    protected String documentType;
    protected String documentSubType;
    protected ArrayResponse1 arrayResponse1;

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the groupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupID() {
        return groupID;
    }

    /**
     * Sets the value of the groupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupID(String value) {
        this.groupID = value;
    }

    /**
     * Gets the value of the subGroupID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubGroupID() {
        return subGroupID;
    }

    /**
     * Sets the value of the subGroupID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubGroupID(String value) {
        this.subGroupID = value;
    }

    /**
     * Gets the value of the groupName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * Sets the value of the groupName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGroupName(String value) {
        this.groupName = value;
    }

    /**
     * Gets the value of the productName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the productName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductName(String value) {
        this.productName = value;
    }

    /**
     * Gets the value of the filenetName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilenetName() {
        return filenetName;
    }

    /**
     * Sets the value of the filenetName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilenetName(String value) {
        this.filenetName = value;
    }

    /**
     * Gets the value of the productCategory property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCategory() {
        return productCategory;
    }

    /**
     * Sets the value of the productCategory property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCategory(String value) {
        this.productCategory = value;
    }

    /**
     * Gets the value of the effStartDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffStartDate() {
        return effStartDate;
    }

    /**
     * Sets the value of the effStartDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffStartDate(String value) {
        this.effStartDate = value;
    }

    /**
     * Gets the value of the effEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEffEndDate() {
        return effEndDate;
    }

    /**
     * Sets the value of the effEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEffEndDate(String value) {
        this.effEndDate = value;
    }

    /**
     * Gets the value of the pubDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPubDate() {
        return pubDate;
    }

    /**
     * Sets the value of the pubDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPubDate(String value) {
        this.pubDate = value;
    }

    /**
     * Gets the value of the guid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGuid() {
        return guid;
    }

    /**
     * Sets the value of the guid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGuid(String value) {
        this.guid = value;
    }

    /**
     * Gets the value of the contractStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractStatus() {
        return contractStatus;
    }

    /**
     * Sets the value of the contractStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractStatus(String value) {
        this.contractStatus = value;
    }

    /**
     * Gets the value of the documentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentName() {
        return documentName;
    }

    /**
     * Sets the value of the documentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentName(String value) {
        this.documentName = value;
    }

    /**
     * Gets the value of the documentType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentType() {
        return documentType;
    }

    /**
     * Sets the value of the documentType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentType(String value) {
        this.documentType = value;
    }

    /**
     * Gets the value of the documentSubType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentSubType() {
        return documentSubType;
    }

    /**
     * Sets the value of the documentSubType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentSubType(String value) {
        this.documentSubType = value;
    }

    /**
     * Gets the value of the arrayResponse1 property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayResponse1 }
     *     
     */
    public ArrayResponse1 getArrayResponse1() {
        return arrayResponse1;
    }

    /**
     * Sets the value of the arrayResponse1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayResponse1 }
     *     
     */
    public void setArrayResponse1(ArrayResponse1 value) {
        this.arrayResponse1 = value;
    }

}
