
package com.tibco.schemas.cfedmsservices.sharedresources.schemadefinitions.searchdocbycontentquery.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element ref="{http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd}senderID" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd}senderApp" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd}msgVersion" minOccurs="0"/&gt;
 *         &lt;element ref="{http://www.tibco.com/schemas/CFEDMSServices/SharedResources/SchemaDefinitions/SearchDocByContentQuery/Schema.xsd}msgID" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "senderID",
    "senderApp",
    "msgVersion",
    "msgID"
})
@XmlRootElement(name = "Header")
public class Header {

    protected String senderID;
    protected String senderApp;
    protected String msgVersion;
    protected String msgID;

    /**
     * Gets the value of the senderID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderID() {
        return senderID;
    }

    /**
     * Sets the value of the senderID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderID(String value) {
        this.senderID = value;
    }

    /**
     * Gets the value of the senderApp property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSenderApp() {
        return senderApp;
    }

    /**
     * Sets the value of the senderApp property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSenderApp(String value) {
        this.senderApp = value;
    }

    /**
     * Gets the value of the msgVersion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgVersion() {
        return msgVersion;
    }

    /**
     * Sets the value of the msgVersion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgVersion(String value) {
        this.msgVersion = value;
    }

    /**
     * Gets the value of the msgID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMsgID() {
        return msgID;
    }

    /**
     * Sets the value of the msgID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMsgID(String value) {
        this.msgID = value;
    }

}
