package com.carefirst.nexus.document.gen.api;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Optional;
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

@Controller
@RequestMapping("${openapi.nexusDocuments.base-path:}")
public class DocumentsApiController implements DocumentsApi {

    private final DocumentsApiDelegate delegate;

    public DocumentsApiController(@org.springframework.beans.factory.annotation.Autowired(required = false) DocumentsApiDelegate delegate) {
        this.delegate = Optional.ofNullable(delegate).orElse(new DocumentsApiDelegate() {});
    }

    @Override
    public DocumentsApiDelegate getDelegate() {
        return delegate;
    }

}
