package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.ProductCategory;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractDocument
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

public class ContractDocument   {
  @JsonProperty("groupId")
  private String groupId;

  @JsonProperty("subgroupId")
  private String subgroupId;

  @JsonProperty("productId")
  private String productId;

  @JsonProperty("productCategory")
  private ProductCategory productCategory;

  @JsonProperty("groupName")
  private String groupName;

  @JsonProperty("productName")
  private String productName;

  @JsonProperty("contractName")
  private String contractName;

  @JsonProperty("effectiveStartDate")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
  private LocalDate effectiveStartDate;

  @JsonProperty("effectiveEndDate")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
  private LocalDate effectiveEndDate;

  @JsonProperty("publishDate")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
  private LocalDate publishDate;

  @JsonProperty("documentId")
  private String documentId;

  @JsonProperty("documentClass")
  private String documentClass;

  @JsonProperty("documentName")
  private String documentName;

  @JsonProperty("documentType")
  private String documentType;

  @JsonProperty("documentSubType")
  private String documentSubType;

  @JsonProperty("ContractStatus")
  private String contractStatus;

  public ContractDocument groupId(String groupId) {
    this.groupId = groupId;
    return this;
  }

  /**
   * group id
   * @return groupId
  */
  @ApiModelProperty(example = "98A4", value = "group id")


  public String getGroupId() {
    return groupId;
  }

  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }

  public ContractDocument subgroupId(String subgroupId) {
    this.subgroupId = subgroupId;
    return this;
  }

  /**
   * sub group id
   * @return subgroupId
  */
  @ApiModelProperty(example = "0001", value = "sub group id")


  public String getSubgroupId() {
    return subgroupId;
  }

  public void setSubgroupId(String subgroupId) {
    this.subgroupId = subgroupId;
  }

  public ContractDocument productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * product id
   * @return productId
  */
  @ApiModelProperty(example = "BHM00673", value = "product id")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public ContractDocument productCategory(ProductCategory productCategory) {
    this.productCategory = productCategory;
    return this;
  }

  /**
   * Get productCategory
   * @return productCategory
  */
  @ApiModelProperty(value = "")

  @Valid

  public ProductCategory getProductCategory() {
    return productCategory;
  }

  public void setProductCategory(ProductCategory productCategory) {
    this.productCategory = productCategory;
  }

  public ContractDocument groupName(String groupName) {
    this.groupName = groupName;
    return this;
  }

  /**
   * group name
   * @return groupName
  */
  @ApiModelProperty(example = "Group Name", value = "group name")


  public String getGroupName() {
    return groupName;
  }

  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }

  public ContractDocument productName(String productName) {
    this.productName = productName;
    return this;
  }

  /**
   * product name
   * @return productName
  */
  @ApiModelProperty(example = "Product Name", value = "product name")


  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public ContractDocument contractName(String contractName) {
    this.contractName = contractName;
    return this;
  }

  /**
   * contract name
   * @return contractName
  */
  @ApiModelProperty(example = "Contract", value = "contract name")


  public String getContractName() {
    return contractName;
  }

  public void setContractName(String contractName) {
    this.contractName = contractName;
  }

  public ContractDocument effectiveStartDate(LocalDate effectiveStartDate) {
    this.effectiveStartDate = effectiveStartDate;
    return this;
  }

  /**
   * effective start Date
   * @return effectiveStartDate
  */
  @ApiModelProperty(example = "Mon Dec 31 19:00:00 EST 2018", value = "effective start Date")

  @Valid

  public LocalDate getEffectiveStartDate() {
    return effectiveStartDate;
  }

  public void setEffectiveStartDate(LocalDate effectiveStartDate) {
    this.effectiveStartDate = effectiveStartDate;
  }

  public ContractDocument effectiveEndDate(LocalDate effectiveEndDate) {
    this.effectiveEndDate = effectiveEndDate;
    return this;
  }

  /**
   * effective end Date
   * @return effectiveEndDate
  */
  @ApiModelProperty(example = "Tue Dec 31 19:00:00 EST 2019", value = "effective end Date")

  @Valid

  public LocalDate getEffectiveEndDate() {
    return effectiveEndDate;
  }

  public void setEffectiveEndDate(LocalDate effectiveEndDate) {
    this.effectiveEndDate = effectiveEndDate;
  }

  public ContractDocument publishDate(LocalDate publishDate) {
    this.publishDate = publishDate;
    return this;
  }

  /**
   * publish Date
   * @return publishDate
  */
  @ApiModelProperty(example = "Sun May 31 20:00:00 EDT 2020", value = "publish Date")

  @Valid

  public LocalDate getPublishDate() {
    return publishDate;
  }

  public void setPublishDate(LocalDate publishDate) {
    this.publishDate = publishDate;
  }

  public ContractDocument documentId(String documentId) {
    this.documentId = documentId;
    return this;
  }

  /**
   * document guid
   * @return documentId
  */
  @ApiModelProperty(example = "3091EF6F-0100-CF3E-87B8-A8E0A054E45B", value = "document guid")


  public String getDocumentId() {
    return documentId;
  }

  public void setDocumentId(String documentId) {
    this.documentId = documentId;
  }

  public ContractDocument documentClass(String documentClass) {
    this.documentClass = documentClass;
    return this;
  }

  /**
   * Get documentClass
   * @return documentClass
  */
  @ApiModelProperty(value = "")


  public String getDocumentClass() {
    return documentClass;
  }

  public void setDocumentClass(String documentClass) {
    this.documentClass = documentClass;
  }

  public ContractDocument documentName(String documentName) {
    this.documentName = documentName;
    return this;
  }

  /**
   * Get documentName
   * @return documentName
  */
  @ApiModelProperty(value = "")


  public String getDocumentName() {
    return documentName;
  }

  public void setDocumentName(String documentName) {
    this.documentName = documentName;
  }

  public ContractDocument documentType(String documentType) {
    this.documentType = documentType;
    return this;
  }

  /**
   * Get documentType
   * @return documentType
  */
  @ApiModelProperty(value = "")


  public String getDocumentType() {
    return documentType;
  }

  public void setDocumentType(String documentType) {
    this.documentType = documentType;
  }

  public ContractDocument documentSubType(String documentSubType) {
    this.documentSubType = documentSubType;
    return this;
  }

  /**
   * Get documentSubType
   * @return documentSubType
  */
  @ApiModelProperty(value = "")


  public String getDocumentSubType() {
    return documentSubType;
  }

  public void setDocumentSubType(String documentSubType) {
    this.documentSubType = documentSubType;
  }

  public ContractDocument contractStatus(String contractStatus) {
    this.contractStatus = contractStatus;
    return this;
  }

  /**
   * Get contractStatus
   * @return contractStatus
  */
  @ApiModelProperty(value = "")


  public String getContractStatus() {
    return contractStatus;
  }

  public void setContractStatus(String contractStatus) {
    this.contractStatus = contractStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractDocument contractDocument = (ContractDocument) o;
    return Objects.equals(this.groupId, contractDocument.groupId) &&
        Objects.equals(this.subgroupId, contractDocument.subgroupId) &&
        Objects.equals(this.productId, contractDocument.productId) &&
        Objects.equals(this.productCategory, contractDocument.productCategory) &&
        Objects.equals(this.groupName, contractDocument.groupName) &&
        Objects.equals(this.productName, contractDocument.productName) &&
        Objects.equals(this.contractName, contractDocument.contractName) &&
        Objects.equals(this.effectiveStartDate, contractDocument.effectiveStartDate) &&
        Objects.equals(this.effectiveEndDate, contractDocument.effectiveEndDate) &&
        Objects.equals(this.publishDate, contractDocument.publishDate) &&
        Objects.equals(this.documentId, contractDocument.documentId) &&
        Objects.equals(this.documentClass, contractDocument.documentClass) &&
        Objects.equals(this.documentName, contractDocument.documentName) &&
        Objects.equals(this.documentType, contractDocument.documentType) &&
        Objects.equals(this.documentSubType, contractDocument.documentSubType) &&
        Objects.equals(this.contractStatus, contractDocument.contractStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groupId, subgroupId, productId, productCategory, groupName, productName, contractName, effectiveStartDate, effectiveEndDate, publishDate, documentId, documentClass, documentName, documentType, documentSubType, contractStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractDocument {\n");
    
    sb.append("    groupId: ").append(toIndentedString(groupId)).append("\n");
    sb.append("    subgroupId: ").append(toIndentedString(subgroupId)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productCategory: ").append(toIndentedString(productCategory)).append("\n");
    sb.append("    groupName: ").append(toIndentedString(groupName)).append("\n");
    sb.append("    productName: ").append(toIndentedString(productName)).append("\n");
    sb.append("    contractName: ").append(toIndentedString(contractName)).append("\n");
    sb.append("    effectiveStartDate: ").append(toIndentedString(effectiveStartDate)).append("\n");
    sb.append("    effectiveEndDate: ").append(toIndentedString(effectiveEndDate)).append("\n");
    sb.append("    publishDate: ").append(toIndentedString(publishDate)).append("\n");
    sb.append("    documentId: ").append(toIndentedString(documentId)).append("\n");
    sb.append("    documentClass: ").append(toIndentedString(documentClass)).append("\n");
    sb.append("    documentName: ").append(toIndentedString(documentName)).append("\n");
    sb.append("    documentType: ").append(toIndentedString(documentType)).append("\n");
    sb.append("    documentSubType: ").append(toIndentedString(documentSubType)).append("\n");
    sb.append("    contractStatus: ").append(toIndentedString(contractStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

