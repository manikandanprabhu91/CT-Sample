package com.carefirst.nexus.document.gen.api;

import com.carefirst.nexus.document.gen.model.AddDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractSearchCriteria;
import com.carefirst.nexus.document.gen.model.DocumentClassResponse;
import com.carefirst.nexus.document.gen.model.DocumentPropertiesResponse;
import com.carefirst.nexus.document.gen.model.DocumentProperty;
import com.carefirst.nexus.document.gen.model.DocumentRequest;
import com.carefirst.nexus.document.gen.model.DocumentResponse;
import java.time.LocalDate;
import com.carefirst.nexus.document.gen.model.ResponseContext;
import com.carefirst.nexus.document.gen.model.SearchDocumentResponse;
import io.swagger.annotations.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * A delegate to be called by the {@link DocumentsApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

public interface DocumentsApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /documents/ : Add Document details
     *
     * @param documentRequest documentRequest (required)
     * @return Success - created (status code 201)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#addDocument
     */
    default ResponseEntity<AddDocumentResponse> addDocument(DocumentRequest documentRequest) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" }, \"documentId\" : \"3091EF6F-0100-CF3E-87B8-A8E0A054E45B\" }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /documents/contracts/ : Search Contract Document details using input parameters
     *
     * @param searchStartDate search start date (optional)
     * @param searchEndDate search end date (optional)
     * @param documentClass document class (optional, default to new ArrayList&lt;&gt;())
     * @param contractSearchCriteria contract search criteria properties (optional)
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#findContractDocuments
     */
    default ResponseEntity<ContractDocumentResponse> findContractDocuments(LocalDate searchStartDate,
        LocalDate searchEndDate,
        List<String> documentClass,
        ContractSearchCriteria contractSearchCriteria) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"documentProperties\" : [ { \"effectiveEndDate\" : \"2020-01-01T00:00:00.000+0000\", \"documentSubType\" : \"documentSubType\", \"productId\" : \"BHM00673\", \"documentType\" : \"documentType\", \"groupId\" : \"98A4\", \"publishDate\" : \"2020-06-01T00:00:00.000+0000\", \"ContractStatus\" : \"ContractStatus\", \"documentName\" : \"documentName\", \"productName\" : \"Product Name\", \"documentClass\" : \"documentClass\", \"subgroupId\" : \"0001\", \"productCategory\" : \"MED\", \"groupName\" : \"Group Name\", \"effectiveStartDate\" : \"2019-01-01T00:00:00.000+0000\", \"contractName\" : \"Contract\", \"documentId\" : \"3091EF6F-0100-CF3E-87B8-A8E0A054E45B\" }, { \"effectiveEndDate\" : \"2020-01-01T00:00:00.000+0000\", \"documentSubType\" : \"documentSubType\", \"productId\" : \"BHM00673\", \"documentType\" : \"documentType\", \"groupId\" : \"98A4\", \"publishDate\" : \"2020-06-01T00:00:00.000+0000\", \"ContractStatus\" : \"ContractStatus\", \"documentName\" : \"documentName\", \"productName\" : \"Product Name\", \"documentClass\" : \"documentClass\", \"subgroupId\" : \"0001\", \"productCategory\" : \"MED\", \"groupName\" : \"Group Name\", \"effectiveStartDate\" : \"2019-01-01T00:00:00.000+0000\", \"contractName\" : \"Contract\", \"documentId\" : \"3091EF6F-0100-CF3E-87B8-A8E0A054E45B\" } ], \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" }, \"contractIdentifier\" : { \"subscriberId\" : \"9013456077\", \"version\" : \"01\", \"memberSuffix\" : \"01\" } }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /documents/ : Search Document details using input parameters
     *
     * @param searchStartDate search start date (optional)
     * @param searchEndDate search end date (optional)
     * @param documentClass document class (optional, default to new ArrayList&lt;&gt;())
     * @param versionHistory verstion history needed (optional)
     * @param searchCriteria search criteria properties (optional, default to new ArrayList&lt;&gt;())
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#findDocuments
     */
    default ResponseEntity<SearchDocumentResponse> findDocuments(LocalDate searchStartDate,
        LocalDate searchEndDate,
        List<String> documentClass,
        Boolean versionHistory,
        List<DocumentProperty> searchCriteria) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"documentProperties\" : [ { \"dataType\" : \"dataType\", \"name\" : \"name\", \"value\" : \"value\" }, { \"dataType\" : \"dataType\", \"name\" : \"name\", \"value\" : \"value\" } ], \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" } }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /documents/{documentId} : Get Document details using document id
     *
     * @param documentId Document GuId (required)
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#getDocument
     */
    default ResponseEntity<DocumentResponse> getDocument(String documentId) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"document\" : { \"documentId\" : \"3091EF6F-0100-CF3E-87B8-A8E0A054E45B\", \"documentMimeType\" : \"application/pdf\", \"documentTitle\" : \"documentTitle\", \"documentData\" : \"documentData\" }, \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" } }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /documents/{documentId}/properties/ : Document properties or metadata using document id
     *
     * @param documentId Document GuId (required)
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#getDocumentProperties
     */
    default ResponseEntity<DocumentPropertiesResponse> getDocumentProperties(String documentId) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"documentProperties\" : [ { \"dataType\" : \"dataType\", \"name\" : \"name\", \"value\" : \"value\" }, { \"dataType\" : \"dataType\", \"name\" : \"name\", \"value\" : \"value\" } ], \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" } }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /documents/classes/ : Search Contract Document details using input parameters
     *
     * @param documentClass document class (optional)
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     * @see DocumentsApi#searchContractDocuments
     */
    default ResponseEntity<DocumentClassResponse> searchContractDocuments(String documentClass) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"responseContext\" : { \"success\" : true, \"responseTime\" : \"121 ms\", \"guid\" : \"08b4b150-ca44-47d8-9c4a-a87979357f35\", \"currentTimeStamp\" : \"2019-06-10T04:55:13.309-04:00\", \"error\" : { \"code\" : \"100.001\", \"details\" : [ { \"value\" : \"value\", \"key\" : \"key\" }, { \"value\" : \"value\", \"key\" : \"key\" } ], \"message\" : \"error message\", \"moreInfo\" : \"N/A\" }, \"status\" : \"200 OK\" }, \"documentSubClasses\" : [ \"documentSubClasses\", \"documentSubClasses\" ] }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
