package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractIdentifier
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

public class ContractIdentifier   {
  @JsonProperty("subscriberId")
  private String subscriberId;

  @JsonProperty("memberSuffix")
  private String memberSuffix;

  @JsonProperty("version")
  private String version;

  public ContractIdentifier subscriberId(String subscriberId) {
    this.subscriberId = subscriberId;
    return this;
  }

  /**
   * subscriber id
   * @return subscriberId
  */
  @ApiModelProperty(example = "9013456077", value = "subscriber id")


  public String getSubscriberId() {
    return subscriberId;
  }

  public void setSubscriberId(String subscriberId) {
    this.subscriberId = subscriberId;
  }

  public ContractIdentifier memberSuffix(String memberSuffix) {
    this.memberSuffix = memberSuffix;
    return this;
  }

  /**
   * member suffix
   * @return memberSuffix
  */
  @ApiModelProperty(example = "01", value = "member suffix")


  public String getMemberSuffix() {
    return memberSuffix;
  }

  public void setMemberSuffix(String memberSuffix) {
    this.memberSuffix = memberSuffix;
  }

  public ContractIdentifier version(String version) {
    this.version = version;
    return this;
  }

  /**
   * version indicator
   * @return version
  */
  @ApiModelProperty(example = "01", value = "version indicator")


  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractIdentifier contractIdentifier = (ContractIdentifier) o;
    return Objects.equals(this.subscriberId, contractIdentifier.subscriberId) &&
        Objects.equals(this.memberSuffix, contractIdentifier.memberSuffix) &&
        Objects.equals(this.version, contractIdentifier.version);
  }

  @Override
  public int hashCode() {
    return Objects.hash(subscriberId, memberSuffix, version);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractIdentifier {\n");
    
    sb.append("    subscriberId: ").append(toIndentedString(subscriberId)).append("\n");
    sb.append("    memberSuffix: ").append(toIndentedString(memberSuffix)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

