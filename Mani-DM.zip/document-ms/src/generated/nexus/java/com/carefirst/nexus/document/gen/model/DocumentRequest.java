package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * DocumentRequest
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

public class DocumentRequest   {
  @JsonProperty("documentClass")
  private String documentClass;

  @JsonProperty("documentProperty")
  private String documentProperty;

  @JsonProperty("documentData")
  private byte[] documentData;

  public DocumentRequest documentClass(String documentClass) {
    this.documentClass = documentClass;
    return this;
  }

  /**
   * Get documentClass
   * @return documentClass
  */
  @ApiModelProperty(value = "")


  public String getDocumentClass() {
    return documentClass;
  }

  public void setDocumentClass(String documentClass) {
    this.documentClass = documentClass;
  }

  public DocumentRequest documentProperty(String documentProperty) {
    this.documentProperty = documentProperty;
    return this;
  }

  /**
   * Get documentProperty
   * @return documentProperty
  */
  @ApiModelProperty(value = "")


  public String getDocumentProperty() {
    return documentProperty;
  }

  public void setDocumentProperty(String documentProperty) {
    this.documentProperty = documentProperty;
  }

  public DocumentRequest documentData(byte[] documentData) {
    this.documentData = documentData;
    return this;
  }

  /**
   * Get documentData
   * @return documentData
  */
  @ApiModelProperty(value = "")


  public byte[] getDocumentData() {
    return documentData;
  }

  public void setDocumentData(byte[] documentData) {
    this.documentData = documentData;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DocumentRequest documentRequest = (DocumentRequest) o;
    return Objects.equals(this.documentClass, documentRequest.documentClass) &&
        Objects.equals(this.documentProperty, documentRequest.documentProperty) &&
        Objects.equals(this.documentData, documentRequest.documentData);
  }

  @Override
  public int hashCode() {
    return Objects.hash(documentClass, documentProperty, documentData);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DocumentRequest {\n");
    
    sb.append("    documentClass: ").append(toIndentedString(documentClass)).append("\n");
    sb.append("    documentProperty: ").append(toIndentedString(documentProperty)).append("\n");
    sb.append("    documentData: ").append(toIndentedString(documentData)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

