package com.carefirst.nexus.document.gen.model;

import java.util.Objects;
import com.carefirst.nexus.document.gen.model.ProductCategory;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * ContractGroupProductSearchCriteria
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2020-06-23T22:53:27.742-04:00[America/New_York]")

public class ContractGroupProductSearchCriteria   {
  @JsonProperty("groupId")
  private String groupId;

  @JsonProperty("subgroupId")
  private String subgroupId;

  @JsonProperty("productId")
  private String productId;

  @JsonProperty("productCategory")
  private ProductCategory productCategory;

  @JsonProperty("packageClass")
  private String packageClass;

  @JsonProperty("startDate")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
  private LocalDate startDate;

  @JsonProperty("endDate")
  @org.springframework.format.annotation.DateTimeFormat(iso = org.springframework.format.annotation.DateTimeFormat.ISO.DATE)
  private LocalDate endDate;

  public ContractGroupProductSearchCriteria groupId(String groupId) {
    this.groupId = groupId;
    return this;
  }

  /**
   * group id
   * @return groupId
  */
  @ApiModelProperty(example = "98A4", value = "group id")


  public String getGroupId() {
    return groupId;
  }

  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }

  public ContractGroupProductSearchCriteria subgroupId(String subgroupId) {
    this.subgroupId = subgroupId;
    return this;
  }

  /**
   * sub group id
   * @return subgroupId
  */
  @ApiModelProperty(example = "0001", value = "sub group id")


  public String getSubgroupId() {
    return subgroupId;
  }

  public void setSubgroupId(String subgroupId) {
    this.subgroupId = subgroupId;
  }

  public ContractGroupProductSearchCriteria productId(String productId) {
    this.productId = productId;
    return this;
  }

  /**
   * product id
   * @return productId
  */
  @ApiModelProperty(example = "BHM00673", value = "product id")


  public String getProductId() {
    return productId;
  }

  public void setProductId(String productId) {
    this.productId = productId;
  }

  public ContractGroupProductSearchCriteria productCategory(ProductCategory productCategory) {
    this.productCategory = productCategory;
    return this;
  }

  /**
   * Get productCategory
   * @return productCategory
  */
  @ApiModelProperty(value = "")

  @Valid

  public ProductCategory getProductCategory() {
    return productCategory;
  }

  public void setProductCategory(ProductCategory productCategory) {
    this.productCategory = productCategory;
  }

  public ContractGroupProductSearchCriteria packageClass(String packageClass) {
    this.packageClass = packageClass;
    return this;
  }

  /**
   * package code or class id
   * @return packageClass
  */
  @ApiModelProperty(example = "0001", value = "package code or class id")


  public String getPackageClass() {
    return packageClass;
  }

  public void setPackageClass(String packageClass) {
    this.packageClass = packageClass;
  }

  public ContractGroupProductSearchCriteria startDate(LocalDate startDate) {
    this.startDate = startDate;
    return this;
  }

  /**
   * start Date
   * @return startDate
  */
  @ApiModelProperty(example = "Mon Dec 31 19:00:00 EST 2018", value = "start Date")

  @Valid

  public LocalDate getStartDate() {
    return startDate;
  }

  public void setStartDate(LocalDate startDate) {
    this.startDate = startDate;
  }

  public ContractGroupProductSearchCriteria endDate(LocalDate endDate) {
    this.endDate = endDate;
    return this;
  }

  /**
   * end Date
   * @return endDate
  */
  @ApiModelProperty(example = "Tue Dec 31 19:00:00 EST 2019", value = "end Date")

  @Valid

  public LocalDate getEndDate() {
    return endDate;
  }

  public void setEndDate(LocalDate endDate) {
    this.endDate = endDate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContractGroupProductSearchCriteria contractGroupProductSearchCriteria = (ContractGroupProductSearchCriteria) o;
    return Objects.equals(this.groupId, contractGroupProductSearchCriteria.groupId) &&
        Objects.equals(this.subgroupId, contractGroupProductSearchCriteria.subgroupId) &&
        Objects.equals(this.productId, contractGroupProductSearchCriteria.productId) &&
        Objects.equals(this.productCategory, contractGroupProductSearchCriteria.productCategory) &&
        Objects.equals(this.packageClass, contractGroupProductSearchCriteria.packageClass) &&
        Objects.equals(this.startDate, contractGroupProductSearchCriteria.startDate) &&
        Objects.equals(this.endDate, contractGroupProductSearchCriteria.endDate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groupId, subgroupId, productId, productCategory, packageClass, startDate, endDate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContractGroupProductSearchCriteria {\n");
    
    sb.append("    groupId: ").append(toIndentedString(groupId)).append("\n");
    sb.append("    subgroupId: ").append(toIndentedString(subgroupId)).append("\n");
    sb.append("    productId: ").append(toIndentedString(productId)).append("\n");
    sb.append("    productCategory: ").append(toIndentedString(productCategory)).append("\n");
    sb.append("    packageClass: ").append(toIndentedString(packageClass)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    endDate: ").append(toIndentedString(endDate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

