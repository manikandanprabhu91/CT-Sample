package com.carefirst.nexus.document.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author aad7740
 *
 */
@Configuration
@ConfigurationProperties(prefix="edms")
@Getter
@Setter
public class EDMSConfig {

	private String wsdlUrl;
	private String username;
	private String password;
	private String endPoint;
}
