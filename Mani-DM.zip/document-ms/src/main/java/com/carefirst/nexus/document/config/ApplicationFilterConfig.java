package com.carefirst.nexus.document.config;

public class ApplicationFilterConfig {

}
