package com.carefirst.nexus.document.service;

import java.time.LocalDate;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest;
import com.carefirst.enterprise.dms.addupdatedocschema.AddDocResponse;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest;
import com.carefirst.enterprise.dms.getdocschema.GetDocRequest.Body;
import com.carefirst.enterprise.dms.getdocschema.GetDocResponse;
import com.carefirst.nexus.document.gen.api.DocumentsApiDelegate;
import com.carefirst.nexus.document.gen.model.AddDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractDocumentResponse;
import com.carefirst.nexus.document.gen.model.ContractSearchCriteria;
import com.carefirst.nexus.document.gen.model.DocumentClassResponse;
import com.carefirst.nexus.document.gen.model.DocumentDetails;
import com.carefirst.nexus.document.gen.model.DocumentPropertiesResponse;
import com.carefirst.nexus.document.gen.model.DocumentProperty;
import com.carefirst.nexus.document.gen.model.DocumentRequest;
import com.carefirst.nexus.document.gen.model.DocumentResponse;
import com.carefirst.nexus.document.gen.model.SearchDocumentResponse;

/**
 * 
 * @author aad7740
 *
 */
public class DocumentService implements DocumentsApiDelegate {

	private static final Logger LOGGER = LogManager.getLogger(DocumentService.class);

	@Autowired
	EDMSService edmsService;

	public ResponseEntity<AddDocumentResponse> addDocument(DocumentRequest documentRequest) {
		LOGGER.info(">>>>>>>>>>>>>getDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		AddDocumentResponse addDocumentResponse = null;
		try {
			AddDocRequest docRequest = new AddDocRequest();
			com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest.Body body = new com.carefirst.enterprise.dms.addupdatedocschema.AddDocRequest.Body();
			body.setDocData(documentRequest.getDocumentData());
			body.setClazz(documentRequest.getDocumentClass());
			com.carefirst.enterprise.dms.addupdatedocschema.DocProp value = new com.carefirst.enterprise.dms.addupdatedocschema.DocProp();
			com.carefirst.enterprise.dms.addupdatedocschema.DocProp.Property documentTitle = new com.carefirst.enterprise.dms.addupdatedocschema.DocProp.Property();
			documentTitle.setPropertyName("DocumentStatus");
			documentTitle.setValue("Approved");
			value.getProperty().add(documentTitle);
			body.setDocProp(value);
			docRequest.setBody(body);
			AddDocResponse docResponse = edmsService.addDocument(docRequest);
			addDocumentResponse = new AddDocumentResponse();
			addDocumentResponse.setDocumentId(docResponse.getGuid());
		} catch (Exception e) {
			LOGGER.error(">>>>>>>>>>>>>Error Occring addDocument Service >>>>>>>>>>>>>>>>>>>>> "+e.getMessage());
		}
		LOGGER.info(">>>>>>>>>>>>>getDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		return null;
	}

	public ResponseEntity<ContractDocumentResponse> findContractDocuments(LocalDate searchStartDate,
			LocalDate searchEndDate,
			List<String> documentClass,
			ContractSearchCriteria contractSearchCriteria) {
		return null;
	}

	public ResponseEntity<SearchDocumentResponse> findDocuments(LocalDate searchStartDate,
			LocalDate searchEndDate,
			List<String> documentClass,
			Boolean versionHistory,
			List<DocumentProperty> searchCriteria) {
		return null;
	}

	public ResponseEntity<DocumentResponse> getDocument(String documentId) {
		LOGGER.info(">>>>>>>>>>>>>getDocument method Start >>>>>>>>>>>>>>>>>>>>> ");
		DocumentResponse documentResponse = null;
		try {
			GetDocRequest request = new GetDocRequest();
			Body body = new Body();
			body.setGuid(documentId);
			request.setBody(body);
			GetDocResponse docResponse = edmsService.getDocument(request);
			documentResponse = new DocumentResponse();
			DocumentDetails document = new DocumentDetails();
			document.setDocumentData(docResponse.getDocData());
			document.setDocumentTitle(docResponse.getDocTitle());
			documentResponse.setDocument(document);
		} catch (Exception e) {
			LOGGER.error("Error Occuring getDocument Service >>>>>>>>>>>>>>>>>>>>> ", e.getMessage());
		}
		LOGGER.info(">>>>>>>>>>>>>getDocument method End >>>>>>>>>>>>>>>>>>>>> ");
		return new ResponseEntity<DocumentResponse>(documentResponse, HttpStatus.OK);
	}

	public ResponseEntity<DocumentPropertiesResponse> getDocumentProperties(String documentId) {
		return null;
	}

	public ResponseEntity<DocumentClassResponse> searchContractDocuments(String documentClass) {
		return null;
	}
}
