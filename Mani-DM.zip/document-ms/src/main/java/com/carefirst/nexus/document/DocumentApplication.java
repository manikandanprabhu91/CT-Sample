package com.carefirst.nexus.document;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 
 * @author aad7740
 *
 */
@SpringBootApplication
@ComponentScan({ "com.carefirst.nexus.utils.web.controllers.admin", 
					"com.carefirst.nexus.pcp",
					"com.carefirst.nexus.utils.web.error",
					"com.carefirst.nexus.utils.web.config.token",
					"com.carefirst.nexus.utils.web.controllers.locallogin",
					"com.carefirst.nexus.utils.web.locallogin",
					"com.carefirst.nexus.memberpcp.gen"})
@RestController
public class DocumentApplication {
	
	private static final Logger LOGGER = LogManager.getLogger(DocumentApplication.class);

	@GetMapping("/pub/healthcheck")
	public String healthCheck() {
		LOGGER.info(">>>>>>>>>>>DocumentApplication HealthCheck>>>>>>>>>>>>>>>>>>>");
		return "OK";
	}
	

	public static void main(String[] args) {
		SpringApplication.run(DocumentApplication.class, args);
	}
}
