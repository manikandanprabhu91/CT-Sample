package com.carefirst.icentric.batch.model;

public class ErrorResponseDto {

	private String errCode;
	private String providerEngagementID;
	private String gapId;
	private String homePlanStatus;
	private String hostPlanStatus;
	private String fieldElement;
	private String fieldData;
	
	public String getErrCode() {
		return errCode;
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getProviderEngagementID() {
		return providerEngagementID;
	}
	public void setProviderEngagementID(String providerEngagementID) {
		this.providerEngagementID = providerEngagementID;
	}
	public String getGapId() {
		return gapId;
	}
	public void setGapId(String gapId) {
		this.gapId = gapId;
	}
	public String getHomePlanStatus() {
		return homePlanStatus;
	}
	public void setHomePlanStatus(String homePlanStatus) {
		this.homePlanStatus = homePlanStatus;
	}
	public String getHostPlanStatus() {
		return hostPlanStatus;
	}
	public void setHostPlanStatus(String hostPlanStatus) {
		this.hostPlanStatus = hostPlanStatus;
	}
	public String getFieldElement() {
		return fieldElement;
	}
	public void setFieldElement(String fieldElement) {
		this.fieldElement = fieldElement;
	}
	public String getFieldData() {
		return fieldData;
	}
	public void setFieldData(String fieldData) {
		this.fieldData = fieldData;
	}
	
}
