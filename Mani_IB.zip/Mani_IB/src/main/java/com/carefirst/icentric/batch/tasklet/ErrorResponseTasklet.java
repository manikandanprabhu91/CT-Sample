package com.carefirst.icentric.batch.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.medrec.model.MedRecReqObj;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGapReqObj;
import com.carefirst.icentric.batch.service.EmailService;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReqObj;
import com.carefirst.icentric.batch.utils.ExcelUtils;
import com.carefirst.icentric.batch.utils.MedRecUtils;
import com.carefirst.icentric.batch.utils.RiskAdjUtils;
import com.carefirst.icentric.batch.utils.StarCareUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Error Response file processing Tasklet
 * @author aad7740
 *
 */
public class ErrorResponseTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(ErrorResponseTasklet.class);

	@Value("${medvantage.inbound.archive.path}")
	private String archivePath;

	@Autowired
	RiskAdjUtils riskAdjUtils;

	@Autowired
	StarCareUtils starCareUtils;

	@Autowired
	MedRecUtils medRecUtils;

	@Autowired
	EmailService emailService;

	@Autowired
	ExcelUtils excelUtils;

	private String categoryInd;

	private String fileName;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("> ErrorResponseTasklet beforeStep starts  >>>");
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter fileParam = jobParamMap.get("fileName");
		fileName = (String) fileParam.getValue();
		int firstIndx = fileName.indexOf(Constants.ERROR_REPORT_STR);
		int last = fileName.indexOf(Constants.DOT);
		String filename = fileName.substring(firstIndx, last);
		if(filename.contains("_mr")) {
			categoryInd = Constants.CATEGORY_IND_MR;
		} else if (filename.contains("_ra")) {
			categoryInd = Constants.CATEGORY_IND_RA;
		} else if(filename.contains("_sc")) {
			categoryInd = Constants.CATEGORY_IND_SC;
		}
		LOGGER.info("> ErrorResponseTasklet beforeStep end  >>>");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("> ErrorResponseTasklet execute method start  >>>");
		try {
			int firstIndx = fileName.indexOf(Constants.ERROR_REPORT_STR);
			int last = fileName.indexOf(Constants.DOT);
			String filename = fileName.substring(firstIndx, last);
			if(Constants.CATEGORY_IND_MR.equals(categoryInd)) {
				InputStream stream = new FileInputStream(fileName);
				MedRecReqObj medRecReqObj = new ObjectMapper().readValue(stream, MedRecReqObj.class);
				List<ErrorResponse> errorResponses = medRecUtils.medicalRecordsErrorResponse(medRecReqObj, fileName);
				if(!errorResponses.isEmpty()) {
					sendErrorResponseEmail(filename, medRecReqObj.getMedRecReq().size(), 
							errorResponses, Constants.CATEGORY_IND_MR); 
				}
				LOGGER.info(":::::MR ErrorResponse ::: () --> ");
			} else if (Constants.CATEGORY_IND_RA.equals(categoryInd)) {
				InputStream stream = new FileInputStream(fileName);
				RiskAdjGapReqObj adjGapReqObj = new ObjectMapper().readValue(stream, RiskAdjGapReqObj.class);
				List<ErrorResponse> errorResponses = riskAdjUtils.risAdjustmentErrorResponse(adjGapReqObj, fileName);
				if(!errorResponses.isEmpty()) {
					LOGGER.info(":::::RA ErrorResponse size() >>>>>>> "+errorResponses.size());
					sendErrorResponseEmail(filename, adjGapReqObj.getRiskAdjustmentGapReq().size(), 
							errorResponses, Constants.CATEGORY_IND_RA); 
				}
			} else if (Constants.CATEGORY_IND_SC.equals(categoryInd)) {
				InputStream stream = new FileInputStream(fileName);
				StarsCareGapReqObj careGapReqObj = new ObjectMapper().readValue(stream, StarsCareGapReqObj.class);
				List<ErrorResponse> errorResponses = starCareUtils.starcareErrorResponse(careGapReqObj, fileName);
				if(!errorResponses.isEmpty()) {
					sendErrorResponseEmail(filename, careGapReqObj.getStarsCareGapReq().size(), 
							errorResponses, Constants.CATEGORY_IND_SC); 
				}
				LOGGER.info(":::::SC ErrorResponse ::: () --> ");	
			}


		} catch (Exception e) {
			LOGGER.error("Error Occuring while processing the error response:::::::: " + e.getMessage());
		}


		LOGGER.info("> ErrorResponseTasklet execute method end  >>>");
		return RepeatStatus.FINISHED;
	}

	private void sendErrorResponseEmail(String filename, int totalRecords,
			List<ErrorResponse> errorResponses, String categoryInd) {
		excelUtils.getDataSource(errorResponses, filename.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING));
		emailService.sendMail(errorResponses, filename, categoryInd, totalRecords);
		String fileNamearchive = archivePath+filename.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING)+Constants.XLS;
		File file = new File(fileNamearchive);
		if(file.exists()) { 
			LOGGER.info("File deleted successfully"+file.delete()); 
		}
	}

}
