package com.carefirst.icentric.batch.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;

@Repository
public interface PexReqtJsonDtlDAO extends JpaRepository<PexReqtJsonDtl, Long>{
	
	@Query(value = "SELECT g FROM PexReqtJsonDtl g where g.pexReqtMembQueue.pexReqtMembQueueSkey=:pexReqtMembQueueSkey")
	PexReqtJsonDtl findByPexReqtMembQueueSkey(@Param("pexReqtMembQueueSkey") long pexReqtMembQueueSkey);
}
