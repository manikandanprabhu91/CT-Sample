package com.carefirst.icentric.batch.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.carefirst.icentric.batch.service.EmailService;
import com.carefirst.icentric.batch.tasklet.EmailStatusUpdateListener;
import com.carefirst.icentric.batch.tasklet.EmailStatusUpdateTasklet;

/**
 * 
 * @author aad7740
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class EmailJobConfig {
	
	private static final Logger LOGGER = LogManager.getLogger(EmailJobConfig.class);
	
	@Autowired
	private JobBuilderFactory emailJobBuilderfactory;

	@Autowired
	private StepBuilderFactory emailStepBuilderfactory;
	
	@Autowired
	EmailStatusUpdateTasklet emailTasklet;

	@Bean
	public Job emailBatchJob() {
		return emailJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB Email").incrementer(new RunIdIncrementer())
				.start(sendPendingStatusEmail()).listener(emailJobcompletionListener()).build();
	}
	
	@Bean
	public Step sendPendingStatusEmail() {
		LOGGER.info("sendEmail - step1() start/end");
		return emailStepBuilderfactory.get("step1").tasklet(emailTasklet).build();
	}
	
	@Bean
	public EmailStatusUpdateTasklet emailTasklet(EmailService emailService){
	    return new EmailStatusUpdateTasklet(emailService);
	}
	
	@Bean
	public JobExecutionListener emailJobcompletionListener() {
		return new EmailStatusUpdateListener();
	}

}
