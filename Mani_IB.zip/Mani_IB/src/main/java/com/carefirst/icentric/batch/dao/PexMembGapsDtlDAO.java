package com.carefirst.icentric.batch.dao;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.carefirst.icentric.batch.entity.PexMembGapsDtl;

@Repository
public interface PexMembGapsDtlDAO extends JpaRepository<PexMembGapsDtl, Long> {

	@Query(value = "SELECT g FROM PexMembGapsDtl g where g.gapId=:gapId and g.pexReqtMembQueue.pexReqtMembQueueSkey=:pexReqtMembQueueSkey")
	List<PexMembGapsDtl> findByGapIdAndPexReqtMembQueueSkey(@Param("gapId") BigDecimal gapId, @Param("pexReqtMembQueueSkey") long pexReqtMembQueueSkey);

	@Transactional
	@Modifying
	@Query(value = "UPDATE PCMH_RSTR.PEX_MEMB_GAPS_DTLS"
			+ " SET HST_PLN_GAP_CLS_INDC = 'ANC',"
			+ " AUD_UPDT_TMSTP = CURRENT_TIMESTAMP,"
			+ " AUD_UPDT_ID = 'SYSTEM'"
			+ " WHERE PEX_MEMB_GAPS_DTLS_SKEY IN (SELECT DISTINCT"
			+ " PMGD.PEX_MEMB_GAPS_DTLS_SKEY"
			+ " FROM PCMH_RSTR.PEX_REQT_MEMB_QUEUE PRMQ,"
			+ " PCMH_RSTR.PEX_MEMB_GAPS_DTLS PMGD"
			+ " WHERE PRMQ.PEX_REQT_MEMB_QUEUE_SKEY ="
			+ " PMGD.PEX_REQT_MEMB_QUEUE_SKEY"
			+ " AND HST_PLN_GAP_CLS_INDC IS NULL"
			+ " AND PRMQ.CPBLTY_INDC_CD IN ('RA', 'SC')"
			+ " AND 1 ="
			+ " CASE"
			+ " WHEN TRUNC (SYSDATE)"
			+ "  - TO_DATE ("
			+ " INTL_HST_PLN_DT,"
			+ " 'YYYYMMDD') > 180"
			+ " THEN"
			+ " 1"
			+ " ELSE"
			+ " 0"
			+ " END)", nativeQuery=true)
	int updateHstPlanIndcGreaterThan180Days();
	
}
