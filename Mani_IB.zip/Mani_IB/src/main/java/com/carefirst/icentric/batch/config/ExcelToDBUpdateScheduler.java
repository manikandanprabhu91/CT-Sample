package com.carefirst.icentric.batch.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.exception.ApplicationException;

@Component
public class ExcelToDBUpdateScheduler implements SchedulingConfigurer {
	

	private static final Logger LOGGER = LogManager.getLogger(ExcelToDBUpdateScheduler.class);

	private final int POOL_SIZE = 10;

	@Autowired
	private JobLauncher jobLauncherExcel;
	
	@Autowired
	private JobExplorer excelToDBExplorer;
	
	@Autowired
	ExcelToDBUpdateConfig excelToDBConfig; 

	
	@Scheduled(cron = "${excel.to.database.job.cron}")
	public void excelToDBScheduler() {
		LOGGER.info(">excelToDBBatchJob Scheduler");
		Map<String, JobParameter> jobParamMap = new HashMap<>();
		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
		JobParameters jobParams = new JobParameters(jobParamMap);
		excelToDBUpdate(jobParams);
		LOGGER.info("< excelToDBBatchJob Scheduler");
	}
	
	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		LOGGER.info("> configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		
	}
	
	private void excelToDBUpdate(JobParameters jobParams){
		LOGGER.info("> excelToDBBatchJob");
		try {
			while (true) {
				Set<org.springframework.batch.core.JobExecution> jobExecutions = excelToDBExplorer
						.findRunningJobExecutions(excelToDBConfig.excelBatchJob().getName());
				boolean runFilejob = !jobExecutions.isEmpty();
				if (runFilejob) {
					LOGGER.info("excelToDBBatchJob Job is already running waiting to restart");
					try {
						Thread.sleep(30000);
					} catch (InterruptedException e) {
						LOGGER.error("Exception Occued :" + e.getMessage(), e);
					}
				} else {
					LOGGER.info("Starting the excelToDBBatchJob job");
					break;
				}
			}
			jobLauncherExcel.run(excelToDBConfig.excelBatchJob(), jobParams);
		} catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException | JobRestartException | ApplicationException e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		} 
		LOGGER.info("< excelToDBScheduler");
	}


}
