
package com.carefirst.icentric.batch.medrec.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ServBeginDt",
    "ServEndDt"
})
public class ServRangeDts {

    @JsonProperty("ServBeginDt")
    private String servBeginDt;
    @JsonProperty("ServEndDt")
    private String servEndDt;

    /**
     * No args constructor for use in serialization
     * 
     */
    public ServRangeDts() {
    }

    /**
     * 
     * @param servEndDt
     * @param servBeginDt
     */
    public ServRangeDts(String servBeginDt, String servEndDt) {
        super();
        this.servBeginDt = servBeginDt;
        this.servEndDt = servEndDt;
    }

    @JsonProperty("ServBeginDt")
    public String getServBeginDt() {
        return servBeginDt;
    }

    @JsonProperty("ServBeginDt")
    public void setServBeginDt(String servBeginDt) {
        this.servBeginDt = servBeginDt;
    }

    @JsonProperty("ServEndDt")
    public String getServEndDt() {
        return servEndDt;
    }

    @JsonProperty("ServEndDt")
    public void setServEndDt(String servEndDt) {
        this.servEndDt = servEndDt;
    }

}
