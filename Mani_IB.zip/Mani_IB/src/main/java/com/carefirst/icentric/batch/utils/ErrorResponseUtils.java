package com.carefirst.icentric.batch.utils;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.model.ErrorResponseDto;

/**
 * This class is used to construct the error response values into individual field.
 * @author aad7740
 *
 */

@Component
public class ErrorResponseUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(ErrorResponseUtils.class);


	public List<ErrorResponseDto> getErrorResponseDetails(List<ErrorResponse> errorResponses) {

		LOGGER.info("::ErrorResponseUtils -> getErrorResponseDetails() start -->>>>:::::::: ");

		List<ErrorResponseDto> responseDtos = new ArrayList<>();

		try {

			for(ErrorResponse errorResponse : errorResponses) {
				for(int i=StringUtils.countMatches(errorResponse.getErrorDesc(), Constants.GAPID); i>0; i--){
					ErrorResponseDto dto = null;
					String errordesc = errorResponse.getErrorDesc();
					String gapId = Constants.GAPID + Integer.valueOf(i).toString();
					String riskAdjGapType = Constants.RISKADJGAPTYPE + Integer.valueOf(i).toString();
					String missingDiagCd = Constants.MISSINGDIAGCD + Integer.valueOf(i).toString();
					String missingDiagCdDesc = Constants.MISSINGDIAGCDDESC + Integer.valueOf(i).toString();
					String missingHCCCd = Constants.MISSINGHCCCD + Integer.valueOf(i).toString();
					String missingHCCCdDesc = Constants.MISSINGHCCCDDESC + Integer.valueOf(i).toString();
					String gapIdentificationRationale = Constants.GAPIDENTIFICATIONRATIONALE + Integer.valueOf(i).toString();
					String prospRetrospId = Constants.PROSPRETROSPID + Integer.valueOf(i).toString();
					String requestedAction = Constants.REQUESTEDACTION + Integer.valueOf(i).toString();
					String homePlanGaplvlClsrInd = Constants.HOMEPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
					String infoRcvdtocloseGap = Constants.INFORCVDTOCLOSEGAP + Integer.valueOf(i).toString();
					String gapClsrSCCFId = Constants.GAPCLSRSCCFID + Integer.valueOf(i).toString();
					String clsrSFReceiptDt = Constants.CLSRSFRECEIPTDT + Integer.valueOf(i).toString();
					String hostPlanGaplvlClsrInd = Constants.HOSTPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
					String missingDiagCdServDt = Constants.MISSINGDIAGCDSERVDT + Integer.valueOf(i).toString();

					if(errordesc.contains(gapId)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(gapId+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(gapId+" (")+gapId.length(), lastIdex+1));
						dto.setFieldElement(gapId);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(riskAdjGapType)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(riskAdjGapType+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(riskAdjGapType+" (")+riskAdjGapType.length(), lastIdex+1));
						dto.setFieldElement(riskAdjGapType);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(missingDiagCd)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(missingDiagCd+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(missingDiagCd+" (")+missingDiagCd.length(), lastIdex+1));
						dto.setFieldElement(missingDiagCd);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(missingDiagCdDesc)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(missingDiagCdDesc+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(missingDiagCdDesc+" (")+missingDiagCdDesc.length(), lastIdex+1));
						dto.setFieldElement(missingDiagCdDesc);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(missingHCCCd)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(missingHCCCd+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(missingHCCCd+" (")+missingHCCCd.length(), lastIdex+1));
						dto.setFieldElement(missingHCCCd);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(missingHCCCdDesc)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(missingHCCCdDesc+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(missingHCCCdDesc+" (")+missingHCCCdDesc.length(), lastIdex+1));
						dto.setFieldElement(missingHCCCdDesc);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(gapIdentificationRationale)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(gapIdentificationRationale+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(gapIdentificationRationale+" (")+gapIdentificationRationale.length(), lastIdex+1));
						dto.setFieldElement(gapIdentificationRationale);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(prospRetrospId)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(prospRetrospId+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(prospRetrospId+" (")+prospRetrospId.length(), lastIdex+1));
						dto.setFieldElement(prospRetrospId);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(requestedAction)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(requestedAction+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(requestedAction+" (")+requestedAction.length(), lastIdex+1));
						dto.setFieldElement(requestedAction);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(homePlanGaplvlClsrInd)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(homePlanGaplvlClsrInd+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(homePlanGaplvlClsrInd+" (")+homePlanGaplvlClsrInd.length(), lastIdex+1));
						dto.setFieldElement(homePlanGaplvlClsrInd);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}

					if(errordesc.contains(infoRcvdtocloseGap)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(infoRcvdtocloseGap+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(infoRcvdtocloseGap+" (")+infoRcvdtocloseGap.length(), lastIdex+1));
						dto.setFieldElement(infoRcvdtocloseGap);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(gapClsrSCCFId)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(gapClsrSCCFId+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(gapClsrSCCFId+" (")+gapClsrSCCFId.length(), lastIdex+1));
						dto.setFieldElement(gapClsrSCCFId);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(clsrSFReceiptDt)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(clsrSFReceiptDt+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(clsrSFReceiptDt+" (")+clsrSFReceiptDt.length(), lastIdex+1));
						dto.setFieldElement(clsrSFReceiptDt);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(hostPlanGaplvlClsrInd)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(hostPlanGaplvlClsrInd+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(hostPlanGaplvlClsrInd+" (")+hostPlanGaplvlClsrInd.length(), lastIdex+1));
						dto.setFieldElement(hostPlanGaplvlClsrInd);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
					if(errordesc.contains(missingDiagCdServDt)) {
						dto = new ErrorResponseDto();
						dto.setGapId(Integer.valueOf(i).toString());
						int index = errordesc.indexOf(missingDiagCdServDt+" (");
						String error = errordesc.substring(index);
						int lastIdex = error.indexOf(")");
						dto.setErrCode(errorResponse.getErrorCode());
						dto.setFieldData(error.substring(error.indexOf(missingDiagCdServDt+" (")+missingDiagCdServDt.length(), lastIdex+1));
						dto.setFieldElement(missingDiagCdServDt);
						dto.setHomePlanStatus(errorResponse.getHomePlanStatus());
						dto.setHostPlanStatus(errorResponse.getHostPlanStatus());
						dto.setProviderEngagementID(errorResponse.getProviderEngagementID());
						responseDtos.add(dto);
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error("::ErrorResponseUtils -> getErrorResponseDetails() :::::::Error Occuring ::: -->>>>:::::::: "+e.getMessage());
		}

		LOGGER.info("::ErrorResponseUtils -> getErrorResponseDetails() end -->>>>:::::::: ");
		return responseDtos;
	}

	public String errorCodeAndDescForRA(String errorDesc) {
		String errordesc = errorCodeAndDescForMR(errorDesc);
		if(errordesc.isEmpty()) {
			for(int i=StringUtils.countMatches(errorDesc, Constants.GAPID); i>0; i--){
				if(errorDesc.contains(Constants.GAPID)) {
					errordesc = Constants.GAPID + Integer.valueOf(i).toString();	
				} else if(errorDesc.contains(Constants.RISKADJGAPTYPE)) {
					errordesc = Constants.RISKADJGAPTYPE + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.MISSINGDIAGCD)) {
					errordesc = Constants.MISSINGDIAGCD + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.MISSINGDIAGCDDESC)) {
					errordesc = Constants.MISSINGDIAGCDDESC + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.MISSINGHCCCD)) {
					errordesc = Constants.MISSINGHCCCD + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.MISSINGHCCCDDESC)) {
					errordesc = Constants.MISSINGHCCCDDESC + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.GAPIDENTIFICATIONRATIONALE)) {
					errordesc = Constants.GAPIDENTIFICATIONRATIONALE + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.PROSPRETROSPID)) {
					errordesc = Constants.PROSPRETROSPID + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.REQUESTEDACTION)) {
					errordesc = Constants.REQUESTEDACTION + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.HOMEPLANGAPLVLCLSRIND)) {
					errordesc = Constants.HOMEPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.INFORCVDTOCLOSEGAP)) {
					errordesc = Constants.INFORCVDTOCLOSEGAP + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.GAPCLSRSCCFID)) {
					errordesc = Constants.GAPCLSRSCCFID + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.CLSRSFRECEIPTDT)) {
					errordesc = Constants.CLSRSFRECEIPTDT + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.HOSTPLANGAPLVLCLSRIND)) {
					errordesc = Constants.HOSTPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.MISSINGDIAGCDSERVDT)) {
					errordesc = Constants.MISSINGDIAGCDSERVDT + Integer.valueOf(i).toString();
				}
			}
		}
		return errordesc;
	}

	public String errorCodeAndDescForSC(String errorDesc) {
		String errordesc = errorCodeAndDescForMR(errorDesc);
		if(errordesc.isEmpty()) {
			for(int i=StringUtils.countMatches(errorDesc, Constants.GAPID); i>0; i--){
				if(errorDesc.contains(Constants.GAPID)) {
					errordesc = Constants.GAPID + Integer.valueOf(i).toString();	
				} else if(errorDesc.contains(Constants.GAPMEASURE)) {
					errordesc = Constants.GAPMEASURE + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.GAPIDENTIFICATIONRATIONALE)) {
					errordesc = Constants.GAPIDENTIFICATIONRATIONALE + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.PROSPRETROSPID)) {
					errordesc = Constants.PROSPRETROSPID + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.REQUESTEDACTION)) {
					errordesc = Constants.REQUESTEDACTION + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.ADDLINFOTOHOSTPLAN)) {
					errordesc = Constants.ADDLINFOTOHOSTPLAN + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.HOMEPLANGAPLVLCLSRIND)) {
					errordesc = Constants.HOMEPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.INFORCVDTOCLOSEGAP)) {
					errordesc = Constants.INFORCVDTOCLOSEGAP + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.GAPCLSRSCCFID)) {
					errordesc = Constants.GAPCLSRSCCFID + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.CLSRSFRECEIPTDT)) {
					errordesc = Constants.CLSRSFRECEIPTDT + Integer.valueOf(i).toString();
				} else if(errorDesc.contains(Constants.HOSTPLANGAPLVLCLSRIND)) {
					errordesc = Constants.HOSTPLANGAPLVLCLSRIND + Integer.valueOf(i).toString();
				}  

			}
		}
		return errordesc;
	}

	public String errorCodeAndDescForMR(String errorDesc) {
		String errordesc = "";
		if(errorDesc.contains(Constants.MEMBERHOSTPLANID)) {
			errordesc = Constants.MEMBERHOSTPLANID;
		} else if(errorDesc.contains(Constants.ROUTETOHOSTPLANID)) {
			errordesc = Constants.ROUTETOHOSTPLANID;
		} else if(errorDesc.contains(Constants.LASTMRRPROVENGMNTREQID)) {
			errordesc = Constants.LASTMRRPROVENGMNTREQID;
		} else if(errorDesc.contains(Constants.HOMEPLANID)) {
			errordesc = Constants.HOMEPLANID;
		} else if(errorDesc.contains(Constants.LASTMEDRECREQRCPTDT)) {
			errordesc = Constants.LASTMEDRECREQRCPTDT;
		} else if(errorDesc.contains(Constants.ITSSUBSCRIBERID)) {
			errordesc = Constants.ITSSUBSCRIBERID;
		} else if(errorDesc.contains(Constants.MEMBERDOB)) {
			errordesc = Constants.MEMBERDOB;
		} else if(errorDesc.contains(Constants.MMIID)) {
			errordesc = Constants.MMIID;
		} else if(errorDesc.contains(Constants.MEMBERFULLNAME)) {
			errordesc = Constants.MEMBERFULLNAME;
		} else if(errorDesc.contains(Constants.MEMBERGENDER)) {
			errordesc = Constants.MEMBERGENDER;
		} else if(errorDesc.contains(Constants.NUMOFGAPCLOSURES)) {
			errordesc = Constants.NUMOFGAPCLOSURES;
		} else if(errorDesc.contains(Constants.BILLPROVPROPRIETARYID)) {
			errordesc = Constants.BILLPROVPROPRIETARYID;
		} else if(errorDesc.contains(Constants.BILLPROVNPI)) {
			errordesc = Constants.BILLPROVNPI;
		} else if(errorDesc.contains(Constants.RNDRNGPROVNPI)) {
			errordesc = Constants.RNDRNGPROVNPI;
		} else if(errorDesc.contains(Constants.RNDRNGPROVHOSTPLANID)) {
			errordesc = Constants.RNDRNGPROVHOSTPLANID;
		} else if(errorDesc.contains(Constants.BILLPROVZIPCODE)) {
			errordesc = Constants.BILLPROVZIPCODE;
		} else if(errorDesc.contains(Constants.RNDRNGPROVZIPCODE)) {
			errordesc = Constants.RNDRNGPROVZIPCODE;
		} else if(errorDesc.contains(Constants.RNDRNGPROVTXNMYCD)) {
			errordesc = Constants.RNDRNGPROVTXNMYCD;
		} else if(errorDesc.contains(Constants.SCCFIDS)) {
			errordesc = Constants.SCCFIDS;
		} else if(errorDesc.contains(Constants.PRESENTDIAGNOSES)) {
			errordesc = Constants.PRESENTDIAGNOSES;
		} else if(errorDesc.contains(Constants.CURRENTDIAGNOSESRNDRNGPROVNPI)) {
			errordesc = Constants.CURRENTDIAGNOSESRNDRNGPROVNPI;
		} else if(errorDesc.contains(Constants.PROVENGAGEMENTIND)) {
			errordesc = Constants.PROVENGAGEMENTIND;
		} else if(errorDesc.contains(Constants.PROVCNTRCTINGSTS)) {
			errordesc = Constants.PROVCNTRCTINGSTS;
		} else if(errorDesc.contains(Constants.MEMBERHOSTPLANID)) {
			errordesc = Constants.MEMBERHOSTPLANID;
		} else if(errorDesc.contains(Constants.ROUTETOHOSTPLANID)) {
			errordesc = Constants.ROUTETOHOSTPLANID;
		}
		return errordesc;
	}

}
