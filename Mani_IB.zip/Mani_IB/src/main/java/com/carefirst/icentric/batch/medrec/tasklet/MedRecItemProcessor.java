package com.carefirst.icentric.batch.medrec.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.medrec.model.MedRecReq;

@Component("MedRecItemProcessor")
@StepScope
public class MedRecItemProcessor implements ItemProcessor<MedRecReq, MedRecReq> {

	private static final Logger LOGGER = LogManager.getLogger(MedRecItemProcessor.class);
	
	@Override
	public MedRecReq process(final MedRecReq record) throws Exception {
		LOGGER.info(" Enter MedRecItemProcessor record processor" );
		
		return record;
	}
}