package com.carefirst.icentric.batch.PCMHFlagUpdate.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;


@Component
public class PCMHFlagUpdateJobCompletionListener extends JobExecutionListenerSupport {
	private static final Logger LOGGER = LogManager.getLogger(PCMHFlagUpdateJobCompletionListener.class);
	
	@Override
	public void afterJob(JobExecution jobExecution) {

		String completionContent = "The job " + jobExecution.getJobInstance().getJobName()+" completed updating pcmh flags.";
		LOGGER.info(completionContent);
	}
	
	

}
