//package com.carefirst.icentric.batch.PCMHFlagUpdate.tasklet;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.batch.core.configuration.annotation.StepScope;
//import org.springframework.batch.item.ItemProcessor;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
//import com.carefirst.icentric.batch.pdm.dao.VwPcpReltpDAO;
//
//@Component("PCMHFlagUpdateItemProcessor")
//@StepScope
//public class PCMHFlagUpdateItemProcessor implements ItemProcessor<PexReqtMembQueue, PexReqtMembQueue> {
//
//	private static final Logger LOGGER = LogManager.getLogger(PCMHFlagUpdateItemProcessor.class);
//	
//	@Autowired
//	VwPcpReltpDAO vwPcpReltpDAO;
//	
//	@Override
//	public PexReqtMembQueue process(final PexReqtMembQueue record) throws Exception {
//		LOGGER.info(" Enter PCMHFlagUpdateItemProcessor record processor" );
//		
//		//do lookup and update the pcmh flag
//		String provid = record.getRndrProvId();
//		if(0!=vwPcpReltpDAO.getMedlPanlId(provid)){
//			record.setPcmhIndicator(1);
//		}else{
//			record.setPcmhIndicator(0);
//		}
//		return record;
//	}
//}