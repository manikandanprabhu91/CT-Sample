package com.carefirst.icentric.batch.riskadj.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.riskadj.model.RiskAdjustmentGapReq;

@Component("RiskAdjItemProcessor")
@StepScope
public class RiskAdjItemProcessor implements ItemProcessor<RiskAdjustmentGapReq, RiskAdjustmentGapReq> {

	private static final Logger LOGGER = LogManager.getLogger(RiskAdjItemProcessor.class);
	
	@Override
	public RiskAdjustmentGapReq process(final RiskAdjustmentGapReq record) throws Exception {
		LOGGER.info(" Enter RiskAdjGapReq record Processor");
		
		return record;
	}
}