package com.carefirst.icentric.batch.medrec.tasklet;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.medrec.model.MedRecReq;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MedRecItemWriter implements ItemWriter<MedRecReq> {

	private static final Logger LOGGER = LogManager.getLogger(MedRecItemWriter.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	private FileUtils fileUtil;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	String fileName;

	@Autowired
	ProvSearch provSearch;
	
	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;

	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("medRecFileName");
		String filePath = (String) param.getValue();
		fileName = filePath.replaceAll(fileUtil.getInBoundPath(), "");
	}

	@Override
	public void write(List<? extends MedRecReq> items) throws Exception {
		LOGGER.info(" Entering MedRecItemWriter");
		try {
			for (MedRecReq medRecpReq : items) {

				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO.findByProvEngmtReqtId(medRecpReq.getProvEngmntReqId());
				if(pexReqtMembQueueList.isEmpty()){
					pexReqtMembQueue = setJsonPojoToEntityClass(medRecpReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				}else{
					updatePexTableColumns(medRecpReq, pexReqtMembQueueList);
					updatePexReqtJsonDetails(medRecpReq, pexReqtMembQueueList);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception found while reading the response:: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		LOGGER.info(" Exiting MedRecItemWriter");
	}

	private void updatePexTableColumns(MedRecReq medRecpReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);

		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setMembHstPlnId(medRecpReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(medRecpReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(medRecpReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(medRecpReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMembDob(medRecpReq.getMemberDOB());
		pexReqtMembQueue.setRndrProvZipCd(medRecpReq.getRndrngProvZipCode());
		pexReqtMembQueue.setHmPlanClsInd(medRecpReq.getHomePlanClsrInd());
		pexReqtMembQueue.setMedRecMtchIndc(medRecpReq.getHostPlanMedRecMatchInd());
		pexReqtMembQueue.setHstPlnClsInd(medRecpReq.getHostPlanClsrInd());		
		
		String[] clsInd = Constants.CLSR_IND;
		if(Arrays.asList(clsInd).contains(medRecpReq.getHomePlanClsrInd())){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}

		pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
	}

	private PexReqtMembQueue setJsonPojoToEntityClass(MedRecReq medRecpReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(medRecpReq, pexReqtMembQueue);
		setPexReqtJsonDetails(medRecpReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	private void setPexReqtMembQueueData(MedRecReq medRecpReq, PexReqtMembQueue pexReqtMembQueue) throws Exception {

		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setProvEngmtReqtId(medRecpReq.getProvEngmntReqId());
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setCpbltyIndcCd(medRecpReq.getCapabilityInd());
		pexReqtMembQueue.setMedRecTypCd(medRecpReq.getMedRecReqType());
		pexReqtMembQueue.setHmPlanId(medRecpReq.getHomePlanId());
		pexReqtMembQueue.setMembHstPlnId(medRecpReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(medRecpReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(medRecpReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(medRecpReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setItsSubscrId(medRecpReq.getITSSubscriberId());
		pexReqtMembQueue.setMembDob(medRecpReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(medRecpReq.getMMIId());
		// pexReqtMembQueue.setMembFrstNm(riskAdjGapReq.getMemberFullName());
		// //need to set first name
		// pexReqtMembQueue.setMembLastNm(riskAdjGapReq.getMemberFullName());
		// //need to set last name
		pexReqtMembQueue.setMembFullNm(medRecpReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(medRecpReq.getMemberGender());
		// pexReqtMembQueue.setCloseGapCnt(new
		// BigDecimal(medRecpReq.getNumofGapClosures()));
		pexReqtMembQueue.setBillProvId(medRecpReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(medRecpReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setBillProvNpi(medRecpReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(medRecpReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(medRecpReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(medRecpReq.getBillProvZipCode());
		pexReqtMembQueue.setRndrProvZipCd(medRecpReq.getRndrngProvZipCode());
		pexReqtMembQueue.setRndrProvTaxId(medRecpReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setSccfId(medRecpReq.getSCCFIds());
		// pexReqtMembQueue.setPrevGapClsProv(riskAdjGapReq.getGapPrevouslyClosedByThisProv());
		// pexReqtMembQueue.setPrsntDiag(medRecpReq.getPresentDiagnoses());
		// pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(medRecpReq.getCurrentDiagnosesRndrngProvNPI()));
		pexReqtMembQueue.setProvEngmtIndc(medRecpReq.getProvEngagementInd());
		pexReqtMembQueue.setProvPartStus(medRecpReq.getProvCntrctingSts());
		pexReqtMembQueue.setMedRecMtchIndc(medRecpReq.getHostPlanMedRecMatchInd());
		pexReqtMembQueue.setHstPlnClsInd(medRecpReq.getHostPlanClsrInd());
		// pexReqtMembQueue.setReqtStusTyp(reqtStusTyp);
		// pexReqtMembQueue.setReqtStusCd(reqtStusCd);
		pexReqtMembQueue.setServcBegDt(medRecpReq.getServRangeDts().getServBeginDt());
		pexReqtMembQueue.setServcEndDt(medRecpReq.getServRangeDts().getServEndDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setProvPlnCd(medRecpReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(medRecpReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(medRecpReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(medRecpReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(medRecpReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setHmPlanClsInd(medRecpReq.getHomePlanClsrInd());
		
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);
		String[] clsInd = Constants.CLSR_IND;
		if(Arrays.asList(clsInd).contains(medRecpReq.getHomePlanClsrInd())){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}

		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(medRecpReq.getRndrngProvProprietaryId(), pexReqtMembQueue);
	}

	private void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch
					.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber ::::::::: "
									+ practitioner.getPractitionerFirstName() + ", "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderName::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerLastName() + ", "
									+ practitioner.getPractitionerFirstName());
							// pexReqtMembQueue.setRndrProvZipCd(practitioner.getPractitionerZip());
							// pexReqtMembQueue.setRndrProvNpi(practitioner.getPractitionerNPI());
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	private void setPexReqtJsonDetails(MedRecReq medRecpReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String medRecReqJson = mapper.writeValueAsString(medRecpReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(medRecReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}
	
	private void updatePexReqtJsonDetails(MedRecReq medRecpReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			MedRecReq readValue = objectMapper.readValue(reqtJson, MedRecReq.class);
			readValue.setMemberHostPlanId(medRecpReq.getMemberHostPlanId());
			readValue.setRoutetoHostPlanId(medRecpReq.getRoutetoHostPlanId());
			readValue.setFirstTimeSenttoHostPlanDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(medRecpReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(medRecpReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(medRecpReq.getMemberDOB());
			readValue.setRndrngProvZipCode(medRecpReq.getRndrngProvZipCode());
			readValue.setHomePlanClsrInd(medRecpReq.getHomePlanClsrInd());
			readValue.setHostPlanMedRecMatchInd(medRecpReq.getHostPlanMedRecMatchInd());
			readValue.setHostPlanClsrInd(medRecpReq.getHostPlanClsrInd());	
			
			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
