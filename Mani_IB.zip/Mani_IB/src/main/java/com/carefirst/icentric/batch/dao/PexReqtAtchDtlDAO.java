package com.carefirst.icentric.batch.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carefirst.icentric.batch.entity.PexReqtAtchDtl;

@Repository
public interface PexReqtAtchDtlDAO  extends JpaRepository<PexReqtAtchDtl, Long>{

}
