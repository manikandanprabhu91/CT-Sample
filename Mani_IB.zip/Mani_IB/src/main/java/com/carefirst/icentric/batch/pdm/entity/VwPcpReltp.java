package com.carefirst.icentric.batch.pdm.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.jpa.domain.AbstractPersistable;
/**
 * The persistent class for the VW_PCP_RELTP database table.
 * 
 */
@Entity
@Table(name="VW_PCP_RELTP",schema="PDM_PANL")
@NamedQuery(name="VwPcpReltp.findAll", query="SELECT v FROM VwPcpReltp v")
public class VwPcpReltp  extends AbstractPersistable<Long> implements Serializable{
	
	
	
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="BUS_EFFT_FROM_DT")
	private Date busEfftFromDt;

	@Temporal(TemporalType.DATE)
	@Column(name="BUS_EFFT_THRU_DT")
	private Date busEfftThruDt;

	@Temporal(TemporalType.DATE)
	@Column(name="LCC_ASSC_LAST_UPDTD_DT")
	private Date lccAsscLastUpdtdDt;

	@Column(name="LCC_AUD_UPDT_TMSTP")
	private Timestamp lccAudUpdtTmstp;

	@Column(name="LCC_MAPPED_TYPE")
	private String lccMappedType;

	@Column(name="LCC_USER_ID")
	private String lccUserId;

	@Column(name="LCC_USER_KEY")
	private BigDecimal lccUserKey;

	@Column(name="LCC_USER_NM")
	private String lccUserNm;

	@Column(name="LCC_USER_NOTES_TXT")
	private String lccUserNotesTxt;

	@Column(name="MAP_UPDATED_USER")
	private String mapUpdatedUser;

	@Temporal(TemporalType.DATE)
	@Column(name="MEDL_PANL_EFFT_DT")
	private Date medlPanlEfftDt;

	@Column(name="MEDL_PANL_ID")
	private String medlPanlId;

	@Temporal(TemporalType.DATE)
	@Column(name="MEDL_PANL_TERM_DT")
	private Date medlPanlTermDt;

	@Column(name="ORGN_NM")
	private String orgnNm;

	@Column(name="PROV_ADDR")
	private String provAddr;

	@Column(name="PROV_CITY")
	private String provCity;

	@Column(name="PROV_CNTY_NM")
	private String provCntyNm;

	@Temporal(TemporalType.DATE)
	@Column(name="PROV_EFFT_DT")
	private Date provEfftDt;

	@Column(name="PROV_EMAL_ADDR")
	private String provEmalAddr;

	@Temporal(TemporalType.DATE)
	@Column(name="PROV_ENT_ASSC_EFFT_DT")
	private Date provEntAsscEfftDt;

	@Temporal(TemporalType.DATE)
	@Column(name="PROV_ENT_ASSC_TERM_DT")
	private Date provEntAsscTermDt;

	@Column(name="PROV_FAX")
	private String provFax;

	@Column(name="PROV_ID")
	private String provId;

	@Column(name="PROV_MEDL_PANL_ENT_ID")
	private String provMedlPanlEntId;

	@Column(name="PROV_NM")
	private String provNm;

	@Column(name="PROV_NPI")
	private BigDecimal provNpi;

	@Column(name="PROV_PHON_NBR")
	private String provPhonNbr;

	@Column(name="PROV_SKEY")
	private BigDecimal provSkey;

	@Column(name="PROV_SPCLTY_CD")
	private String provSpcltyCd;

	@Column(name="PROV_SPCLTY_DESC")
	private String provSpcltyDesc;

	@Column(name="PROV_STATE")
	private String provState;

	@Temporal(TemporalType.DATE)
	@Column(name="PROV_TERM_DT")
	private Date provTermDt;

	@Column(name="PROV_ZIP")
	private String provZip;

	@Column(name="PTNR_ADDR")
	private String ptnrAddr;

	@Column(name="PTNR_AFILN_SKEY")
	private BigDecimal ptnrAfilnSkey;

	@Column(name="PTNR_APPLN_ID")
	private String ptnrApplnId;

	@Column(name="PTNR_CITY")
	private String ptnrCity;

	@Column(name="PTNR_CNTY_NM")
	private String ptnrCntyNm;

	@Column(name="PTNR_EMAL_ADDR")
	private String ptnrEmalAddr;

	@Column(name="PTNR_FAX")
	private String ptnrFax;

	@Column(name="PTNR_FIRST_NM")
	private String ptnrFirstNm;

	@Column(name="PTNR_ID")
	private String ptnrId;

	@Column(name="PTNR_LAST_NM")
	private String ptnrLastNm;

	@Temporal(TemporalType.DATE)
	@Column(name="PTNR_MEDL_PANL_ASSC_EFFT_DT")
	private Date ptnrMedlPanlAsscEfftDt;

	@Temporal(TemporalType.DATE)
	@Column(name="PTNR_MEDL_PANL_ASSC_TERM_DT")
	private Date ptnrMedlPanlAsscTermDt;

	@Column(name="PTNR_MID_NM")
	private String ptnrMidNm;

	@Column(name="PTNR_NM")
	private String ptnrNm;

	@Column(name="PTNR_NPI")
	private BigDecimal ptnrNpi;

	@Column(name="PTNR_PHON_NBR")
	private String ptnrPhonNbr;

	@Column(name="PTNR_SPCLTY_CD")
	private String ptnrSpcltyCd;

	@Column(name="PTNR_SPCLTY_DESC")
	private String ptnrSpcltyDesc;

	@Column(name="PTNR_STATE")
	private String ptnrState;

	@Column(name="PTNR_TITLE")
	private String ptnrTitle;

	@Column(name="PTNR_ZIP")
	private String ptnrZip;

	@Column(name="RCC_USER_ID")
	private String rccUserId;

	@Column(name="RCC_USER_KEY")
	private BigDecimal rccUserKey;

	@Column(name="RCC_USER_NM")
	private String rccUserNm;

	@Column(name="REGION_ID")
	private String regionId;

	@Column(name="REGION_NM")
	private String regionNm;

	@Temporal(TemporalType.DATE)
	@Column(name="TAX_ENT_EFFT_DT")
	private Date taxEntEfftDt;

	@Temporal(TemporalType.DATE)
	@Column(name="TAX_ENT_TERM_DT")
	private Date taxEntTermDt;

	@Column(name="TAX_ID")
	private String taxId;

	@Column(name="USER_ROLE")
	private String userRole;

	public VwPcpReltp() {
	}

	public Date getBusEfftFromDt() {
		return this.busEfftFromDt;
	}

	public void setBusEfftFromDt(Date busEfftFromDt) {
		this.busEfftFromDt = busEfftFromDt;
	}

	public Date getBusEfftThruDt() {
		return this.busEfftThruDt;
	}

	public void setBusEfftThruDt(Date busEfftThruDt) {
		this.busEfftThruDt = busEfftThruDt;
	}

	public Date getLccAsscLastUpdtdDt() {
		return this.lccAsscLastUpdtdDt;
	}

	public void setLccAsscLastUpdtdDt(Date lccAsscLastUpdtdDt) {
		this.lccAsscLastUpdtdDt = lccAsscLastUpdtdDt;
	}

	public Timestamp getLccAudUpdtTmstp() {
		return this.lccAudUpdtTmstp;
	}

	public void setLccAudUpdtTmstp(Timestamp lccAudUpdtTmstp) {
		this.lccAudUpdtTmstp = lccAudUpdtTmstp;
	}

	public String getLccMappedType() {
		return this.lccMappedType;
	}

	public void setLccMappedType(String lccMappedType) {
		this.lccMappedType = lccMappedType;
	}

	public String getLccUserId() {
		return this.lccUserId;
	}

	public void setLccUserId(String lccUserId) {
		this.lccUserId = lccUserId;
	}

	public BigDecimal getLccUserKey() {
		return this.lccUserKey;
	}

	public void setLccUserKey(BigDecimal lccUserKey) {
		this.lccUserKey = lccUserKey;
	}

	public String getLccUserNm() {
		return this.lccUserNm;
	}

	public void setLccUserNm(String lccUserNm) {
		this.lccUserNm = lccUserNm;
	}

	public String getLccUserNotesTxt() {
		return this.lccUserNotesTxt;
	}

	public void setLccUserNotesTxt(String lccUserNotesTxt) {
		this.lccUserNotesTxt = lccUserNotesTxt;
	}

	public String getMapUpdatedUser() {
		return this.mapUpdatedUser;
	}

	public void setMapUpdatedUser(String mapUpdatedUser) {
		this.mapUpdatedUser = mapUpdatedUser;
	}

	public Date getMedlPanlEfftDt() {
		return this.medlPanlEfftDt;
	}

	public void setMedlPanlEfftDt(Date medlPanlEfftDt) {
		this.medlPanlEfftDt = medlPanlEfftDt;
	}

	public String getMedlPanlId() {
		return this.medlPanlId;
	}

	public void setMedlPanlId(String medlPanlId) {
		this.medlPanlId = medlPanlId;
	}

	public Date getMedlPanlTermDt() {
		return this.medlPanlTermDt;
	}

	public void setMedlPanlTermDt(Date medlPanlTermDt) {
		this.medlPanlTermDt = medlPanlTermDt;
	}

	public String getOrgnNm() {
		return this.orgnNm;
	}

	public void setOrgnNm(String orgnNm) {
		this.orgnNm = orgnNm;
	}

	public String getProvAddr() {
		return this.provAddr;
	}

	public void setProvAddr(String provAddr) {
		this.provAddr = provAddr;
	}

	public String getProvCity() {
		return this.provCity;
	}

	public void setProvCity(String provCity) {
		this.provCity = provCity;
	}

	public String getProvCntyNm() {
		return this.provCntyNm;
	}

	public void setProvCntyNm(String provCntyNm) {
		this.provCntyNm = provCntyNm;
	}

	public Date getProvEfftDt() {
		return this.provEfftDt;
	}

	public void setProvEfftDt(Date provEfftDt) {
		this.provEfftDt = provEfftDt;
	}

	public String getProvEmalAddr() {
		return this.provEmalAddr;
	}

	public void setProvEmalAddr(String provEmalAddr) {
		this.provEmalAddr = provEmalAddr;
	}

	public Date getProvEntAsscEfftDt() {
		return this.provEntAsscEfftDt;
	}

	public void setProvEntAsscEfftDt(Date provEntAsscEfftDt) {
		this.provEntAsscEfftDt = provEntAsscEfftDt;
	}

	public Date getProvEntAsscTermDt() {
		return this.provEntAsscTermDt;
	}

	public void setProvEntAsscTermDt(Date provEntAsscTermDt) {
		this.provEntAsscTermDt = provEntAsscTermDt;
	}

	public String getProvFax() {
		return this.provFax;
	}

	public void setProvFax(String provFax) {
		this.provFax = provFax;
	}

	public String getProvId() {
		return this.provId;
	}

	public void setProvId(String provId) {
		this.provId = provId;
	}

	public String getProvMedlPanlEntId() {
		return this.provMedlPanlEntId;
	}

	public void setProvMedlPanlEntId(String provMedlPanlEntId) {
		this.provMedlPanlEntId = provMedlPanlEntId;
	}

	public String getProvNm() {
		return this.provNm;
	}

	public void setProvNm(String provNm) {
		this.provNm = provNm;
	}

	public BigDecimal getProvNpi() {
		return this.provNpi;
	}

	public void setProvNpi(BigDecimal provNpi) {
		this.provNpi = provNpi;
	}

	public String getProvPhonNbr() {
		return this.provPhonNbr;
	}

	public void setProvPhonNbr(String provPhonNbr) {
		this.provPhonNbr = provPhonNbr;
	}

	public BigDecimal getProvSkey() {
		return this.provSkey;
	}

	public void setProvSkey(BigDecimal provSkey) {
		this.provSkey = provSkey;
	}

	public String getProvSpcltyCd() {
		return this.provSpcltyCd;
	}

	public void setProvSpcltyCd(String provSpcltyCd) {
		this.provSpcltyCd = provSpcltyCd;
	}

	public String getProvSpcltyDesc() {
		return this.provSpcltyDesc;
	}

	public void setProvSpcltyDesc(String provSpcltyDesc) {
		this.provSpcltyDesc = provSpcltyDesc;
	}

	public String getProvState() {
		return this.provState;
	}

	public void setProvState(String provState) {
		this.provState = provState;
	}

	public Date getProvTermDt() {
		return this.provTermDt;
	}

	public void setProvTermDt(Date provTermDt) {
		this.provTermDt = provTermDt;
	}

	public String getProvZip() {
		return this.provZip;
	}

	public void setProvZip(String provZip) {
		this.provZip = provZip;
	}

	public String getPtnrAddr() {
		return this.ptnrAddr;
	}

	public void setPtnrAddr(String ptnrAddr) {
		this.ptnrAddr = ptnrAddr;
	}

	public BigDecimal getPtnrAfilnSkey() {
		return this.ptnrAfilnSkey;
	}

	public void setPtnrAfilnSkey(BigDecimal ptnrAfilnSkey) {
		this.ptnrAfilnSkey = ptnrAfilnSkey;
	}

	public String getPtnrApplnId() {
		return this.ptnrApplnId;
	}

	public void setPtnrApplnId(String ptnrApplnId) {
		this.ptnrApplnId = ptnrApplnId;
	}

	public String getPtnrCity() {
		return this.ptnrCity;
	}

	public void setPtnrCity(String ptnrCity) {
		this.ptnrCity = ptnrCity;
	}

	public String getPtnrCntyNm() {
		return this.ptnrCntyNm;
	}

	public void setPtnrCntyNm(String ptnrCntyNm) {
		this.ptnrCntyNm = ptnrCntyNm;
	}

	public String getPtnrEmalAddr() {
		return this.ptnrEmalAddr;
	}

	public void setPtnrEmalAddr(String ptnrEmalAddr) {
		this.ptnrEmalAddr = ptnrEmalAddr;
	}

	public String getPtnrFax() {
		return this.ptnrFax;
	}

	public void setPtnrFax(String ptnrFax) {
		this.ptnrFax = ptnrFax;
	}

	public String getPtnrFirstNm() {
		return this.ptnrFirstNm;
	}

	public void setPtnrFirstNm(String ptnrFirstNm) {
		this.ptnrFirstNm = ptnrFirstNm;
	}

	public String getPtnrId() {
		return this.ptnrId;
	}

	public void setPtnrId(String ptnrId) {
		this.ptnrId = ptnrId;
	}

	public String getPtnrLastNm() {
		return this.ptnrLastNm;
	}

	public void setPtnrLastNm(String ptnrLastNm) {
		this.ptnrLastNm = ptnrLastNm;
	}

	public Date getPtnrMedlPanlAsscEfftDt() {
		return this.ptnrMedlPanlAsscEfftDt;
	}

	public void setPtnrMedlPanlAsscEfftDt(Date ptnrMedlPanlAsscEfftDt) {
		this.ptnrMedlPanlAsscEfftDt = ptnrMedlPanlAsscEfftDt;
	}

	public Date getPtnrMedlPanlAsscTermDt() {
		return this.ptnrMedlPanlAsscTermDt;
	}

	public void setPtnrMedlPanlAsscTermDt(Date ptnrMedlPanlAsscTermDt) {
		this.ptnrMedlPanlAsscTermDt = ptnrMedlPanlAsscTermDt;
	}

	public String getPtnrMidNm() {
		return this.ptnrMidNm;
	}

	public void setPtnrMidNm(String ptnrMidNm) {
		this.ptnrMidNm = ptnrMidNm;
	}

	public String getPtnrNm() {
		return this.ptnrNm;
	}

	public void setPtnrNm(String ptnrNm) {
		this.ptnrNm = ptnrNm;
	}

	public BigDecimal getPtnrNpi() {
		return this.ptnrNpi;
	}

	public void setPtnrNpi(BigDecimal ptnrNpi) {
		this.ptnrNpi = ptnrNpi;
	}

	public String getPtnrPhonNbr() {
		return this.ptnrPhonNbr;
	}

	public void setPtnrPhonNbr(String ptnrPhonNbr) {
		this.ptnrPhonNbr = ptnrPhonNbr;
	}

	public String getPtnrSpcltyCd() {
		return this.ptnrSpcltyCd;
	}

	public void setPtnrSpcltyCd(String ptnrSpcltyCd) {
		this.ptnrSpcltyCd = ptnrSpcltyCd;
	}

	public String getPtnrSpcltyDesc() {
		return this.ptnrSpcltyDesc;
	}

	public void setPtnrSpcltyDesc(String ptnrSpcltyDesc) {
		this.ptnrSpcltyDesc = ptnrSpcltyDesc;
	}

	public String getPtnrState() {
		return this.ptnrState;
	}

	public void setPtnrState(String ptnrState) {
		this.ptnrState = ptnrState;
	}

	public String getPtnrTitle() {
		return this.ptnrTitle;
	}

	public void setPtnrTitle(String ptnrTitle) {
		this.ptnrTitle = ptnrTitle;
	}

	public String getPtnrZip() {
		return this.ptnrZip;
	}

	public void setPtnrZip(String ptnrZip) {
		this.ptnrZip = ptnrZip;
	}

	public String getRccUserId() {
		return this.rccUserId;
	}

	public void setRccUserId(String rccUserId) {
		this.rccUserId = rccUserId;
	}

	public BigDecimal getRccUserKey() {
		return this.rccUserKey;
	}

	public void setRccUserKey(BigDecimal rccUserKey) {
		this.rccUserKey = rccUserKey;
	}

	public String getRccUserNm() {
		return this.rccUserNm;
	}

	public void setRccUserNm(String rccUserNm) {
		this.rccUserNm = rccUserNm;
	}

	public String getRegionId() {
		return this.regionId;
	}

	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	public String getRegionNm() {
		return this.regionNm;
	}

	public void setRegionNm(String regionNm) {
		this.regionNm = regionNm;
	}

	public Date getTaxEntEfftDt() {
		return this.taxEntEfftDt;
	}

	public void setTaxEntEfftDt(Date taxEntEfftDt) {
		this.taxEntEfftDt = taxEntEfftDt;
	}

	public Date getTaxEntTermDt() {
		return this.taxEntTermDt;
	}

	public void setTaxEntTermDt(Date taxEntTermDt) {
		this.taxEntTermDt = taxEntTermDt;
	}

	public String getTaxId() {
		return this.taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getUserRole() {
		return this.userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

}