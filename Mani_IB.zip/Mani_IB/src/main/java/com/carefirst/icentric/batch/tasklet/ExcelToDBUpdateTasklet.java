package com.carefirst.icentric.batch.tasklet;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.utils.FileUtils;

public class ExcelToDBUpdateTasklet implements Tasklet, StepExecutionListener {

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Value("${medvantage.inbound.archive.path}")
	String archive;

	@Value("${medvantage.inbound.archive.extract.path}")
	String extractPath;

	@Autowired
	FileUtils fileUtils;

	private static final Logger LOGGER = LogManager.getLogger(ExcelToDBUpdateTasklet.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("> ExcelToDBUpdateTasklet execute starts  >>>");
		Workbook workbook =null;

		try {

			for(File file: fileUtils.getExtractFile(archive)) {
				workbook = WorkbookFactory.create(file);
				workbook.forEach(sheet -> {
					int index = 0;
					for(Row row : sheet) {
						if(index++ == 0) continue;
						if(row.getCell(16) != null && row.getCell(16).getStringCellValue().equals("Y")) {
							pexReqtMembQueueDAO.updateExtractYes(row.getCell(15).getStringCellValue());
						}
					}

				});
				workbook.close();
				Files.copy(Paths.get(file.getPath()), Paths.get(extractPath+file.getName()), StandardCopyOption.REPLACE_EXISTING);
				new File(archive+file.getName()).delete();

			}
		} catch(Exception e) {
			LOGGER.error("Error Occuring execute method  :::::::::: " + e.getMessage());
		}
		return RepeatStatus.FINISHED;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("> ExcelToDBUpdateTasklet beforeStep starts  >>>");
	}

	public ExitStatus afterStep(StepExecution stepExecution) {
		LOGGER.info("> ExcelToDBUpdateTasklet afterStep");
		return ExitStatus.COMPLETED;

	}

}
