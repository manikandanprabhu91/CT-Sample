package com.carefirst.icentric.batch.error.model;

public class ErrorResponse {

	private String errorCode;
	private String providerEngagementID;
	private String gapID;
	private String homePlanStatus;
	private String hostPlanStatus;
	private String fieldElement;
	private String fieldData;
	private String errorDesc;
	private String category;
	private String fileName;

	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getProviderEngagementID() {
		return providerEngagementID;
	}
	public void setProviderEngagementID(String providerEngagementID) {
		this.providerEngagementID = providerEngagementID;
	}
	public String getGapID() {
		return gapID;
	}
	public void setGapID(String gapID) {
		this.gapID = gapID;
	}
	public String getHomePlanStatus() {
		return homePlanStatus;
	}
	public void setHomePlanStatus(String homePlanStatus) {
		this.homePlanStatus = homePlanStatus;
	}
	public String getHostPlanStatus() {
		return hostPlanStatus;
	}
	public void setHostPlanStatus(String hostPlanStatus) {
		this.hostPlanStatus = hostPlanStatus;
	}
	public String getFieldElement() {
		return fieldElement;
	}
	public void setFieldElement(String fieldElement) {
		this.fieldElement = fieldElement;
	}
	public String getFieldData() {
		return fieldData;
	}
	public void setFieldData(String fieldData) {
		this.fieldData = fieldData;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
}
