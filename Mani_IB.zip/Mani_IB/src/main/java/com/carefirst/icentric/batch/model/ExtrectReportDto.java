package com.carefirst.icentric.batch.model;

public class ExtrectReportDto {

	private String RenderingProviderNPI;
	private String RenderingProviderName;
	private String RenderingProviderID;
	private String MemberID;
	private String MemberFullName;
	private String ServiceBeginDate;
	private String ServiceEndDate;
	private String Member_DOB;
	private String Address1;
	private String Address2;
	private String Zip;
	private String City;
	private String State;
	private String REFNC_CD_DESC;
	private String PractitionerID;
	private String DiagnosisCode;
	private String ProvEngmentReqId;
	private String Status;
	
	public String getRenderingProviderNPI() {
		return RenderingProviderNPI;
	}
	public void setRenderingProviderNPI(String renderingProviderNPI) {
		RenderingProviderNPI = renderingProviderNPI;
	}
	public String getRenderingProviderName() {
		return RenderingProviderName;
	}
	public void setRenderingProviderName(String renderingProviderName) {
		RenderingProviderName = renderingProviderName;
	}
	public String getRenderingProviderID() {
		return RenderingProviderID;
	}
	public void setRenderingProviderID(String renderingProviderID) {
		RenderingProviderID = renderingProviderID;
	}
	public String getMemberID() {
		return MemberID;
	}
	public void setMemberID(String memberID) {
		MemberID = memberID;
	}
	public String getServiceBeginDate() {
		return ServiceBeginDate;
	}
	public void setServiceBeginDate(String serviceBeginDate) {
		ServiceBeginDate = serviceBeginDate;
	}
	public String getServiceEndDate() {
		return ServiceEndDate;
	}
	public void setServiceEndDate(String serviceEndDate) {
		ServiceEndDate = serviceEndDate;
	}
	
	public String getMember_DOB() {
		return Member_DOB;
	}
	public void setMember_DOB(String member_DOB) {
		Member_DOB = member_DOB;
	}
	public String getAddress1() {
		return Address1;
	}
	public void setAddress1(String address1) {
		Address1 = address1;
	}
	public String getAddress2() {
		return Address2;
	}
	public void setAddress2(String address2) {
		Address2 = address2;
	}
	public String getZip() {
		return Zip;
	}
	public void setZip(String zip) {
		Zip = zip;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getREFNC_CD_DESC() {
		return REFNC_CD_DESC;
	}
	public void setREFNC_CD_DESC(String rEFNC_CD_DESC) {
		REFNC_CD_DESC = rEFNC_CD_DESC;
	}
	public String getPractitionerID() {
		return PractitionerID;
	}
	public void setPractitionerID(String practitionerID) {
		PractitionerID = practitionerID;
	}
	public String getDiagnosisCode() {
		return DiagnosisCode;
	}
	public void setDiagnosisCode(String diagnosisCode) {
		DiagnosisCode = diagnosisCode;
	}
	public String getProvEngmentReqId() {
		return ProvEngmentReqId;
	}
	public void setProvEngmentReqId(String provEngmentReqId) {
		ProvEngmentReqId = provEngmentReqId;
	}
	public String getMemberFullName() {
		return MemberFullName;
	}
	public void setMemberFullName(String memberFullName) {
		MemberFullName = memberFullName;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	
}
