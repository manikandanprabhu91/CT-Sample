package com.carefirst.icentric.batch.tasklet;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.utils.FileUtils;

@Component
public class ErrorResponseCompletionListener  extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LogManager.getLogger(ErrorResponseCompletionListener.class);
	
	@Autowired
	FileUtils fileUtil;
	
	@Override
	public void afterJob(JobExecution jobExecution) {
		String fileType = jobExecution.getJobParameters().getString("attachFileExten");
		String fileIndicator = jobExecution.getJobParameters().getString("fileIndicator");
		String completionContent = "The job " + jobExecution.getJobInstance().getJobName();

		try {
			fileUtil.archiveInboundFiles(fileIndicator, fileType, "error_report");
		} catch (IOException e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		}
		
		try {
			completionContent =completionContent + " with files "+  jobExecution.getJobParameters().getString("fileList") + "executed sucesssfully";
		} catch (Exception e) {
			LOGGER.error(e);
		}

		LOGGER.info(completionContent);
	}
}
