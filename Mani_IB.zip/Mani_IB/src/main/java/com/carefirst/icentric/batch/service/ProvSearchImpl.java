package com.carefirst.icentric.batch.service;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carefirst.eapmca.controller.PMConnector;
import com.carefirst.icentric.batch.config.ProvSearchConfig;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderRequestMessage;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponseMessage;
import com.example.xmlns._1374265672430.GlobalProvPracServiceServiceagent;
import com.example.xmlns._1374265672430.ProvPractSearchPort;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

@Service
public class ProvSearchImpl implements ProvSearch {

	private static final Logger logger = LoggerFactory.getLogger(ProvSearchImpl.class);

	private final ProvSearchConfig properties;

	private final QName GLOBALPROVPRACSERVICESERVICEAGENT_QNAME = new QName("http://xmlns.example.com/1374265672430",
			"GlobalProvPracService.serviceagent");

	@Autowired
	public ProvSearchImpl(ProvSearchConfig properties) {
		this.properties = properties;
	}

	public ProviderResponse getProviderDetails(String rndrngProvProprietaryId) throws Exception {

		logger.info("Starting getProv");
		URL wsdlurl = null;
		try {
			wsdlurl = new URL(properties.getWsdlUrl());
		} catch (MalformedURLException e) {
			logger.error("Invalid service configuration");
			throw new Exception("ERROR_INVALID_CONFIG");
		}

		GlobalProvPracServiceServiceagent ds = new GlobalProvPracServiceServiceagent(wsdlurl,
				GLOBALPROVPRACSERVICESERVICEAGENT_QNAME);
		ProvPractSearchPort provSearchPort = ds.getProvPractSearchPortEndpoint();

		BindingProvider bp = (BindingProvider) provSearchPort;
		bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, properties.getEndPoint());

		bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY,
				PMConnector.getConnector().getUserName(properties.getVaultQuery()));
		bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY,
				PMConnector.getConnector().getContent(properties.getVaultQuery()));
		bp.getRequestContext().put("com.sun.xml.internal.ws.connect.timeout", properties.getTimeout());
		bp.getRequestContext().put("com.sun.xml.internal.ws.request.timeout", properties.getTimeout());

		try {
			ProviderRequestMessage provPractitionerIn = createRequest( rndrngProvProprietaryId);
			if (logger.isInfoEnabled()) {
				logger.info("Communication request :" + objectToXML(provPractitionerIn));
			}

			ProviderResponseMessage provResponse = provSearchPort.getProvPractOperation(provPractitionerIn);
			if (logger.isDebugEnabled()) {
				logger.debug("Communication response :" + objectToXML(provResponse));
			}
			if (("SUCCESS").equalsIgnoreCase(provResponse.getStatusBlock().getStatusMessage().get(0).getMesgDesc())) {
				return provResponse.getProviderResponse();
			}
		} catch (Exception e) {
			logger.info("Exception Occured in while getting Provider Search Details for Rendering Proprietary Id : "+rndrngProvProprietaryId);
			logger.error(ExceptionUtils.getStackTrace(e));
		}
		logger.info("Exiting getProv");
		return null;

	}

	private ProviderRequestMessage createRequest(String rndrngProvProprietaryId) {
		ProviderRequestMessage provPractitionerIn = new ProviderRequestMessage();
		//TODO set the request object to test
		provPractitionerIn.setPANRID(rndrngProvProprietaryId);
		provPractitionerIn.setTypeSearch("PRACONLY");
		/*provPractitionerIn.getPagination().setStartRecord("1");
		provPractitionerIn.getPagination().setThreshold("10");*/
		
		return provPractitionerIn;
	}

	private String objectToXML(ProviderResponseMessage provResponse) {
		XStream xstream = new XStream(new DomDriver());
		return xstream.toXML(provResponse);
	}

	private String objectToXML(ProviderRequestMessage provPractitionerIn) {
		XStream xstream = new XStream(new DomDriver());
		return xstream.toXML(provPractitionerIn);
	}

}
