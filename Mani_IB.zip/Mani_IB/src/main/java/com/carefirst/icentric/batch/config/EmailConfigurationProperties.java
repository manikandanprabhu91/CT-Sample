package com.carefirst.icentric.batch.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="email")
public class EmailConfigurationProperties {

	private String environment;
	private String to;
	private String from;
	private String subject;
	private String firstcontent;
	private String secondcontent;
	private String submissiondate;
	private String responsetotalrecords;
	private String responsefailedrecords;
	private String responsetotalhostplanrecords;
	private String note;
	
	private String psto;
	private String psfrom;
	private String pssubject;
	private String pscontent;
	private String pscontentSecond;
	
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getFirstcontent() {
		return firstcontent;
	}
	public void setFirstcontent(String firstcontent) {
		this.firstcontent = firstcontent;
	}
	public String getSecondcontent() {
		return secondcontent;
	}
	public void setSecondcontent(String secondcontent) {
		this.secondcontent = secondcontent;
	}
	public String getSubmissiondate() {
		return submissiondate;
	}
	public void setSubmissiondate(String submissiondate) {
		this.submissiondate = submissiondate;
	}
	public String getResponsetotalrecords() {
		return responsetotalrecords;
	}
	public void setResponsetotalrecords(String responsetotalrecords) {
		this.responsetotalrecords = responsetotalrecords;
	}
	public String getResponsefailedrecords() {
		return responsefailedrecords;
	}
	public void setResponsefailedrecords(String responsefailedrecords) {
		this.responsefailedrecords = responsefailedrecords;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getResponsetotalhostplanrecords() {
		return responsetotalhostplanrecords;
	}
	public void setResponsetotalhostplanrecords(String responsetotalhostplanrecords) {
		this.responsetotalhostplanrecords = responsetotalhostplanrecords;
	}
	public String getPsto() {
		return psto;
	}
	public void setPsto(String psto) {
		this.psto = psto;
	}
	public String getPsfrom() {
		return psfrom;
	}
	public void setPsfrom(String psfrom) {
		this.psfrom = psfrom;
	}
	public String getPssubject() {
		return pssubject;
	}
	public void setPssubject(String pssubject) {
		this.pssubject = pssubject;
	}
	public String getPscontent() {
		return pscontent;
	}
	public void setPscontent(String pscontent) {
		this.pscontent = pscontent;
	}
	public String getPscontentSecond() {
		return pscontentSecond;
	}
	public void setPscontentSecond(String pscontentSecond) {
		this.pscontentSecond = pscontentSecond;
	}
	
}
