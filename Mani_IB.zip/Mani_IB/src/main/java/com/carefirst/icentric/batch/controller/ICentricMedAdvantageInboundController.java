package com.carefirst.icentric.batch.controller;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.carefirst.icentric.batch.config.MedicalRecordJobScheduler;
import com.carefirst.icentric.batch.config.ReportGenerationScheduler;
import com.carefirst.icentric.batch.config.RiskAdjustmentJobScheduler;
import com.carefirst.icentric.batch.config.StarCareJobScheduler;
import com.carefirst.icentric.batch.model.JobResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class is used to Trigger inbound jobs.
 * @author aad7740
 *
 */

@Validated
@RestController
@Api(value = "JobTrigger")
public class ICentricMedAdvantageInboundController {

	private static final Logger LOGGER = LogManager.getLogger(ICentricMedAdvantageInboundController.class);
	
	@Autowired
	MedicalRecordJobScheduler medicalRecordJobScheduler;
	
	@Autowired
	StarCareJobScheduler starCareJobScheduler;
	
	@Autowired
	RiskAdjustmentJobScheduler riskAdjustmentJobScheduler;
	
	@Autowired
	ReportGenerationScheduler extractReport;

	@GetMapping("/medadvantage/inbound/meicalrecord")
	@ApiOperation(value = "Trigger meicalrecord Job", notes = "API to trigger meicalrecord job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> triggerMedRecJobFromWeb() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger meicalrecord job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (medicalRecordJobScheduler.triggerJobFromWeb()) {
				LOGGER.info("Got Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger meicalrecord job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger meicalrecord = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger meicalrecord job");
		}
		return responseEntity;
	}
	
	@GetMapping("/medadvantage/inbound/starcare")
	@ApiOperation(value = "Trigger starcare Job", notes = "API to trigger Starcare job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> triggerStarCareJobFromWeb() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger starcare job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (starCareJobScheduler.triggerJobFromWeb()) {
				LOGGER.info("Got Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger starcare job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger starcare = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger starcare job");
		}
		return responseEntity;
	}
	
	@GetMapping("/medadvantage/inbound/riskadjustment")
	@ApiOperation(value = "Trigger riskadjustment Job", notes = "API to trigger riskadjustment job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> triggerRiskadjustmentJobFromWeb() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger riskadjustment job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (riskAdjustmentJobScheduler.triggerJobFromWeb()) {
				LOGGER.info("Got Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger riskadjustment job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger riskadjustment = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger riskadjustment job");
		}
		return responseEntity;
	}
	@GetMapping("/medadvantage/inbound/extract")
	@ApiOperation(value = "Trigger extract report Job", notes = "API to trigger extract report job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> triggerExtractReportJobFromWeb() {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger extract job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (extractReport.triggerJobFromWeb()) {
				LOGGER.info("Got Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger extract job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger extract = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger extract job");
		}
		return responseEntity;
	}
	
	
	
}
