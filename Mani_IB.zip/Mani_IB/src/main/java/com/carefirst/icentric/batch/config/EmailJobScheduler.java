package com.carefirst.icentric.batch.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;

@Component
public class EmailJobScheduler implements SchedulingConfigurer {

	private static final Logger LOGGER = LogManager.getLogger(EmailJobScheduler.class);

	private final int POOL_SIZE = 10;

	@Autowired
	private JobLauncher jobLauncherEmail;

	@Autowired
	private EmailJobConfig emailJobConfig;

	@Autowired
	private JobExplorer emailJobExplorer;
	
	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Override
	public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
		LOGGER.info("> configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();
		scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		LOGGER.info("< configureTasks");
	}

	@Scheduled(cron = "${medvantage.inbound.batch.email.cron}")
	public void scheduler() {
		String transactionId = UUID.randomUUID().toString();
		MDC.put("transactionId", "Email: " + transactionId);
		LOGGER.info("> Email batchJob");
		Map<String, JobParameter> jobParamMap = new HashMap<>();
		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
		triggerEmail(jobParamMap);
		MDC.clear();
		MDC.remove("transactionId");
	}

	private void triggerEmail(Map<String, JobParameter> jobParamMap) {
		LOGGER.info("> runMedicalRecord");
		try {
			jobParamMap.put(Constants.CATEGORY_IND, new JobParameter(Constants.CATEGORY_IND_MR));
			JobParameters jobParams = new JobParameters(jobParamMap);
			while (true) {
				Set<org.springframework.batch.core.JobExecution> jobExecutions = emailJobExplorer
						.findRunningJobExecutions(emailJobConfig.emailBatchJob().getName());
				boolean runFilejob = !jobExecutions.isEmpty();
				if (runFilejob) {
					LOGGER.info("Email Job is already running waiting to restart");
					Thread.sleep(30000);
				} else {
					LOGGER.info("Starting the Email job");
					break;
				}
			}
			// Job is triggered to execute the tasks
			jobLauncherEmail.run(emailJobConfig.emailBatchJob(), jobParams);	
		}catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException | org.springframework.batch.core.repository.JobRestartException
				| InterruptedException e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		}
	}
	
	public boolean triggerJobFromWeb() throws Exception {
		LOGGER.info("> triggerJobFromWeb");
		Set<org.springframework.batch.core.JobExecution> jobExecutions = emailJobExplorer
				.findRunningJobExecutions(emailJobConfig.emailBatchJob().getName());
		boolean runFilejob = !jobExecutions.isEmpty();
		if (runFilejob) {
			LOGGER.info("< triggerJobFromWeb");
			throw new Exception("JOB is running. Please try again later");
		} else {
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				scheduler();
				LOGGER.info("< triggerJobFromWeb");
			});
		}
		return true;
	}
}
