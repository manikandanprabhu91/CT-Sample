package com.carefirst.icentric.batch.config;

import java.io.File;

import org.apache.commons.io.monitor.FileAlterationListener;
import org.apache.commons.io.monitor.FileAlterationListenerAdaptor;
import org.apache.commons.io.monitor.FileAlterationMonitor;
import org.apache.commons.io.monitor.FileAlterationObserver;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.utils.FileUtils;


@Component
public class FileWatchConfigMedRec {

	@Autowired
	private MedicalRecordJobScheduler scheduler;

	@Autowired
	private FileUtils fileUtil;

	private static final int POLL_INTERVAL = 500;

	private static final Logger LOGGER = LogManager.getLogger(FileWatchConfigMedRec.class);

	@Value("${filewatch.enabled}")
	private String filewatch;

	@EventListener(ApplicationReadyEvent.class)
	public void medicalRecordFilewatch() {

		try {
			LOGGER.info("Starting medicalRecordFilewatch on DIR  ::" + fileUtil.getInBoundPath());

			FileAlterationObserver observer = new FileAlterationObserver(fileUtil.getInBoundPath());
			FileAlterationMonitor monitor = new FileAlterationMonitor(POLL_INTERVAL);
			FileAlterationListener listener = new FileAlterationListenerAdaptor() {
				@Override
				public void onFileCreate(File file) {
					if (null != filewatch && (Constants.TRUE.equalsIgnoreCase(filewatch))) {
						LOGGER.info("File: " + file.getName() + " found. Starting medicalRecordFilewatch Job.");
						
							scheduler.scheduler();
					}
				}

				@Override
				public void onFileDelete(File file) {
					LOGGER.info("File: " + file.getName() + " deleted");
				}

				@Override
				public void onFileChange(File file) {
					LOGGER.info("File: " + file.getName() + " changed");
				}
			};
			observer.addListener(listener);
			monitor.addObserver(observer);
			monitor.start();

		} catch (Exception e) {
			LOGGER.error("Error starting medicalRecordFilewatch");
			LOGGER.error(ExceptionUtils.getStackTrace(e));
		}
		LOGGER.info("exiting medicalRecordFilewatch");
	}
}
