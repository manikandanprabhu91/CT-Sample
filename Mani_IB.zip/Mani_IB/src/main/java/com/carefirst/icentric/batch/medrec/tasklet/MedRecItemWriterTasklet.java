package com.carefirst.icentric.batch.medrec.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.medrec.model.MedRecReq;
import com.carefirst.icentric.batch.medrec.model.MedRecReqObj;
import com.carefirst.icentric.batch.utils.MedRecUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to process the record and storing the data into DB.
 * @author aad7740
 *
 */
public class MedRecItemWriterTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(MedRecItemWriterTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	MedRecUtils medRecUtils;
	
	String fileName;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("medRecFileName");
		String filePath = (String) param.getValue();
		fileName = filePath;		
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info(":::::::::::MedRecItemWriterTasklet execute method:::::: Starting>>>>>> ");
		try {
			InputStream inJson = new FileInputStream(new File(fileName));
			MedRecReqObj medRecReqObj = new ObjectMapper().readValue(inJson, MedRecReqObj.class);
			for (MedRecReq medRecpReq : medRecReqObj.getMedRecReq()) {
				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO.findByProvEngmtReqtId(medRecpReq.getProvEngmntReqId());
				if(pexReqtMembQueueList.isEmpty()){
					pexReqtMembQueue = medRecUtils.setJsonPojoToEntityClass(medRecpReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				}else{
					LOGGER.info(":::::::::::MedRecItemWriterTasklet execute method  updatePexTableColumns::::::>>>>>> ");
					medRecUtils.updatePexTableColumns(medRecpReq, pexReqtMembQueueList);
					medRecUtils.updatePexReqtJsonDetails(medRecpReq, pexReqtMembQueueList);
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error("Exception found while reading the response:: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		LOGGER.info(":::::::::::MedRecItemWriterTasklet execute method:::::: End>>>>>> ");
		return RepeatStatus.FINISHED;
	}

}
