package com.carefirst.icentric.batch.tasklet;

public class ReportGenerationCompletionListener {

}
