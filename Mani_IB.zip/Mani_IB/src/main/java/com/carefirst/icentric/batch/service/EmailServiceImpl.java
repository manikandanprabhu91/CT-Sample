package com.carefirst.icentric.batch.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import com.carefirst.icentric.batch.config.EmailConfigurationProperties;
import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.medrec.model.MedRecReqObj;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGapReqObj;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReqObj;
import com.carefirst.icentric.batch.utils.ErrorResponseUtils;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to process the error file and send email to business team.
 * @author aad7740
 *
 */
@Service
public class EmailServiceImpl implements EmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);

	@Autowired
	JavaMailSender javaMailSender;

	@Autowired
	EmailConfigurationProperties emailConfigProperties;

	@Autowired
	ErrorResponseUtils errorResponseUtils; 

	@Autowired
	FileUtils fileUtils;

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Value("${medvantage.inbound.archive.path}")
	private String archivePath;


	@Value("${medvantage.outbound.archive.path}")
	private String outboundarchivePath;

	@Override
	public void sendMail(List<ErrorResponse> errorResponses, String fileName, String categoryInd, int totalrecord) {
		LOGGER.info("::::sendMail-->>>>> Start:::::::::::");
		File file = null;
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Email To :" + errorResponses.size());
			}

			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper mailMessage = new MimeMessageHelper(message, true);
			String[] recipientList = emailConfigProperties.getTo().split(Constants.COMMA);
			InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
			int counter = 0;
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Email To :" + recipientList);
			}
			for (String recipient : recipientList) {
				recipientAddress[counter] = new InternetAddress(recipient.trim());
				counter++;
			}
			mailMessage.setTo(recipientAddress);
			mailMessage.setFrom(emailConfigProperties.getFrom());
			mailMessage.setSubject(emailConfigProperties.getSubject().replace(Constants.DOT, categoryInd));
			int firstIndx = fileName.indexOf(Constants.ERROR_REPORT_STR);
			String filename = fileName.substring(firstIndx);
			file = new File(archivePath+filename.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING) + Constants.XLS);
			MimeMultipart mimeMultipart = new MimeMultipart();
			MimeBodyPart bodyPart = new MimeBodyPart();
			List<String> errorCodes = new ArrayList<>();
			for(ErrorResponse errorResponse: errorResponses) {
				errorCodes.add(errorResponse.getErrorCode());
			}
			bodyPart.setContent(emailHTMLContent(errorResponses, fileName, categoryInd, totalrecord, errorCodes), Constants.CONTENTTYPE);
			mimeMultipart.addBodyPart(bodyPart);
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			DataSource source = new FileDataSource(file);
			mimeBodyPart.setDataHandler(new DataHandler(source));
			mimeBodyPart.setFileName(filename.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING) + Constants.XLS);
			mimeMultipart.addBodyPart(mimeBodyPart);
			message.setContent(mimeMultipart);
			javaMailSender.send(message);

		} catch (Exception e) {
			LOGGER.error("Error Occuring while sending the mail ::::::::::::::::: "+e.getMessage());
		}

		LOGGER.info("::::sendMail-->>>>> End:::::::::::");
	}

	protected String emailHTMLContent(List<ErrorResponse> errorResponses, String fileName, String categoryInd, int totalrecord,
			List<String> errorCodes) {
		String message = "";

		try {
			StringBuffer buffer = new StringBuffer();
			message = Constants.HTML_HEAD;
			String filename = fileName.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING);
			message += Constants.HTML_BR_TAG + emailConfigProperties.getFirstcontent() + Constants.EMPTY_STRING_SPACE + 
					fileUtils.getFileName(filename, categoryInd) + Constants.HTML_BR_TAG_END;
			message += emailConfigProperties.getSecondcontent() + Constants.HTML_BR_TAG;
			message += Constants.HTML_BR_TAG + emailConfigProperties.getSubmissiondate() + Constants.EMPTY_STRING_SPACE + 
					fileUtils.getDateString(filename, categoryInd) + Constants.HTML_BR_TAG_END;
			int totaloutbountrec = 0;
			if(Constants.CATEGORY_IND_MR.equals(categoryInd)) {
				InputStream stream = new FileInputStream(outboundarchivePath+fileUtils.getFileName(filename, categoryInd));
				MedRecReqObj medRecReqObj = new ObjectMapper().readValue(stream, MedRecReqObj.class);
				totaloutbountrec = medRecReqObj.getMedRecReq().size();
			} else if(Constants.CATEGORY_IND_RA.equals(categoryInd)) {
				InputStream stream = new FileInputStream(outboundarchivePath+fileUtils.getFileName(filename, categoryInd));
				RiskAdjGapReqObj adjGapReqObj = new ObjectMapper().readValue(stream, RiskAdjGapReqObj.class);
				totaloutbountrec = adjGapReqObj.getRiskAdjustmentGapReq().size();
			} else if(Constants.CATEGORY_IND_SC.equals(categoryInd)) {
				InputStream stream = new FileInputStream(outboundarchivePath+fileUtils.getFileName(filename, categoryInd));
				StarsCareGapReqObj careGapReqObj = new ObjectMapper().readValue(stream, StarsCareGapReqObj.class);
				totaloutbountrec = careGapReqObj.getStarsCareGapReq().size();
			}
			message += Constants.HTML_BR_TAG + Constants.HASH_SYMBOL+emailConfigProperties.getResponsetotalhostplanrecords() + 
					Constants.EMPTY_STRING_SPACE + totaloutbountrec + Constants.HTML_BR_TAG_END;
			message += Constants.HTML_BR_TAG + Constants.HASH_SYMBOL+emailConfigProperties.getResponsetotalrecords() +
					Constants.EMPTY_STRING_SPACE + totalrecord + Constants.HTML_BR_TAG_END;
			message += Constants.HTML_BR_TAG + Constants.HASH_SYMBOL+emailConfigProperties.getResponsefailedrecords() + 
					Constants.EMPTY_STRING_SPACE + errorResponses.size() + Constants.HTML_BR_TAG_END;
			for(ErrorResponse response:errorResponses) {
				if(!buffer.toString().isEmpty() && buffer.toString().contains(response.getErrorCode())) {
					LOGGER.info("Error Description Already appended.....");
				} else {
					int errorCodeSize = Collections.frequency(errorCodes, response.getErrorCode());
					buffer.append(Constants.HTML_BR_TAG_END + response.getErrorCode() + Constants.OPEN_BRACKET + 
							pexReqtMembQueueDAO.getErrorDescription(response.getErrorCode()) + Constants.CLOSE_BRACKET + 
							Constants.MINUS_SYMBOL + errorCodeSize + Constants.HTML_BR_TAG_END);

				}

			}

			buffer.append(Constants.HTML_BR_TAG_END);
			message += buffer.toString();
			LOGGER.info(">>>Email body content :::::() -> " + message);
		} catch (Exception e) {
			LOGGER.error("Error Occuring while constructing the html content ::::::: "+e.getMessage());
		}
		return message;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void sendStatsUpdateEmail() {
		LOGGER.info(">>>sendStatsUpdateEmail Start :::::() -> ");
		try {
			List<Object[]> pendingStatusList = pexReqtMembQueueDAO.getPendingStatusList(fileUtils.getPendingStatusDate());
			if(!pendingStatusList.isEmpty()) {
				MimeMessage message = javaMailSender.createMimeMessage();
				MimeMessageHelper mailMessage = new MimeMessageHelper(message, true);
				String[] recipientList = emailConfigProperties.getPsto().split(Constants.COMMA);
				InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
				int counter = 0;
				if (LOGGER.isDebugEnabled()) {
					LOGGER.debug("Email To :" + recipientList);
				}
				for (String recipient : recipientList) {
					recipientAddress[counter] = new InternetAddress(recipient.trim());
					counter++;
				}
				mailMessage.setTo(recipientAddress);
				mailMessage.setFrom(emailConfigProperties.getFrom());
				mailMessage.setSubject(emailConfigProperties.getPssubject());
				String body = Constants.HTML_HEAD;
				
				body += Constants.HTML_BR_TAG + emailConfigProperties.getPscontent() + Constants.EMPTY_STRING_SPACE + Calendar.getInstance().getDisplayName(Calendar.MONTH,
						Calendar.LONG, Locale.ENGLISH) + Constants.EMPTY_STRING_SPACE + emailConfigProperties.getPscontentSecond() + Constants.HTML_BR_TAG_END + Constants.HTML_BR_TAG_END;
				
				for (Object[] result : pendingStatusList) {
					body += result[1].toString() + " "+ pexReqtMembQueueDAO.findRequestType(result[0].toString()) + Constants.PS_COUNT_CONTENT + result[2] + Constants.HTML_BR_TAG_END + Constants.HTML_BR_TAG_END;
				}

				MimeMultipart mimeMultipart = new MimeMultipart();
				MimeBodyPart bodyPart = new MimeBodyPart();
				bodyPart.setContent(body, Constants.CONTENTTYPE);
				mimeMultipart.addBodyPart(bodyPart);
				message.setContent(mimeMultipart);
				javaMailSender.send(message);
			}
		} catch(Exception e) {
			LOGGER.error("Error Occuring while sending the mail ::::::::::::::::: "+e.getMessage());
		}

		LOGGER.info(">>>sendStatsUpdateEmail End :::::() -> ");
	}

}
