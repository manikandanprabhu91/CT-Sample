package com.carefirst.icentric.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableScheduling
@ComponentScan({"com.carefirst.icentric.batch.*"})
public class ICentricMedvantageInboundBatch {
	/**
	 * The main class of AE2BatchApplication
	 * 
	 */
	public static void main(String[] args) {
		SpringApplication.run(ICentricMedvantageInboundBatch.class, args);
	}
}
