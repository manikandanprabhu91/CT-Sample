/**
 * 
 */
package com.carefirst.icentric.batch.config;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.adapter.ItemReaderAdapter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.carefirst.icentric.batch.riskadj.model.RiskAdjustmentGapReq;
import com.carefirst.icentric.batch.riskadj.tasklet.RiskAdjItemProcessor;
import com.carefirst.icentric.batch.riskadj.tasklet.RiskAdjItemWriter;
import com.carefirst.icentric.batch.riskadj.tasklet.RiskAdjItemWriterTasklet;
import com.carefirst.icentric.batch.riskadj.tasklet.RiskAdjJobCompletionListener;
import com.carefirst.icentric.batch.tasklet.AttachmentFileInsertTasklet;
import com.carefirst.icentric.batch.tasklet.StatusUpdateTasklet;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author aab8788
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class RiskAdjustmentJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(RiskAdjustmentJobConfig.class);
	@Autowired
	private JobBuilderFactory riskAdjJobBuilderfactory;

	@Autowired
	private StepBuilderFactory riskAdjStepBuilderfactory;


	private int chunkSize = 100;

	@Bean
	public Job riskAdjBatchJob() {
		return riskAdjJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB Risk Adjustment").incrementer(new RunIdIncrementer())
				.start(riskAdjGapWriter()).next(internalStatusUpdate()).listener(riskAdjJobcompletionListener()).build();
	}

	@Bean
	public JobExecutionListener riskAdjJobcompletionListener() {
		return new RiskAdjJobCompletionListener();
	}
	
	@Bean
	public Step riskAdjGapWriter() {
		LOGGER.info("insertData - step1() start/end");
		return riskAdjStepBuilderfactory.get("step1").tasklet(riskAdjGapTasklet()).build();
	}
	
	@Bean
	public RiskAdjItemWriterTasklet riskAdjGapTasklet() {
		RiskAdjItemWriterTasklet tasklet = new RiskAdjItemWriterTasklet();
		return tasklet;
	}


//	@Bean
//	public Step readRiskAdjData() {
//		return  riskAdjStepBuilderfactory.get("step1").<RiskAdjustmentGapReq, RiskAdjustmentGapReq>chunk(chunkSize)
//				.reader(riskAdjJsonItemReader(null)).processor(riskAdjGapReqItemProcessor()).writer(riskAdjGapReqWriter())
//				.build();	
//	}

	@Bean
	public Job riskAdjAttachmentBatchJob() {
		return riskAdjJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB Risk Adjustment").incrementer(new RunIdIncrementer())
				.start(insertAttachmentFile()).listener(riskAdjJobcompletionListener()).build();
	}
	
	@Bean
	public Step insertAttachmentFile() {
		LOGGER.info("insertData - step1() start/end");
		return riskAdjStepBuilderfactory.get("step1").tasklet(insertAttachmentFileInsertTasklet()).build();
	}
	
	@Bean
	public AttachmentFileInsertTasklet insertAttachmentFileInsertTasklet() {
		AttachmentFileInsertTasklet tasklet = new AttachmentFileInsertTasklet();
		return tasklet;
	}
		
	@Bean
	public ItemWriter<RiskAdjustmentGapReq> riskAdjGapReqWriter() {
		return new RiskAdjItemWriter();
	}
	
	@Bean
	public Step internalStatusUpdate() {
		LOGGER.info("insertData - step1() start/end");
		return riskAdjStepBuilderfactory.get("step1").tasklet(internalStatusUpdateTasklet()).build();
	}
	
	@Bean
	public StatusUpdateTasklet internalStatusUpdateTasklet() {
		StatusUpdateTasklet tasklet = new StatusUpdateTasklet();
		return tasklet;
	}

//	@Bean
//	@StepScope
//	public ItemProcessor<RiskAdjustmentGapReq, RiskAdjustmentGapReq> riskAdjGapReqItemProcessor() {
//		return new RiskAdjItemProcessor();
//	}
//
//	@Bean
//	@StepScope
//	public ItemReader<RiskAdjustmentGapReq> riskAdjItemReader() {
//		return new ItemReaderAdapter<RiskAdjustmentGapReq>();
//	}

//	@Bean
//	@StepScope
//	public JsonItemReader<RiskAdjustmentGapReq> riskAdjJsonItemReader(@Value("#{jobParameters['riskAdjFileName']}") String file) {
//
//		ObjectMapper objectMapper = new ObjectMapper();
//		// configure the objectMapper as required
//		JacksonJsonObjectReader<RiskAdjustmentGapReq> jsonObjectReader = new JacksonJsonObjectReader<>(
//				RiskAdjustmentGapReq.class);
//		jsonObjectReader.setMapper(objectMapper);
//
//		return new JsonItemReaderBuilder<RiskAdjustmentGapReq>().jsonObjectReader(jsonObjectReader)
//				.resource(new FileSystemResource(new File(file.trim()))).name("riskAdjJsonItemReader").build();
//	}

}
