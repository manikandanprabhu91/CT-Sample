package com.carefirst.icentric.batch.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.carefirst.icentric.batch.tasklet.ErrorResponseCompletionListener;
import com.carefirst.icentric.batch.tasklet.ErrorResponseTasklet;

/**
 * 
 * @author aad7740
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class ErrorResponseJobConfig {
	
	private static final Logger LOGGER = LogManager.getLogger(ErrorResponseJobConfig.class);
	
	@Autowired
	private JobBuilderFactory builderFactory;

	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Bean
	public Job errorResBatchJob() {
		return builderFactory.get("MEDVANTAGE_PROCESS-JOB Medical Record").incrementer(new RunIdIncrementer())
				.start(errorResReader()).listener(errorResponseJobcompletionListener()).build();
	}
	
	@Bean
	public Step errorResReader() {
		LOGGER.info("readData - step1() start/end");
		return stepBuilderFactory.get("step1").tasklet(errorResponseTasklet()).build();
	}
	
	@Bean
	public ErrorResponseTasklet errorResponseTasklet() {
		ErrorResponseTasklet tasklet = new ErrorResponseTasklet();
		return tasklet;
	}

	@Bean
	public JobExecutionListener errorResponseJobcompletionListener() {
		return new ErrorResponseCompletionListener();
	}
}
