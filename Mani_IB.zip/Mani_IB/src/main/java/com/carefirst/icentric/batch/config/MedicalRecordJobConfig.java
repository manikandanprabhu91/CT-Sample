/**
 * 
 */
package com.carefirst.icentric.batch.config;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.carefirst.icentric.batch.medrec.model.MedRecReq;
import com.carefirst.icentric.batch.medrec.tasklet.MedRecItemProcessor;
import com.carefirst.icentric.batch.medrec.tasklet.MedRecItemWriter;
import com.carefirst.icentric.batch.medrec.tasklet.MedRecItemWriterTasklet;
import com.carefirst.icentric.batch.medrec.tasklet.MedRecJobCompletionListener;
import com.carefirst.icentric.batch.tasklet.AttachmentFileInsertTasklet;
import com.carefirst.icentric.batch.tasklet.StatusUpdateTasklet;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author aab8788
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class MedicalRecordJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(MedicalRecordJobConfig.class);
	@Autowired
	private JobBuilderFactory medRecJobBuilderfactory;

	@Autowired
	private StepBuilderFactory medRecStepBuilderfactory;

	private int chunkSize = 100;

	@Bean
	public Job medRecBatchJob() {
		return medRecJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB Medical Record").incrementer(new RunIdIncrementer())
				.start(medRecWriter()).next(internalStatusUpdate()).listener(medRecJobcompletionListener()).build();
	}
	
	@Bean
	public Job medRecAttachmentBatchJob() {
		return medRecJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB Risk Adjustment").incrementer(new RunIdIncrementer())
				.start(insertAttachmentFile()).listener(medRecJobcompletionListener()).build();
	}

	@Bean
	public JobExecutionListener medRecJobcompletionListener() {
		return new MedRecJobCompletionListener();
	}

//	@Bean
//	public Step readMedRecData() {
//		LOGGER.info("readData - step1() start/end");
//
//		return medRecStepBuilderfactory.get("step1").<MedRecReq, MedRecReq>chunk(chunkSize)
//				.reader(medRecJsonItemReader(null)).processor(medRecReqItemProcessor()).writer(medRecReqWriter())
//				.build();
//	}

	@Bean
	public ItemWriter<MedRecReq> medRecReqWriter() {
		return new MedRecItemWriter();
	}

	@Bean
	@StepScope
	public ItemProcessor<MedRecReq, MedRecReq> medRecReqItemProcessor() {
		return new MedRecItemProcessor();
	}
	
	@Bean
	public Step medRecWriter() {
		LOGGER.info("insertData - step1() start/end");
		return medRecStepBuilderfactory.get("step1").tasklet(medRecordTasklet()).build();
	}
	
	@Bean
	public MedRecItemWriterTasklet medRecordTasklet() {
		MedRecItemWriterTasklet tasklet = new MedRecItemWriterTasklet();
		return tasklet;
	}
	
	@Bean
	public Step insertAttachmentFile() {
		LOGGER.info("insertData - step1() start/end");
		return medRecStepBuilderfactory.get("step1").tasklet(insertAttachmentFileInsertTasklet()).build();
	}
	
	@Bean
	public AttachmentFileInsertTasklet insertAttachmentFileInsertTasklet() {
		AttachmentFileInsertTasklet tasklet = new AttachmentFileInsertTasklet();
		return tasklet;
	}
	
	@Bean
	public Step internalStatusUpdate() {
		LOGGER.info("insertData - step1() start/end");
		return medRecStepBuilderfactory.get("step1").tasklet(internalStatusUpdateTasklet()).build();
	}
	
	@Bean
	public StatusUpdateTasklet internalStatusUpdateTasklet() {
		StatusUpdateTasklet tasklet = new StatusUpdateTasklet();
		return tasklet;
	}

//	@Bean
//	@StepScope
//	public JsonItemReader<MedRecReq> medRecJsonItemReader(@Value("#{jobParameters['medRecFileName']}") String file) {
//
//		ObjectMapper objectMapper = new ObjectMapper();
//		// configure the objectMapper as required
//		JacksonJsonObjectReader<MedRecReq> jsonObjectReader = new JacksonJsonObjectReader<>(
//				MedRecReq.class);
//		jsonObjectReader.setMapper(objectMapper);
//
//		return new JsonItemReaderBuilder<MedRecReq>().jsonObjectReader(jsonObjectReader)
//				.resource(new FileSystemResource(new File(file.trim()))).name("medRecJsonItemReader").build();
//	}

}
