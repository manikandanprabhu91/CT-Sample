package com.carefirst.icentric.batch.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.icentric.batch.starcare.model.StarCareGap;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReqObj;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.NetworkDetails;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to Process Starcare records.
 * @author aad7740
 *
 */
@Component
public class StarCareUtils {

	private static final Logger LOGGER = LogManager.getLogger(StarCareUtils.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	String fileName;

	@Autowired
	ProvSearch provSearch;

	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;

	public void updatePexReqtJsonDetails(StarsCareGapReq starsCareGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) throws Exception{
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			StarsCareGapReq readValue = objectMapper.readValue(reqtJson, StarsCareGapReq.class);
			readValue.setMemberHostPlanId(starsCareGapReq.getMemberHostPlanId());
			readValue.setRoutetoHostPlanId(starsCareGapReq.getRoutetoHostPlanId());
			readValue.setCapabilityInd(starsCareGapReq.getCapabilityInd());
			readValue.setHomePlanId(starsCareGapReq.getHomePlanId());
			readValue.setITSSubscriberId(starsCareGapReq.getITSSubscriberId());
			readValue.setNumofGapClosures(starsCareGapReq.getNumofGapClosures());
			readValue.setBillProvProprietaryId(starsCareGapReq.getBillProvProprietaryId());
			readValue.setRndrngProvProprietaryId(starsCareGapReq.getRndrngProvProprietaryId());
			readValue.setBillProvNPI(starsCareGapReq.getBillProvNPI());
			readValue.setRndrngProvNPI(starsCareGapReq.getRndrngProvNPI());
			readValue.setRndrngProvHostPlanId(starsCareGapReq.getRndrngProvHostPlanId());
			readValue.setBillProvZipCode(starsCareGapReq.getBillProvZipCode());
			readValue.setRndrngProvZipCode(starsCareGapReq.getRndrngProvZipCode());
			readValue.setRndrngProvTxnmyCd(starsCareGapReq.getRndrngProvTxnmyCd());
			readValue.setSCCFIds(starsCareGapReq.getSCCFIds());
			readValue.setGapPrevouslyClosedByThisProv(starsCareGapReq.getGapPrevouslyClosedByThisProv());
			readValue.setProvEngagementInd(starsCareGapReq.getProvEngagementInd());
			readValue.setRndrngProvTaxId(starsCareGapReq.getRndrngProvTaxId());
			readValue.setRndrngProvAddlInfo(starsCareGapReq.getRndrngProvAddlInfo());
			readValue.setFirstTimeSenttoHostPlanDt(starsCareGapReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(starsCareGapReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(starsCareGapReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(starsCareGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(starsCareGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(starsCareGapReq.getMemberDOB());
			readValue.setMMIId(starsCareGapReq.getMMIId());
			readValue.setMemberFullName(starsCareGapReq.getMemberFullName());
			readValue.setMemberGender(starsCareGapReq.getMemberGender());
			readValue.getMemberPCP5PartKey().setProvPlanCd(starsCareGapReq.getMemberPCP5PartKey().getProvPlanCd());
			readValue.getMemberPCP5PartKey().setProductCd(starsCareGapReq.getMemberPCP5PartKey().getProductCd());
			readValue.getMemberPCP5PartKey().setProvNum(starsCareGapReq.getMemberPCP5PartKey().getProvNum());
			readValue.getMemberPCP5PartKey().setProvNumSuffix(starsCareGapReq.getMemberPCP5PartKey().getProvNumSuffix());
			readValue.getMemberPCP5PartKey().setProvNetwrkLocSeqNum(starsCareGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
			readValue.setProvCntrctingSts(starsCareGapReq.getProvCntrctingSts());

			for (StarCareGap starCareGap : starsCareGapReq.getStarCareGaps()) {
				for (StarCareGap readValueGap : readValue.getStarCareGaps()) {
					if(readValueGap.getGapId() == starCareGap.getGapId()){
						readValueGap.setRequestedAction(starCareGap.getRequestedAction());
						readValueGap.setInfoRcvdtocloseGap(starCareGap.getInfoRcvdtocloseGap());
						readValueGap.setGapClsrSCCFId(starCareGap.getGapClsrSCCFId());
						readValueGap.setClsrSFReceiptDt(starCareGap.getClsrSFReceiptDt());
						readValueGap.setGapMeasure(starCareGap.getGapMeasure());
						readValueGap.setGapIdentificationRationale(starCareGap.getGapIdentificationRationale());
						readValueGap.setAddlInfotoHostPlan(starCareGap.getAddlInfotoHostPlan());
						readValueGap.setProspRetrospId(starCareGap.getProspRetrospId());
					}
				}
			}
			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		} catch (JsonParseException ex) {
			LOGGER.error("Error Occuring updatePexReqtJsonDetails JsonParseException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (JsonMappingException ex) {
			LOGGER.error("Error Occuring updatePexReqtJsonDetails JsonMappingException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (IOException ex) {
			LOGGER.error("Error Occuring updatePexReqtJsonDetails IOException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	public void updatePexTableColumns(StarsCareGapReq careGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		try {
			PexReqtMembQueue pexReqtMembQueue;
			pexReqtMembQueue = pexReqtMembQueueList.get(0);

			pexReqtMembQueue.setAudUpdtId("SYSTEM");
			pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
			pexReqtMembQueue.setMembDob(careGapReq.getMemberDOB());//updatable
			//new
			pexReqtMembQueue.setCpbltyIndcCd(careGapReq.getCapabilityInd());
			pexReqtMembQueue.setHmPlanId(careGapReq.getHomePlanId());
			pexReqtMembQueue.setItsSubscrId(careGapReq.getITSSubscriberId());
			pexReqtMembQueue.setBillProvId(careGapReq.getBillProvProprietaryId());
			pexReqtMembQueue.setRndrProvId(careGapReq.getRndrngProvProprietaryId());
			pexReqtMembQueue.setBillProvNpi(careGapReq.getBillProvNPI());
			pexReqtMembQueue.setRndrProvNpi(careGapReq.getRndrngProvNPI());
			pexReqtMembQueue.setRndrProvHstPlnId(careGapReq.getRndrngProvHostPlanId());
			pexReqtMembQueue.setBillProvZipCd(careGapReq.getBillProvZipCode());
			pexReqtMembQueue.setRndrProvZipCd(careGapReq.getRndrngProvZipCode());
			pexReqtMembQueue.setSccfId(careGapReq.getSCCFIds());
			pexReqtMembQueue.setProvEngmtIndc(careGapReq.getProvEngagementInd());
			pexReqtMembQueue.setRndrProvTaxId(careGapReq.getRndrngProvTaxId());
			//new
			pexReqtMembQueue.setPrevGapClsProv(careGapReq.getGapPrevouslyClosedByThisProv());
			pexReqtMembQueue.setAddnlInfo(careGapReq.getRndrngProvAddlInfo());
			pexReqtMembQueue.setRndrProvTnxmyCd(careGapReq.getRndrngProvTxnmyCd());
			pexReqtMembQueue.setMembHstPlnId(careGapReq.getMemberHostPlanId());
			pexReqtMembQueue.setRoutHstPlnId(careGapReq.getRoutetoHostPlanId());
			pexReqtMembQueue.setIntlHstPlnDt(careGapReq.getFirstTimeSenttoHostPlanDt());
			pexReqtMembQueue.setLastMrrProvEngmtRetId(careGapReq.getLastMRRProvEngmntReqID());
			pexReqtMembQueue.setLastMedRecReqtDt(careGapReq.getLastMedRecReqRcptDt());
			pexReqtMembQueue.setLastMedRecReqtBegDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			pexReqtMembQueue.setLastMedRecReqtEndDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			pexReqtMembQueue.setMmiId(careGapReq.getMMIId());
			pexReqtMembQueue.setMembFullNm(careGapReq.getMemberFullName());
			pexReqtMembQueue.setMembGndr(careGapReq.getMemberGender());
			pexReqtMembQueue.setProvPlnCd(careGapReq.getMemberPCP5PartKey().getProvPlanCd());
			pexReqtMembQueue.setProvProdCd(careGapReq.getMemberPCP5PartKey().getProductCd());
			pexReqtMembQueue.setProvNum(careGapReq.getMemberPCP5PartKey().getProvNum());
			pexReqtMembQueue.setProvSufx(careGapReq.getMemberPCP5PartKey().getProvNumSuffix());
			pexReqtMembQueue.setProvNtwrkLoc(careGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
			pexReqtMembQueue.setProvPartStus(careGapReq.getProvCntrctingSts());

			updateGaps(pexReqtMembQueue, careGapReq);
			pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
		} catch (Exception ex) {
			LOGGER.error("Error Occuring updatePexTableColumns :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	public void updateGaps(PexReqtMembQueue pexReqtMembQueue, StarsCareGapReq careGapReq) {
		if (!careGapReq.getStarCareGaps().isEmpty()) {

			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			for (StarCareGap starCareGap : careGapReq.getStarCareGaps()) {
				List<PexMembGapsDtl> gaps = pexMembGapsDtlDAO.findByGapIdAndPexReqtMembQueueSkey(
						new BigDecimal(starCareGap.getGapId()), pexReqtMembQueue.getPexReqtMembQueueSkey());
				if (!gaps.isEmpty()) {
					PexMembGapsDtl gap = gaps.get(0);

					gap.setAudUpdtId("SYSTEM");
					gap.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
					gap.setReqtdActn(starCareGap.getRequestedAction());//updatable
					gap.setHmPlnGapClsIndc(starCareGap.getHomePlanGaplvlClsrInd());//updatable
					gap.setClsGapInfoRcvd(starCareGap.getInfoRcvdtocloseGap());//updatable
					gap.setClsSfDt(starCareGap.getClsrSFReceiptDt());//updatable
					gap.setSccfId(starCareGap.getGapClsrSCCFId());//updatable
//					gap.setHstPlnGapClsIndc(starCareGap.getHostPlanGaplvlClsrInd());

					
					//new
					gap.setGapMeasCd(starCareGap.getGapMeasure());
					gap.setGapIdtfnRtnl(starCareGap.getGapIdentificationRationale());
					gap.setAddlInfoHostPln(starCareGap.getAddlInfotoHostPlan());
					gap.setProsRetIdntCd(starCareGap.getProspRetrospId());
					//new
					pexMembGapsDtlDAO.saveAndFlush(gap);
					hmPlanClsrIndList.add(gap.getHmPlnGapClsIndc());
					hostPlanClsrIndList.add(gap.getHstPlnGapClsIndc());
				}
			}
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList, hostPlanClsrIndList);
		}
	}

	public void updateReqtStusCode(PexReqtMembQueue pexReqtMembQueue, List<String> hmPlanClsrIndList, List<String> hostPlanClsrIndList) {
		boolean areAllGapsClosed = true;
		boolean allhstPlanInd = true;
		String[] clsInd = Constants.CLSR_IND;
		for(String hmPlanClsrInd : hmPlanClsrIndList){
			if(!(Arrays.asList(clsInd).contains(hmPlanClsrInd))){
				areAllGapsClosed = false;
				break;
			}
		}
		if(areAllGapsClosed){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
		Iterator<String> iterator = hostPlanClsrIndList.iterator();
		while (iterator.hasNext()) {
			String hstPlanInd = iterator.next();
			if(null == hstPlanInd || hstPlanInd.isEmpty()){
				allhstPlanInd = false;
				break;
			}
		}
		if(allhstPlanInd){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
	}

	public PexReqtMembQueue setJsonPojoToEntityClass(StarsCareGapReq careGapReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(careGapReq, pexReqtMembQueue);
		setPexMembGapDetails(careGapReq, pexReqtMembQueue);
		setPexReqtJsonDetails(careGapReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	public void setPexReqtMembQueueData(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setProvEngmtReqtId(careGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setBillProvNpi(careGapReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(careGapReq.getRndrngProvNPI());
		pexReqtMembQueue.setSccfId(careGapReq.getSCCFIds());
		pexReqtMembQueue.setRndrProvTnxmyCd(careGapReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setItsSubscrId(careGapReq.getITSSubscriberId());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(careGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setPrevGapClsProv(careGapReq.getGapPrevouslyClosedByThisProv());
		pexReqtMembQueue.setMmiId(careGapReq.getMMIId());
		pexReqtMembQueue.setBillProvId(careGapReq.getBillProvProprietaryId());
		pexReqtMembQueue.setCpbltyIndcCd(careGapReq.getCapabilityInd());
		pexReqtMembQueue.setHmPlanId(careGapReq.getHomePlanId());
		pexReqtMembQueue.setMembFullNm(careGapReq.getMemberFullName());
		pexReqtMembQueue.setMembHstPlnId(careGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setProvEngmtIndc(careGapReq.getProvEngagementInd());
		pexReqtMembQueue.setProvPartStus(careGapReq.getProvCntrctingSts());
		pexReqtMembQueue.setRndrProvHstPlnId(careGapReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setRndrProvId(careGapReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setRoutHstPlnId(careGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(careGapReq.getBillProvZipCode());
		pexReqtMembQueue.setIntlHstPlnDt(careGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue
		.setLastMedRecReqtBegDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtDt(careGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMembDob(careGapReq.getMemberDOB());
		pexReqtMembQueue.setProvNtwrkLoc(careGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setProvNum(careGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvPlnCd(careGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(careGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvSufx(careGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setRndrProvZipCd(careGapReq.getRndrngProvZipCode());
		pexReqtMembQueue.setCloseGapCnt(new BigDecimal(careGapReq.getNumofGapClosures()));
		pexReqtMembQueue.setMembGndr(careGapReq.getMemberGender());
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);
		pexReqtMembQueue.setAddnlInfo(careGapReq.getRndrngProvAddlInfo());
		pexReqtMembQueue.setRndrProvTaxId(careGapReq.getRndrngProvTaxId());
		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(careGapReq.getRndrngProvProprietaryId(), pexReqtMembQueue);		

	}

	public void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				boolean isStatusCheck = false;
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderName ::::::::: "
									+ practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							
							/*if(practitioner.getNetworkDetails().size() > 0) {
								for(NetworkDetails networkDetails : practitioner.getNetworkDetails()) {
									if(Constants.NT_ID_200.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(!Constants.NT_ID_200.equals(networkDetails.getNetworkID()) || !Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = false;
										break;
									}
								}
							} 
							
							if(isStatusCheck) {
								pexReqtMembQueue.setProvPartStus("N");
							} else {
								pexReqtMembQueue.setProvPartStus("P");
							}*/
							
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	public void setPexMembGapDetails(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue) {
		if (!careGapReq.getStarCareGaps().isEmpty()) {
			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			for (StarCareGap starCareGap : careGapReq.getStarCareGaps()) {
				PexMembGapsDtl pexMembGapsDtl = new PexMembGapsDtl();
				pexMembGapsDtl.setAudInsrtId("SYSTEM");
				pexMembGapsDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAudUpdtId("SYSTEM");
				pexMembGapsDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAddlInfoHostPln(starCareGap.getAddlInfotoHostPlan());
				pexMembGapsDtl.setGapId(new BigDecimal(starCareGap.getGapId()));
				pexMembGapsDtl.setGapMeasCd(starCareGap.getGapMeasure());
				pexMembGapsDtl.setGapIdtfnRtnl(starCareGap.getGapIdentificationRationale());
				pexMembGapsDtl.setReqtdActn(starCareGap.getRequestedAction());
				pexMembGapsDtl.setHmPlnGapClsIndc(starCareGap.getHomePlanGaplvlClsrInd());
				pexMembGapsDtl.setClsGapInfoRcvd(starCareGap.getInfoRcvdtocloseGap());
				pexMembGapsDtl.setClsSfDt(starCareGap.getClsrSFReceiptDt());
				pexMembGapsDtl.setSccfId(starCareGap.getGapClsrSCCFId());
				pexMembGapsDtl.setHstPlnGapClsIndc(starCareGap.getHostPlanGaplvlClsrInd());
				pexMembGapsDtl.setProsRetIdntCd(starCareGap.getProspRetrospId());

				//Set Column default Values
				pexMembGapsDtl.setGapMeasTyp("STAR_MEAS_SCGRE_TYP");
				pexMembGapsDtl.setHmPlnGapClsTyp("HM_PLN_GAP_CLS");
				pexMembGapsDtl.setHstPlnGapClsTyp("HST_PLN_GAP_CLS_INDC");
				pexMembGapsDtl.setRskAdjGapTyp("RSK_ADJ_GAP_TYP");
				pexMembGapsDtl.setHccClmTyp("HCC_CLM_TYP");
				pexMembGapsDtl.setProsRetIdntTyp("PROS_RET_IDNT");

				pexReqtMembQueue.addPexMembGapsDtl(pexMembGapsDtl);
				hmPlanClsrIndList.add(pexMembGapsDtl.getHmPlnGapClsIndc());
				hostPlanClsrIndList.add(pexMembGapsDtl.getHstPlnGapClsIndc());
			}
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList, hostPlanClsrIndList);
		}
	}

	public void setPexReqtJsonDetails(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String starCareGapReqJson = mapper.writeValueAsString(careGapReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(starCareGapReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}
	
	public List<ErrorResponse> starcareErrorResponse(StarsCareGapReqObj starsCareGapReqObj, String filename)
			throws Exception {
		int firstIndx = filename.indexOf(Constants.ERROR_REPORT_STR);
		int last = filename.indexOf(Constants.DOT);
		String fileName = filename.substring(firstIndx, last);
		List<ErrorResponse> errorResponses = new ArrayList<>();
		if(starsCareGapReqObj != null) {
			if(!starsCareGapReqObj.getStarsCareGapReq().isEmpty()) {
				for(StarsCareGapReq careGapReq : starsCareGapReqObj.getStarsCareGapReq()) {
					if(careGapReq.getErrCd() != null) {
						ErrorResponse errorResponse = new ErrorResponse();
						errorResponse.setCategory(Constants.CATEGORY_IND_SC);
						errorResponse.setFileName(fileName.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING));
						errorResponse.setErrorCode(careGapReq.getErrCd());
						errorResponse.setErrorDesc(careGapReq.getErrDesc());
						errorResponse.setProviderEngagementID(careGapReq.getProvEngmntReqId());
						errorResponses.add(errorResponse);
					}
				}
			}
		}
		return errorResponses;
	}


}
