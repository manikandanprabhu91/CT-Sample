package com.carefirst.icentric.batch.constant;

public class Constants {
	public static final String[] CLSR_IND = {"C", "D", "W" , "R", "S"};
	
	public static final String OPEN = "PEX_REQT_STUS01";
	public static final String IN_PROGRESS = "PEX_REQT_STUS02";
	public static final String PENDING_CLOSURE = "PEX_REQT_STUS03";
	public static final String CLOSED = "PEX_REQT_STUS04";
	public static final String CATEGORY_IND = "categoryInd";
	public static final String CATEGORY_IND_SC = "SC";
	public static final String CATEGORY_IND_RA = "RA";
	public static final String CATEGORY_IND_MR = "MR";
	public static final String MATCHED = "Matched";
	public static final String NOTE = "Note: ";
	public static final String HTML_HEAD = "<head>\r\n" + 
	"<style>\r\n" + 
	"table, th, td {\r\n" + 
	"  border: 1px solid black;\r\n" + 
	"  border-collapse: collapse;\r\n" + 
	"}\r\n" + 
	"th, td {\r\n" + 
	"  padding: 5px;\r\n" + 
	"}\r\n" + 
	"th {\r\n" + 
	"  text-align: left;\r\n" + 
	"}\r\n" + 
	"</style>\r\n" + 
	"</head>";
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static final String NT_ID_200 = "200";
	public static final String NT_ID_074 = "074";
	public static final String HOMEPLANID = "HomePlanId";
	public static final String LASTMRRPROVENGMNTREQID = "LastMRRProvEngmntReqID";
	public static final String LASTMEDRECREQRCPTDT = "LastMedRecReqRcptDt";
	public static final String ITSSUBSCRIBERID = "ITSSubscriberId";
	public static final String MEMBERDOB = "MemberDOB";
	public static final String MMIID = "MMIId";
	public static final String MEMBERFULLNAME = "MemberFullName";
	public static final String MEMBERGENDER = "MemberGender";
	public static final String NUMOFGAPCLOSURES = "NumofGapClosures";
	public static final String BILLPROVPROPRIETARYID = "BillProvProprietaryId";
	public static final String BILLPROVNPI = "BillProvNPI";
	public static final String RNDRNGPROVNPI = "RndrngProvNPI";
	public static final String RNDRNGPROVHOSTPLANID = "RndrngProvHostPlanId";
	public static final String BILLPROVZIPCODE = "BillProvZipCode";
	public static final String RNDRNGPROVZIPCODE = "RndrngProvZipCode";
	public static final String RNDRNGPROVTXNMYCD = "RndrngProvTxnmyCd";
	public static final String SCCFIDS = "SCCFIds";
	public static final String PRESENTDIAGNOSES = "PresentDiagnoses";
	public static final String CURRENTDIAGNOSESRNDRNGPROVNPI = "CurrentDiagnosesRndrngProvNPI";
	public static final String PROVENGAGEMENTIND = "ProvEngagementInd";
	public static final String PROVCNTRCTINGSTS = "ProvCntrctingSts";
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public static final String GAPID = "GapId";
	public static final String RISKADJGAPTYPE = "RiskAdjGapType";
	public static final String MISSINGDIAGCD = "MissingDiagCd";
	public static final String MISSINGDIAGCDDESC = "MissingDiagCdDesc";
	public static final String MISSINGHCCCD = "MissingHCCCd";
	public static final String MISSINGHCCCDDESC = "MissingHCCCdDesc";
	public static final String GAPIDENTIFICATIONRATIONALE = "GapIdentificationRationale";
	public static final String PROSPRETROSPID = "ProspRetrospId";
	public static final String REQUESTEDACTION = "RequestedAction";
	public static final String HOMEPLANGAPLVLCLSRIND = "HomePlanGaplvlClsrInd";
	public static final String INFORCVDTOCLOSEGAP = "InfoRcvdtocloseGap";
	public static final String GAPCLSRSCCFID = "GapClsrSCCFId";
	public static final String CLSRSFRECEIPTDT = "ClsrSFReceiptDt";
	public static final String HOSTPLANGAPLVLCLSRIND = "HostPlanGaplvlClsrInd";
	public static final String MEMBERHOSTPLANID = "MemberHostPlanId ";
	public static final String MISSINGDIAGCDSERVDT = "MissingDiagCdServDt";
	public static final String ROUTETOHOSTPLANID = "RoutetoHostPlanId";
	public static final String FIRSTTIMESENTTOHOSTPLANDT = "FirstTimeSenttoHostPlanDt";
	public static final String RNDRNGPROVPROPRIETARYID = "RndrngProvProprietaryId";
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////////////////******StarCare request fields /////////////////////////////////////////////////////////////////
	public static final String GAPMEASURE = "GapMeasure";
	public static final String ADDLINFOTOHOSTPLAN = "AddlInfotoHostPlan";
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	public static final String EMPTY_STRING = "";
	public static final String OPEN_BRACKET = "(";
	public static final String CLOSE_BRACKET = ")";
	public static final String MINUS_SYMBOL = " - ";
	public static final String HTML_BR_TAG = "<br>";
	public static final String HTML_BR_TAG_END = "</br>";
	public static final String HASH_SYMBOL = "# ";
	public static final String EMPTY_STRING_SPACE = " ";
	public static final String ERROR_REPORT = "error_report_";
	public static final String DOT = ".";
	public static final String XLS = ".xls";
	public static final String CONTENTTYPE = "text/html";
	public static final String ERROR_REPORT_STR = "error_report";
	public static final String COMMA = ",";
	public static final String PS_COUNT_CONTENT = " Status Count : ";
	public static final String PS_COUNT_QUERY = "select req.* from PCMH_RSTR.PEX_REQT_MEMB_QUEUE req, PCMH_RSTR.PEX_MEMB_GAPS_DTLS gap where req.PEX_REQT_MEMB_QUEUE_SKEY  = gap.PEX_REQT_MEMB_QUEUE_SKEY(+) AND req.REQT_STUS_CD='PEX_REQT_STUS03'";
	//select req from PCMH_RSTR.PEX_REQT_MEMB_QUEUE req, PCMH_RSTR.PEX_MEMB_GAPS_DTLS gap where req.PEX_REQT_MEMB_QUEUE_SKEY  = gap.PEX_REQT_MEMB_QUEUE_SKEY
	public static final String TRUE = "true";
	
	
	
	
}
