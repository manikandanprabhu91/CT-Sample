package com.carefirst.icentric.batch.utils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.apache.commons.lang3.exception.ExceptionUtils;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

@Component
public class FileUtils {
	private static final Logger LOGGER = LogManager.getLogger(FileUtils.class);

	@Value("${medvantage.inbound.path}")
	private String inBoundPath;

	@Value("${medvantage.inbound.archive.path}")
	private String archivePath;

	@Value("${medvantage.inbound.archive.error.path}")
	private String archiveErrorPath;


	@Value("${medvantage.inbound.rdrive.path}")
	private String rDrivePath;

	@Value("${medvantage.inbound.planCodes}")
	private String planCodes;

	@Value("${medvantage.inbound.pattern}")
	private String patternString;

	public final String UNDERSCORE = "_";

	public String getInBoundPath() {
		return inBoundPath;
	}

	public String getArchivePath() {
		return archivePath;
	}

	public String getArchiveErrorPath() {
		return archiveErrorPath;
	}

	public String getrDrivePath() {
		return rDrivePath;
	}

	public String getPatternString() {
		return patternString;
	}

	// File types are sc, ra and mr
	public List<FileSystemResource> getFiles(String fileType) {
		List<String> planCodes = getPlancodes();
		File directoryPath = null;
		if("error_report".equals(fileType)) {
			directoryPath = new File(archivePath);
		} else {
			directoryPath = new File(inBoundPath);
		}


		Pattern digitPattern = Pattern.compile(patternString);
		List<FileSystemResource> fileSystemResourcePath = new ArrayList<>();
		File[] files = directoryPath.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				boolean returnVar = false;
				for (String planCode : planCodes) {
					if("error_report".equals(fileType)) {
						returnVar = true;
						break;
					} else {
						if ((name.toLowerCase().contains(fileType.toLowerCase()) && name.toLowerCase().contains(planCode) && 
								name.toLowerCase().contains(UNDERSCORE+fileType))) {
							returnVar = true;
							break;
						} else if (name.toLowerCase().contains(fileType.toLowerCase()) && digitPattern.matcher(name.substring(0, 3)).matches()) {
							returnVar = true;
							break;
						}
					}
				}
				return returnVar;
			}
		});
		for (File file : files) {
			if (!file.getName().isEmpty()) {
				fileSystemResourcePath.add(new FileSystemResource(file.getPath()));
			}
		}
		return fileSystemResourcePath;
	}

	private List<String> getPlancodes() {
		List<String> planCodeList = new ArrayList<>();
		if (planCodes.contains(",")) {
			planCodeList = Arrays.stream(planCodes.split(",")).collect(Collectors.toList());
		} else {
			planCodeList.add(planCodes);
		}
		return planCodeList;
	}

	public List<FileSystemResource> getInbFiles(String fileType, String errorType) {
		File directoryPath = null;
		if("error_report".equals(errorType)) {
			directoryPath = new File(archivePath);
		} else {
			directoryPath = new File(inBoundPath);
		}
		
		List<FileSystemResource> fileSystemResourcePath = new ArrayList<>();
		File[] files = directoryPath.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				return (name.toLowerCase().contains(fileType.toLowerCase()));
			}
		});
		for (File file : files) {
			if (!file.getName().isEmpty()) {
				fileSystemResourcePath.add(new FileSystemResource(file.getPath()));
			}
		}
		return fileSystemResourcePath;
	}

	public void archiveInboundFiles(String fileIndicator, String fileType, String errorType) throws IOException {
		List<FileSystemResource> files = getInbFiles(fileIndicator, errorType);
		for (FileSystemResource fileSystemResource : files) {
			if("json".equals(fileType) && fileSystemResource.getFilename().toLowerCase().contains("_"+fileIndicator.toLowerCase())) {
				archiveInbountFileByFileType(fileSystemResource);
			} else if ("attachment".equals(fileType) && !(fileSystemResource.getFilename().toLowerCase().contains("_"+fileIndicator.toLowerCase()))) {
				archiveInbountFileByFileType(fileSystemResource);
			}
		}


	}	

	public void archiveInbountFileByFileType(FileSystemResource sourceFile) {

		try {

			Date date = new Date();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
			String renamed = "";
			String[] fn = sourceFile.getFile().getName().split("\\.");
			if(sourceFile.getFile().getName().contains("error_report")) {
				renamed = archiveErrorPath + File.separator + fn[0] + "_" + dateFormat.format(date) + "." + fn[1];
			} else {
				if(fn.length > 1) {
					renamed = archivePath + File.separator + fn[0] + "_" + dateFormat.format(date) + "." + fn[1];
				} else {
					renamed = archivePath + File.separator + fn[0] + "_" + dateFormat.format(date);
				}
			}
			File destFile = new File(renamed);
			sourceFile.getFile().renameTo(destFile);
			// deleted = sourceFile.delete()

		} catch (Exception e) {
			LOGGER.error(ExceptionUtils.getStackTrace(e));
		}

	}

	public void modifyJsonFileContent(String filePath, String key) {
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader(filePath));
			JSONObject jsonObject = (JSONObject) obj;
			JSONArray requestJsonArray = (JSONArray) jsonObject.get(key);

			FileWriter writer = new FileWriter(filePath);
			writer.write(requestJsonArray.toJSONString());
			writer.flush();
			writer.close();

		} catch (Exception e) {
			LOGGER.error(ExceptionUtils.getStackTrace(e));
		}
	}

	public String getFileName(String fileName, String categoryInd) {

		String emailFileName = "";
		try{
			String filename[] = fileName.substring(fileName.indexOf(categoryInd.toLowerCase()+"_")+3).split("_");
			if(filename.length > 0)
				emailFileName = fileName.substring(0, fileName.indexOf("_"))+"_"+categoryInd.toLowerCase()+"_"+filename[0]+".json";
		} catch (Exception e) {
			LOGGER.error("Error Occuring while consructing the file name::::::::: "+e.getMessage());
		}
		return emailFileName;
	}
	
	
	public String getDateString(String fileName, String categoryInd) throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat dateFormatTwo = new SimpleDateFormat("MM/dd/yyyy");
		String date = "";
		int indexFirst = fileName.indexOf(categoryInd+"_")+3;
		String filename[] = fileName.substring(indexFirst).split("_");
		if(filename.length > 0) {
			date = dateFormatTwo.format(dateFormat.parse(filename[2].substring(0, 8)));	
		}
		return date;
	}
	
	public String getPendingStatusDate() {
		LocalDate today = LocalDate.now();
		int year = today.getYear();
		String month = Calendar.getInstance().getDisplayName(Calendar.MONTH,
				Calendar.LONG, Locale.ENGLISH);
		return "01"+"-"+month+"-"+year;
	}
	
	public File[] getExtractFile(String filePath) {
		File workingDirectory = new File(filePath);
		File[] listOfFiles = workingDirectory.listFiles(new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				 return name.startsWith("PEX_Report_MR_RA_SC");
			}
		});
		return listOfFiles;
	}

	
}
