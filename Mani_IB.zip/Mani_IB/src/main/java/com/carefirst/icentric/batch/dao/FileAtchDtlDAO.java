package com.carefirst.icentric.batch.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carefirst.icentric.batch.entity.FileAtchDtl;

@Repository
public interface FileAtchDtlDAO  extends JpaRepository<FileAtchDtl, Long>{

}
