//package com.carefirst.icentric.batch.config;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.batch.core.JobParameter;
//import org.springframework.batch.core.JobParameters;
//import org.springframework.batch.core.JobParametersInvalidException;
//import org.springframework.batch.core.explore.JobExplorer;
//import org.springframework.batch.core.launch.JobLauncher;
//import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
//import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
//import org.springframework.batch.core.repository.JobRestartException;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.scheduling.annotation.SchedulingConfigurer;
//import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
//import org.springframework.scheduling.config.ScheduledTaskRegistrar;
//import org.springframework.stereotype.Component;
//
//import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
//import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
//import com.carefirst.icentric.batch.exception.ApplicationException;
//
///**
// * @author aaa6364
// *
// */
//@Component
//public class PCMHIndicatorJobScheduler implements SchedulingConfigurer {
//	private static final Logger LOGGER = LogManager.getLogger(PCMHIndicatorJobScheduler.class);
//
//	private static final int POOL_SIZE = 10;
//	
//	@Autowired
//	private JobLauncher jobLauncherPcmhFlag;
//	
//	@Autowired
//	private JobExplorer pcmhIndicatorUpdateJobExplorer;
//
//	@Autowired
//	PexMembGapsDtlDAO pexMembGapsDtlDAO;
//	
//	@Autowired
//	PexReqtMembQueueDAO pexMemQueueDao;
//	
//	@Autowired
//	private PCMHFlagUpdateJobConfig pcmhFlagUpdateJobConfig;
//	
//	@Scheduled(cron = "${medvantage.inbound.batch.pcmhflag.cron}")
//	public void PcmhIndicatorScheduler() {
//		LOGGER.info("> PcmhIndicatorScheduler");
//		Map<String, JobParameter> jobParamMap = new HashMap<>();
//		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
//		JobParameters jobParams = new JobParameters(jobParamMap);
//		updatePcmhIndicator(jobParams);
//		LOGGER.info("< PcmhIndicatorScheduler");
//	}
//
//	@Override
//	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
//		LOGGER.info("> configureTasks");
//		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
//		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
//		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
//		threadPoolTaskScheduler.initialize();
//
//		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
//		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
//		
//	}
//	
//	private void updatePcmhIndicator(JobParameters jobParams){
//		LOGGER.info("> updatePcmhIndicator");
//		try {
//			while (true) {
//				Set<org.springframework.batch.core.JobExecution> jobExecutions = pcmhIndicatorUpdateJobExplorer
//						.findRunningJobExecutions(pcmhFlagUpdateJobConfig.PCMHFlagUpdateBatchJob().getName());
//				boolean runFilejob = !jobExecutions.isEmpty();
//				if (runFilejob) {
//					LOGGER.info("pcmhFlagUpdate Job is already running waiting to restart");
//					try {
//						Thread.sleep(30000);
//					} catch (InterruptedException e) {
//						LOGGER.error("Exception Occued :" + e.getMessage(), e);
//					}
//				} else {
//					LOGGER.info("Starting the pcmhFlagUpdate job");
//					break;
//				}
//			}
//			jobLauncherPcmhFlag.run(pcmhFlagUpdateJobConfig.PCMHFlagUpdateBatchJob(), jobParams);
//		} catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
//				| JobParametersInvalidException | JobRestartException | ApplicationException e) {
//			LOGGER.error("Exception Occued :" + e.getMessage(), e);
//		} 
//		LOGGER.info("< updatePcmhIndicator");
//	}
//
//}
