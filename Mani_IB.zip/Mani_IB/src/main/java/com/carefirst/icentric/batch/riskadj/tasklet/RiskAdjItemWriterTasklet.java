package com.carefirst.icentric.batch.riskadj.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGapReqObj;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjustmentGapReq;
import com.carefirst.icentric.batch.utils.RiskAdjUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to process riskadj records and store the data into DB.
 * @author aad7740
 *
 */
public class RiskAdjItemWriterTasklet implements Tasklet, StepExecutionListener{

	private static final Logger LOGGER = LogManager.getLogger(RiskAdjItemWriterTasklet.class);
			
	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	String fileName;
	
	@Autowired
	RiskAdjUtils riskAdjUtils;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("riskAdjFileName");
		fileName = (String) param.getValue();
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		LOGGER.info(" Entering RiskAdjItemWriter");

		try {
			
			InputStream stream = new FileInputStream(new File(fileName));
			RiskAdjGapReqObj adjGapReqObj = new ObjectMapper().readValue(stream, RiskAdjGapReqObj.class);
			
			for (RiskAdjustmentGapReq riskAdjGapReq : adjGapReqObj.getRiskAdjustmentGapReq()) {

				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO
						.findByProvEngmtReqtId(riskAdjGapReq.getProvEngmntReqId());
				if (pexReqtMembQueueList.isEmpty()) {
					pexReqtMembQueue = riskAdjUtils.setJsonPojoToEntityClass(riskAdjGapReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				} else {
					riskAdjUtils.updatePexTableColumns(riskAdjGapReq,pexReqtMembQueueList);
					riskAdjUtils.updatePexReqtJsonDetails(riskAdjGapReq, pexReqtMembQueueList);
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Exception found while reading the response:: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		
		LOGGER.info(" Exiting RiskAdjItemWriter");
		return RepeatStatus.FINISHED;
	}

}
