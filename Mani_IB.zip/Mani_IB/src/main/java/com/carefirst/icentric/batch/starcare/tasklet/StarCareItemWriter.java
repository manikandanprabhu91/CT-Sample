package com.carefirst.icentric.batch.starcare.tasklet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.icentric.batch.starcare.model.StarCareGap;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class StarCareItemWriter implements ItemWriter<StarsCareGapReq> {

	private static final Logger LOGGER = LogManager.getLogger(StarCareItemWriter.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	private FileUtils fileUtil;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	String fileName;

	@Autowired
	ProvSearch provSearch;
	
	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;

	/**
	 * 
	 * @param stepExecution
	 */
	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("starcareFileName");
		String filePath = (String) param.getValue();
		fileName = filePath.replaceAll(fileUtil.getInBoundPath(), "");
	}

	@Override
	public void write(List<? extends StarsCareGapReq> items) throws Exception {
		LOGGER.info(" Enter StarCareItemWriter");
		try {
			for (StarsCareGapReq careGapReq :items) {

				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO.findByProvEngmtReqtId(careGapReq.getProvEngmntReqId());
				if(pexReqtMembQueueList.isEmpty()){
					pexReqtMembQueue = setJsonPojoToEntityClass(careGapReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				}else{
					updatePexTableColumns(careGapReq, pexReqtMembQueueList);
					updatePexReqtJsonDetails(careGapReq, pexReqtMembQueueList);
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Exception found while reading the response:: :::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		LOGGER.info(" Exiting StarCareItemWriter");
	}

	private void updatePexReqtJsonDetails(StarsCareGapReq starsCareGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			StarsCareGapReq readValue = objectMapper.readValue(reqtJson, StarsCareGapReq.class);
			readValue.setMemberHostPlanId(starsCareGapReq.getMemberHostPlanId());
			readValue.setRoutetoHostPlanId(starsCareGapReq.getRoutetoHostPlanId());
			readValue.setFirstTimeSenttoHostPlanDt(starsCareGapReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(starsCareGapReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(starsCareGapReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(starsCareGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(starsCareGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(starsCareGapReq.getMemberDOB());
			readValue.setMMIId(starsCareGapReq.getMMIId());
			readValue.setMemberFullName(starsCareGapReq.getMemberFullName());
			readValue.setMemberGender(starsCareGapReq.getMemberGender());
			readValue.getMemberPCP5PartKey().setProvPlanCd(starsCareGapReq.getMemberPCP5PartKey().getProvPlanCd());
			readValue.getMemberPCP5PartKey().setProductCd(starsCareGapReq.getMemberPCP5PartKey().getProductCd());
			readValue.getMemberPCP5PartKey().setProvNum(starsCareGapReq.getMemberPCP5PartKey().getProvNum());
			readValue.getMemberPCP5PartKey().setProvNumSuffix(starsCareGapReq.getMemberPCP5PartKey().getProvNumSuffix());
			readValue.getMemberPCP5PartKey().setProvNetwrkLocSeqNum(starsCareGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
			readValue.setProvCntrctingSts(starsCareGapReq.getProvCntrctingSts());
			
			for (StarCareGap starCareGap : starsCareGapReq.getStarCareGaps()) {
				for (StarCareGap readValueGap : readValue.getStarCareGaps()) {
					if(readValueGap.getGapId() == starCareGap.getGapId()){
						readValueGap.setRequestedAction(starCareGap.getRequestedAction());
						readValueGap.setHomePlanGaplvlClsrInd(starCareGap.getHomePlanGaplvlClsrInd());
						readValueGap.setInfoRcvdtocloseGap(starCareGap.getInfoRcvdtocloseGap());
						readValueGap.setGapClsrSCCFId(starCareGap.getGapClsrSCCFId());
						readValueGap.setClsrSFReceiptDt(starCareGap.getClsrSFReceiptDt());
						readValueGap.setHostPlanGaplvlClsrInd(starCareGap.getHostPlanGaplvlClsrInd());
					}
				}
			}
			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void updatePexTableColumns(StarsCareGapReq careGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		
		pexReqtMembQueue.setMembHstPlnId(careGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(careGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(careGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(careGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(careGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMembDob(careGapReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(careGapReq.getMMIId());
		pexReqtMembQueue.setMembFullNm(careGapReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(careGapReq.getMemberGender());
		pexReqtMembQueue.setProvPlnCd(careGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(careGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(careGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(careGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(careGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setProvPartStus(careGapReq.getProvCntrctingSts());
		
		updateGaps(pexReqtMembQueue, careGapReq);
		pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
		
	}

	private void updateGaps(PexReqtMembQueue pexReqtMembQueue, StarsCareGapReq careGapReq) {
		if (!careGapReq.getStarCareGaps().isEmpty()) {
			
			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			
			for (StarCareGap starCareGap : careGapReq.getStarCareGaps()) {
				List<PexMembGapsDtl> gaps = pexMembGapsDtlDAO.findByGapIdAndPexReqtMembQueueSkey(
						new BigDecimal(starCareGap.getGapId()), pexReqtMembQueue.getPexReqtMembQueueSkey());
				if (!gaps.isEmpty()) {
					PexMembGapsDtl gap = gaps.get(0);
					
					gap.setAudUpdtId("SYSTEM");
					gap.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
					gap.setReqtdActn(starCareGap.getRequestedAction());
					gap.setHmPlnGapClsIndc(starCareGap.getHomePlanGaplvlClsrInd());
					gap.setClsGapInfoRcvd(starCareGap.getInfoRcvdtocloseGap());
					gap.setClsSfDt(starCareGap.getClsrSFReceiptDt());
					gap.setSccfId(starCareGap.getGapClsrSCCFId());
					gap.setHstPlnGapClsIndc(starCareGap.getHostPlanGaplvlClsrInd());
					
					pexMembGapsDtlDAO.saveAndFlush(gap);
					hmPlanClsrIndList.add(gap.getHmPlnGapClsIndc());
					hostPlanClsrIndList.add(gap.getHstPlnGapClsIndc());
				}
			}
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList, hostPlanClsrIndList);
		}
	}
	
	private void updateReqtStusCode(PexReqtMembQueue pexReqtMembQueue, List<String> hmPlanClsrIndList, List<String> hostPlanClsrIndList) {
		boolean areAllGapsClosed = true;
		String[] clsInd = Constants.CLSR_IND;
		for(String hmPlanClsrInd : hmPlanClsrIndList){
			if(!(Arrays.asList(clsInd).contains(hmPlanClsrInd))){
				areAllGapsClosed = false;
				break;
			}
		}
		if(areAllGapsClosed){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
		if(!hostPlanClsrIndList.contains(null) && !hostPlanClsrIndList.isEmpty()){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
	}

	private PexReqtMembQueue setJsonPojoToEntityClass(StarsCareGapReq careGapReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(careGapReq, pexReqtMembQueue);
		setPexMembGapDetails(careGapReq, pexReqtMembQueue);
		setPexReqtJsonDetails(careGapReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	private void setPexReqtMembQueueData(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setProvEngmtReqtId(careGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setBillProvNpi(careGapReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(careGapReq.getRndrngProvNPI());
		pexReqtMembQueue.setSccfId(careGapReq.getSCCFIds());
		pexReqtMembQueue.setRndrProvTaxId(careGapReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setItsSubscrId(careGapReq.getITSSubscriberId());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(careGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setProvEngmtReqtId(careGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setPrevGapClsProv(careGapReq.getGapPrevouslyClosedByThisProv());
		pexReqtMembQueue.setMmiId(careGapReq.getMMIId());
		pexReqtMembQueue.setBillProvId(careGapReq.getBillProvProprietaryId());
		pexReqtMembQueue.setCpbltyIndcCd(careGapReq.getCapabilityInd());
		pexReqtMembQueue.setHmPlanId(careGapReq.getHomePlanId());
		pexReqtMembQueue.setMembFullNm(careGapReq.getMemberFullName());
		pexReqtMembQueue.setMembHstPlnId(careGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setProvEngmtIndc(careGapReq.getProvEngagementInd());
		pexReqtMembQueue.setProvPartStus(careGapReq.getProvCntrctingSts());
		pexReqtMembQueue.setRndrProvHstPlnId(careGapReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setRndrProvId(careGapReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setRoutHstPlnId(careGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(careGapReq.getBillProvZipCode());
		pexReqtMembQueue.setIntlHstPlnDt(careGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue
		.setLastMedRecReqtBegDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtDt(careGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(careGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMembDob(careGapReq.getMemberDOB());
		pexReqtMembQueue.setProvNtwrkLoc(careGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setProvNum(careGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvPlnCd(careGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(careGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvSufx(careGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setRndrProvZipCd(careGapReq.getRndrngProvZipCode());
		pexReqtMembQueue.setCloseGapCnt(new BigDecimal(careGapReq.getNumofGapClosures()));
		pexReqtMembQueue.setMembGndr(careGapReq.getMemberGender());
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);

		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(careGapReq.getRndrngProvProprietaryId(), pexReqtMembQueue);		

	}

	private void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber ::::::::: "
									+ practitioner.getPractitionerFirstName() + ", "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderName::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerLastName() + ", "
									+ practitioner.getPractitionerFirstName());
							// pexReqtMembQueue.setRndrProvZipCd(practitioner.getPractitionerZip());
							// pexReqtMembQueue.setRndrProvNpi(practitioner.getPractitionerNPI());
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	private void setPexMembGapDetails(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue) {
		if (!careGapReq.getStarCareGaps().isEmpty()) {
			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			for (StarCareGap starCareGap : careGapReq.getStarCareGaps()) {
				PexMembGapsDtl pexMembGapsDtl = new PexMembGapsDtl();
				pexMembGapsDtl.setAudInsrtId("SYSTEM");
				pexMembGapsDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAudUpdtId("SYSTEM");
				pexMembGapsDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAddlInfoHostPln(starCareGap.getAddlInfotoHostPlan());
				pexMembGapsDtl.setGapId(new BigDecimal(starCareGap.getGapId()));
				pexMembGapsDtl.setGapMeasCd(starCareGap.getGapMeasure());
				pexMembGapsDtl.setGapIdtfnRtnl(starCareGap.getGapIdentificationRationale());
				pexMembGapsDtl.setReqtdActn(starCareGap.getRequestedAction());
				pexMembGapsDtl.setHmPlnGapClsIndc(starCareGap.getHomePlanGaplvlClsrInd());
				pexMembGapsDtl.setClsGapInfoRcvd(starCareGap.getInfoRcvdtocloseGap());
				pexMembGapsDtl.setClsSfDt(starCareGap.getClsrSFReceiptDt());
				pexMembGapsDtl.setSccfId(starCareGap.getGapClsrSCCFId());
				pexMembGapsDtl.setHstPlnGapClsIndc(starCareGap.getHostPlanGaplvlClsrInd());
				pexMembGapsDtl.setProsRetIdntCd(starCareGap.getProspRetrospId());

				//Set Column default Values
				pexMembGapsDtl.setGapMeasTyp("STAR_MEAS_SCGRE_TYP");
				pexMembGapsDtl.setHmPlnGapClsTyp("HM_PLN_GAP_CLS");
				pexMembGapsDtl.setHstPlnGapClsTyp("HST_PLN_GAP_CLS_INDC");
				pexMembGapsDtl.setRskAdjGapTyp("RSK_ADJ_GAP_TYP");
				pexMembGapsDtl.setHccClmTyp("HCC_CLM_TYP");
				pexMembGapsDtl.setProsRetIdntTyp("PROS_RET_IDNT");

				pexReqtMembQueue.addPexMembGapsDtl(pexMembGapsDtl);
				hmPlanClsrIndList.add(pexMembGapsDtl.getHmPlnGapClsIndc());
				hostPlanClsrIndList.add(pexMembGapsDtl.getHstPlnGapClsIndc());
			}
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList, hostPlanClsrIndList);
		}
	}

	private void setPexReqtJsonDetails(StarsCareGapReq careGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String starCareGapReqJson = mapper.writeValueAsString(careGapReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(starCareGapReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}

}
