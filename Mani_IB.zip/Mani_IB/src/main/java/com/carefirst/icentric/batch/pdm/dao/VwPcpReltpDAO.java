//package com.carefirst.icentric.batch.pdm.dao;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
//import com.carefirst.icentric.batch.pdm.entity.VwPcpReltp;
//
//@Repository
//public interface VwPcpReltpDAO  extends JpaRepository<VwPcpReltp, Long>{
//
//	@Query(value = "SELECT COUNT(PTNR_ID) "+
//	   "FROM PDM_PANL.VW_PCP_RELTP WHERE PTNR_ID = ?1"+
//       " AND SYSDATE BETWEEN PROV_EFFT_DT AND PROV_TERM_DT"+
//       " AND SYSDATE BETWEEN TAX_ENT_EFFT_DT AND TAX_ENT_TERM_DT"+
//       " AND SYSDATE BETWEEN PROV_ENT_ASSC_EFFT_DT AND PROV_ENT_ASSC_TERM_DT"+
//       " AND SYSDATE BETWEEN PTNR_MEDL_PANL_ASSC_EFFT_DT"+
//       " AND PTNR_MEDL_PANL_ASSC_TERM_DT"+
//       " AND SYSDATE BETWEEN MEDL_PANL_EFFT_DT AND MEDL_PANL_TERM_DT"+
//       " AND SYSDATE BETWEEN BUS_EFFT_FROM_DT AND BUS_EFFT_THRU_DT", 
//			  nativeQuery = true)
//	Long getMedlPanlId(String provid);
//
//}
