package com.carefirst.icentric.batch.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class ReportUtils {

	private static final Logger LOGGER = LogManager.getLogger(ReportUtils.class);

	@Autowired
	JavaMailSender javaMailSender;
	
	@Value("${extract.email.toAddress}")
	private String toAddress;
	
	@Value("${extract.email.fromAddress}")
	private String fromAddress;

	public <T> void writeToExcelInMultiSheets(final String fileName, final String sheetName, final List<T> data, String indicator) {
		LOGGER.info(">>>>>>>>>>>>>>>>>> writeToExcelInMultiSheets>>>>>>>>>>>");
		File file = null;
		OutputStream fos = null;
		XSSFWorkbook workbook = null;
		try {
			file = new File(fileName);
			Sheet sheet = null;
			if (file.exists()) {
				workbook = (XSSFWorkbook) WorkbookFactory.create(new FileInputStream(file));
			} else {
				workbook = new XSSFWorkbook();
			}
			sheet = workbook.createSheet(sheetName);
			List<String> fieldNames = getFieldNamesForClass(data.get(0).getClass());
			int rowCount = 0;
			int columnCount = 0;
			Row row = sheet.createRow(rowCount++);
			for (String fieldName : fieldNames) {
				Cell cell = row.createCell(columnCount++);
				cell.setCellValue(fieldName);
			}
			Class<? extends Object> classz = data.get(0).getClass();
			for (T t : data) {
				row = sheet.createRow(rowCount++);
				columnCount = 0;
				for (String fieldName : fieldNames) {
					
					Cell cell = row.createCell(columnCount);
					Method method = null;
					try {
						method = classz.getMethod("get" + capitalize(fieldName));
					} catch (NoSuchMethodException nme) {
						method = classz.getMethod("get" + fieldName);
					}
					Object value = method.invoke(t, (Object[]) null);
					if (value != null) {
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Long) {
							cell.setCellValue((Long) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						} else if (value instanceof Double) {
							cell.setCellValue((Double) value);
						}
					}
					columnCount++;
				}
			}
//			FileOutputStream out = new FileOutputStream(file);
//			workbook.write(out);
//			out.close();
			
			fos = new FileOutputStream(file);
			workbook.write(fos);
			fos.flush();
		} catch (Exception e) {
			LOGGER.error("::::::::::::Error Occuring extract report:::::::::::::::::::::: "+e.getMessage());
		} finally {
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException e) {
			}
			
		}
	}

	private List<String> getFieldNamesForClass(Class<?> clazz) throws Exception {
		List<String> fieldNames = new ArrayList<String>();
		Field[] fields = clazz.getDeclaredFields();
		for (int i = 0; i < fields.length; i++) {
			fieldNames.add(fields[i].getName());
		}
		return fieldNames;
	}

	private String capitalize(String s) {
		if (s.length() == 0)
			return s;
		return s.substring(0, 1).toUpperCase() + s.substring(1);
	}


	public void sendMail(File file) throws Exception{
		
		try {
			
			MimeMessage message = javaMailSender.createMimeMessage();
			MimeMessageHelper mailMessage = new MimeMessageHelper(message, true);
			String[] recipientList = toAddress.split(",");
			InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
			int counter = 0;
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("Email To :" + recipientList);
			}
			for (String recipient : recipientList) {
				recipientAddress[counter] = new InternetAddress(recipient.trim());
				counter++;
			}
			mailMessage.setTo(recipientAddress);
			mailMessage.setFrom(fromAddress);
			mailMessage.setSubject("SECURECOMM: MA Extract Report");
			MimeBodyPart mimeBodyPart = new MimeBodyPart();
			MimeMultipart mimeMultipart = new MimeMultipart();


			mimeBodyPart.setDataHandler(new DataHandler(new FileDataSource(file)));
			mimeBodyPart.setFileName(file.getName());
			mimeMultipart.addBodyPart(mimeBodyPart);
			message.setContent(mimeMultipart);
			javaMailSender.send(message);
			file.delete();

		} catch(Exception e) {
			LOGGER.error("Erorr Occuring while sending the email:::::::::::: "+e.getMessage());
		}
	}
}
