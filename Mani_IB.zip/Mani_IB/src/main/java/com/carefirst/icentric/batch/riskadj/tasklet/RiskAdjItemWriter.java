package com.carefirst.icentric.batch.riskadj.tasklet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.annotation.BeforeStep;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGap;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjustmentGapReq;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author aab8788
 *
 */
public class RiskAdjItemWriter implements ItemWriter<RiskAdjustmentGapReq> {

	private static final Logger LOGGER = LogManager.getLogger(RiskAdjItemWriter.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	private FileUtils fileUtil;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	@Autowired
	ProvSearch provSearch;

	String fileName;

	String fileExtension;
	
	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;

	/**
	 * 
	 * @param stepExecution
	 */
	@BeforeStep
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("riskAdjFileName");
		String filePath = (String) param.getValue();
		fileName = filePath.replaceAll(fileUtil.getInBoundPath(), "");
		
		
	}

	@Override
	public void write(List<? extends RiskAdjustmentGapReq> items) throws Exception {
		LOGGER.info(" Entering RiskAdjItemWriter");

		try {
			for (RiskAdjustmentGapReq riskAdjGapReq : items) {

				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO
						.findByProvEngmtReqtId(riskAdjGapReq.getProvEngmntReqId());
				if (pexReqtMembQueueList.isEmpty()) {
					pexReqtMembQueue = setJsonPojoToEntityClass(riskAdjGapReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				} else {
					 updatePexTableColumns(riskAdjGapReq,pexReqtMembQueueList);
					 updatePexReqtJsonDetails(riskAdjGapReq, pexReqtMembQueueList);
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Exception found while reading the response:: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		LOGGER.info(" Exiting RiskAdjItemWriter");
	}

	private void updatePexReqtJsonDetails(RiskAdjustmentGapReq riskAdjGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			RiskAdjustmentGapReq readValue = objectMapper.readValue(reqtJson, RiskAdjustmentGapReq.class);
			readValue.setMemberHostPlanId(riskAdjGapReq.getMemberHostPlanId());
			readValue.setRoutetoHostPlanId(riskAdjGapReq.getRoutetoHostPlanId());
			readValue.setFirstTimeSenttoHostPlanDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(riskAdjGapReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(riskAdjGapReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(riskAdjGapReq.getMemberDOB());
			readValue.setMMIId(riskAdjGapReq.getMMIId());
			readValue.setMemberFullName(riskAdjGapReq.getMemberFullName());
			readValue.setMemberGender(riskAdjGapReq.getMemberGender());
			readValue.getMemberPCP5PartKey().setProvPlanCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
			readValue.getMemberPCP5PartKey().setProductCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
			readValue.getMemberPCP5PartKey().setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
			readValue.getMemberPCP5PartKey().setProvNumSuffix(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
			readValue.getMemberPCP5PartKey().setProvNetwrkLocSeqNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
			readValue.setPresentDiagnoses(riskAdjGapReq.getPresentDiagnoses());
			readValue.setCurrentDiagnosesRndrngProvNPI(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI());
			readValue.setProvCntrctingSts(riskAdjGapReq.getProvCntrctingSts());
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				for (RiskAdjGap readValueGap : readValue.getRiskAdjGaps()) {
					if(readValueGap.getGapId() == riskAdjGap.getGapId()){
						readValueGap.setRequestedAction(riskAdjGap.getRequestedAction());
						readValueGap.setHomePlanGaplvlClsrInd(riskAdjGap.getHomePlanGaplvlClsrInd());
						readValueGap.setInfoRcvdtocloseGap(riskAdjGap.getInfoRcvdtocloseGap());
						readValueGap.setGapClsrSCCFId(riskAdjGap.getGapClsrSCCFId());
						readValueGap.setClsrSFReceiptDt(riskAdjGap.getClsrSFReceiptDt());
						readValueGap.setHostPlanGaplvlClsrInd(riskAdjGap.getHostPlanGaplvlClsrInd());
					}
				}
			}
			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		} catch (JsonParseException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	private void updatePexTableColumns(RiskAdjustmentGapReq riskAdjGapReq,
			List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setMembHstPlnId(riskAdjGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(riskAdjGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(riskAdjGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(riskAdjGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMembDob(riskAdjGapReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(riskAdjGapReq.getMMIId());
		pexReqtMembQueue.setMembFullNm(riskAdjGapReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(riskAdjGapReq.getMemberGender());
		pexReqtMembQueue.setProvPlnCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setPrsntDiag(riskAdjGapReq.getPresentDiagnoses());
		pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI()));
		pexReqtMembQueue.setProvPartStus(riskAdjGapReq.getProvCntrctingSts());

		updateGaps(pexReqtMembQueue, riskAdjGapReq);
		pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
	}

	private void updateGaps(PexReqtMembQueue pexReqtMembQueue, RiskAdjustmentGapReq riskAdjGapReq) {
		if (!riskAdjGapReq.getRiskAdjGaps().isEmpty()) {
			
			List<String> hmPlanClsrIndList = new ArrayList<>();
			
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				List<PexMembGapsDtl> gaps = pexMembGapsDtlDAO.findByGapIdAndPexReqtMembQueueSkey(
						new BigDecimal(riskAdjGap.getGapId()), pexReqtMembQueue.getPexReqtMembQueueSkey());
				if (!gaps.isEmpty()) {
					PexMembGapsDtl gap = gaps.get(0);
					gap.setAudUpdtId("SYSTEM");
					gap.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
					gap.setReqtdActn(riskAdjGap.getRequestedAction());
					gap.setHmPlnGapClsIndc(riskAdjGap.getHomePlanGaplvlClsrInd());
					gap.setClsGapInfoRcvd(riskAdjGap.getInfoRcvdtocloseGap());
					gap.setSccfId(riskAdjGap.getGapClsrSCCFId());
					gap.setClsSfDt(riskAdjGap.getClsrSFReceiptDt());
					gap.setHstPlnGapClsIndc(riskAdjGap.getHostPlanGaplvlClsrInd());
					
					pexMembGapsDtlDAO.saveAndFlush(gap);
					hmPlanClsrIndList.add(gap.getHmPlnGapClsIndc());
				}
			}
			
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList);
		}
	}
	

	private void updateReqtStusCode(PexReqtMembQueue pexReqtMembQueue, List<String> hmPlanClsrIndList) {
		boolean areAllGapsClosed = true;
		String[] clsInd = Constants.CLSR_IND;
		for(String hmPlanClsrInd : hmPlanClsrIndList){
			if(!(Arrays.asList(clsInd).contains(hmPlanClsrInd))){
				areAllGapsClosed = false;
				break;
			}
		}
		if(areAllGapsClosed){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
//			pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
		}
	}

	private PexReqtMembQueue setJsonPojoToEntityClass(RiskAdjustmentGapReq riskAdjGapReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(riskAdjGapReq, pexReqtMembQueue);
		setPexMembGapDetails(riskAdjGapReq, pexReqtMembQueue);
		setPexReqtJsonDetails(riskAdjGapReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	private void setPexReqtMembQueueData(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws Exception {

		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setProvEngmtReqtId(riskAdjGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setCpbltyIndcCd(riskAdjGapReq.getCapabilityInd());
		pexReqtMembQueue.setHmPlanId(riskAdjGapReq.getHomePlanId());
		pexReqtMembQueue.setMembHstPlnId(riskAdjGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(riskAdjGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(riskAdjGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(riskAdjGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setItsSubscrId(riskAdjGapReq.getITSSubscriberId());
		pexReqtMembQueue.setMembDob(riskAdjGapReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(riskAdjGapReq.getMMIId());
		// pexReqtMembQueue.setMembFrstNm(riskAdjGapReq.getMemberFullName());
		// //need to set first name
		// pexReqtMembQueue.setMembLastNm(riskAdjGapReq.getMemberFullName());
		// //need to set last name
		pexReqtMembQueue.setMembFullNm(riskAdjGapReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(riskAdjGapReq.getMemberGender());
		pexReqtMembQueue.setCloseGapCnt(new BigDecimal(riskAdjGapReq.getNumofGapClosures()));
		pexReqtMembQueue.setBillProvId(riskAdjGapReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(riskAdjGapReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setBillProvNpi(riskAdjGapReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(riskAdjGapReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(riskAdjGapReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(riskAdjGapReq.getBillProvZipCode());
		pexReqtMembQueue.setRndrProvZipCd(riskAdjGapReq.getRndrngProvZipCode());
		pexReqtMembQueue.setRndrProvTaxId(riskAdjGapReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setSccfId(riskAdjGapReq.getSCCFIds());
		// pexReqtMembQueue.setPrevGapClsProv(riskAdjGapReq.getGapPrevouslyClosedByThisProv());
		pexReqtMembQueue.setPrsntDiag(riskAdjGapReq.getPresentDiagnoses());
		pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI()));

		pexReqtMembQueue.setProvEngmtIndc(riskAdjGapReq.getProvEngagementInd());
		// pexReqtMembQueue.setProvPartStusTyp(riskAdjGapReq.getProvCntrctingSts());
		pexReqtMembQueue.setProvPartStus(riskAdjGapReq.getProvCntrctingSts());
		// pexReqtMembQueue.setMedRecMtchTyp(medRecMtchTyp);
		// pexReqtMembQueue.setMedRecMtchIndc(medRecMtchIndc);
		// pexReqtMembQueue.setHstPlnClsIndTyp(hstPlnClsIndTyp);
		// pexReqtMembQueue.setHstPlnClsInd(hstPlnClsInd);
		// pexReqtMembQueue.setReqtStusTyp(reqtStusTyp);
		// pexReqtMembQueue.setServcBegDt(servcBegDt);
		// pexReqtMembQueue.setServcEndDt(servcEndDt);
		pexReqtMembQueue
		.setLastMedRecReqtBegDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue
		.setLastMedRecReqtEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setProvPlnCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		// pexReqtMembQueue.setHmPlanClsIndTyp(hmPlanClsIndTyp);
		// pexReqtMembQueue.setHmPlanClsInd(hmPlanClsInd);
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);

		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(riskAdjGapReq.getRndrngProvProprietaryId(), pexReqtMembQueue);

	}

	private void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber ::::::::: "
									+ practitioner.getPractitionerFirstName() + ", "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderName::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerLastName() + ", "
									+ practitioner.getPractitionerFirstName());
							// pexReqtMembQueue.setRndrProvZipCd(practitioner.getPractitionerZip());
							// pexReqtMembQueue.setRndrProvNpi(practitioner.getPractitionerNPI());
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}


	private void setPexReqtJsonDetails(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String riskAdjGapReqJson = mapper.writeValueAsString(riskAdjGapReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(riskAdjGapReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}


	private void setPexMembGapDetails(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue) {
		if (!riskAdjGapReq.getRiskAdjGaps().isEmpty()) {
			List<String> hmPlanClsrIndList = new ArrayList<>();
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				PexMembGapsDtl pexMembGapsDtl = new PexMembGapsDtl();

				pexMembGapsDtl.setAudInsrtId("SYSTEM");
				pexMembGapsDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAudUpdtId("SYSTEM");
				pexMembGapsDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setGapId(new BigDecimal(riskAdjGap.getGapId()));
				pexMembGapsDtl.setMisDiagCd(riskAdjGap.getMissingDiagCd());
				pexMembGapsDtl.setMisDiagCdDesc(riskAdjGap.getMissingDiagCdDesc());
				pexMembGapsDtl.setMisHccCd(String.valueOf(riskAdjGap.getMissingHCCCd()));
				pexMembGapsDtl.setMisHccCdDesc(riskAdjGap.getMissingHCCCdDesc());
				pexMembGapsDtl.setMisDiagCdSrvcDt(riskAdjGap.getMissingDiagCdServDt());
				pexMembGapsDtl.setMisProvNpiDiagCd(riskAdjGap.getMissingDiagCdProvNPI());
				pexMembGapsDtl.setGapIdtfnRtnl(riskAdjGap.getGapIdentificationRationale());
				pexMembGapsDtl.setProsRetIdntCd(riskAdjGap.getProspRetrospId());
				pexMembGapsDtl.setReqtdActn(riskAdjGap.getRequestedAction());
				pexMembGapsDtl.setHmPlnGapClsIndc(riskAdjGap.getHomePlanGaplvlClsrInd());
				pexMembGapsDtl.setClsGapInfoRcvd(riskAdjGap.getInfoRcvdtocloseGap());
				pexMembGapsDtl.setSccfId(riskAdjGap.getGapClsrSCCFId());
				pexMembGapsDtl.setClsSfDt(riskAdjGap.getClsrSFReceiptDt());
				pexMembGapsDtl.setHstPlnGapClsIndc(riskAdjGap.getHostPlanGaplvlClsrInd());
				pexMembGapsDtl.setRskAdjGapCd(riskAdjGap.getRiskAdjGapType());
				pexMembGapsDtl.setHccClmCd(riskAdjGap.getHCCClaimType());
				//Set Column default Values
				pexMembGapsDtl.setGapMeasTyp("STAR_MEAS_SCGRE_TYP");
				pexMembGapsDtl.setHmPlnGapClsTyp("HM_PLN_GAP_CLS");
				pexMembGapsDtl.setHstPlnGapClsTyp("HST_PLN_GAP_CLS_INDC");
				pexMembGapsDtl.setRskAdjGapTyp("RSK_ADJ_GAP_TYP");
				pexMembGapsDtl.setHccClmTyp("HCC_CLM_TYP");
				pexMembGapsDtl.setProsRetIdntTyp("PROS_RET_IDNT");

				pexReqtMembQueue.addPexMembGapsDtl(pexMembGapsDtl);
				hmPlanClsrIndList.add(pexMembGapsDtl.getHmPlnGapClsIndc());
			}
			
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList);
		}
	}

}
