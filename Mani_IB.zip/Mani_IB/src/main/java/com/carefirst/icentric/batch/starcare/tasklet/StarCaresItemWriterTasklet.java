package com.carefirst.icentric.batch.starcare.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReqObj;
import com.carefirst.icentric.batch.utils.StarCareUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 * This class is used to Process starcare record and store the data into DB.
 * @author aad7740
 *
 */

public class StarCaresItemWriterTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(StarCaresItemWriterTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;
	
	@Autowired
	StarCareUtils starCareUtils;

	String fileName;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("starcareFileName");
		fileName = (String) param.getValue();
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info(" Enter StarCareItemWriter");
		try {
			InputStream stream = new FileInputStream(new File(fileName));
			StarsCareGapReqObj careGapReqObj = new ObjectMapper().readValue(stream, StarsCareGapReqObj.class);
			
			for (StarsCareGapReq careGapReq : careGapReqObj.getStarsCareGapReq()) {

				PexReqtMembQueue pexReqtMembQueue = null;
				List<PexReqtMembQueue> pexReqtMembQueueList = pexReqtMembQueueDAO.findByProvEngmtReqtId(careGapReq.getProvEngmntReqId());
				if(pexReqtMembQueueList.isEmpty()){
					pexReqtMembQueue = starCareUtils.setJsonPojoToEntityClass(careGapReq);
					pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
				}else{
					starCareUtils.updatePexTableColumns(careGapReq, pexReqtMembQueueList);
					starCareUtils.updatePexReqtJsonDetails(careGapReq, pexReqtMembQueueList);
				}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
			LOGGER.error("Exception found while reading the response:: :::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		LOGGER.info(" Exiting StarCareItemWriter");
		return RepeatStatus.FINISHED;
	}

}
