
package com.carefirst.icentric.batch.riskadj.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
"ProvPlanCd",
"ProductCd",
"ProvNum",
"ProvNumSuffix",
"ProvNetwrkLocSeqNum"
})
public class MemberPCP5PartKey {

@JsonProperty("ProvPlanCd")
private String provPlanCd;
@JsonProperty("ProductCd")
private String productCd;
@JsonProperty("ProvNum")
private String provNum;
@JsonProperty("ProvNumSuffix")
private String provNumSuffix;
@JsonProperty("ProvNetwrkLocSeqNum")
private String provNetwrkLocSeqNum;

/**
* No args constructor for use in serialization
*
*/
public MemberPCP5PartKey() {
}

/**
*
* @param provNumSuffix
* @param provPlanCd
* @param provNetwrkLocSeqNum
* @param provNum
* @param productCd
*/
public MemberPCP5PartKey(String provPlanCd, String productCd, String provNum, String provNumSuffix, String provNetwrkLocSeqNum) {
super();
this.provPlanCd = provPlanCd;
this.productCd = productCd;
this.provNum = provNum;
this.provNumSuffix = provNumSuffix;
this.provNetwrkLocSeqNum = provNetwrkLocSeqNum;
}

@JsonProperty("ProvPlanCd")
public String getProvPlanCd() {
return provPlanCd;
}

@JsonProperty("ProvPlanCd")
public void setProvPlanCd(String provPlanCd) {
this.provPlanCd = provPlanCd;
}

@JsonProperty("ProductCd")
public String getProductCd() {
return productCd;
}

@JsonProperty("ProductCd")
public void setProductCd(String productCd) {
this.productCd = productCd;
}

@JsonProperty("ProvNum")
public String getProvNum() {
return provNum;
}

@JsonProperty("ProvNum")
public void setProvNum(String provNum) {
this.provNum = provNum;
}

@JsonProperty("ProvNumSuffix")
public String getProvNumSuffix() {
return provNumSuffix;
}

@JsonProperty("ProvNumSuffix")
public void setProvNumSuffix(String provNumSuffix) {
this.provNumSuffix = provNumSuffix;
}

@JsonProperty("ProvNetwrkLocSeqNum")
public String getProvNetwrkLocSeqNum() {
return provNetwrkLocSeqNum;
}

@JsonProperty("ProvNetwrkLocSeqNum")
public void setProvNetwrkLocSeqNum(String provNetwrkLocSeqNum) {
this.provNetwrkLocSeqNum = provNetwrkLocSeqNum;
}

}