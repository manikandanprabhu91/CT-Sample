
package com.carefirst.icentric.batch.medrec.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "MedRecReq"
})
public class MedRecReqObj {

    @JsonProperty("MedRecReq")
    private List<MedRecReq> medRecReq = null;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MedRecReqObj() {
    }

    /**
     * 
     * @param medRecReq
     */
    public MedRecReqObj(List<MedRecReq> medRecReq) {
        super();
        this.medRecReq = medRecReq;
    }

    @JsonProperty("MedRecReq")
    public List<MedRecReq> getMedRecReq() {
        return medRecReq;
    }

    @JsonProperty("MedRecReq")
    public void setMedRecReq(List<MedRecReq> medRecReq) {
        this.medRecReq = medRecReq;
    }

}
