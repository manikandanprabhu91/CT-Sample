package com.carefirst.icentric.batch.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

@Component
public class EmailStatusUpdateListener extends JobExecutionListenerSupport {

	private static final Logger LOGGER = LogManager.getLogger(EmailStatusUpdateListener.class);
	@Override
	public void afterJob(JobExecution jobExecution) {
		LOGGER.info("Email Job::::::::::::::::"+ jobExecution.getJobInstance().getJobName());
	}
}
