package com.carefirst.icentric.batch.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.utils.FileUtils;

/**
 * 
 * @author aad7740
 *
 */
@Component
public class ErrorResponseJobScheduler implements SchedulingConfigurer {

	private static final Logger LOGGER = LogManager.getLogger(ErrorResponseJobScheduler.class);

	@Autowired
	private JobLauncher jobLauncher;

	@Autowired
	private ErrorResponseJobConfig jobConfig;

	@Autowired
	private JobExplorer jobExplorer;

	@Autowired
	private FileUtils fileUtils;

	private final int POOL_SIZE = 10;

	@Override
	public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
		LOGGER.info("> Error Response configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		LOGGER.info("< configureTasks");
	}

	public void scheduler() {
		String transactionId = UUID.randomUUID().toString();
		MDC.put("transactionId", "ErrorRes: " + transactionId);
		LOGGER.info("> ErrorRes batchJob");
		Map<String, JobParameter> jobParamMap = new HashMap<>();
		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
		List<FileSystemResource> list = fileUtils.getFiles("error_report");
		if (list.isEmpty()) {
			LOGGER.info("No Files to Process, Hence returning from errorResScheduler()");
			return;
		}
		try {
			List<String> errorFiles = new ArrayList<>();
			for (FileSystemResource fileSystemResource : list) {
				if(fileSystemResource.getPath().contains("error_report")) {
//						&& fileSystemResource.getFile().getName().toLowerCase().contains(fileIndicator.toLowerCase()+"_")) {
					errorFiles.add(fileSystemResource.getPath());
				}
			}

			String filesPath = "";
			if(!errorFiles.isEmpty()) {
				for(String file : errorFiles) {

					filesPath = file.toString().replace("[", "").replace("]", "").replace("\"", "");
					jobParamMap.put("fileName", new JobParameter(filesPath));
					jobParamMap.put("attachFileExten", new JobParameter("json"));
//					jobParamMap.put("fileIndicator", new JobParameter(fileIndicator));
					JobParameters jobParams = new JobParameters(jobParamMap);

					while (true) {
						Set<org.springframework.batch.core.JobExecution> jobExecutions = jobExplorer
								.findRunningJobExecutions(jobConfig.errorResBatchJob().getName());
						boolean runFilejob = !jobExecutions.isEmpty();
						if (runFilejob) {
							LOGGER.info("ErrorResponse Job is already running waiting to restart");
							Thread.sleep(30000);
						} else {
							LOGGER.info("Starting the ErrorResponse job");
							break;
						}
					}
					// Job is triggered to execute the tasks
					jobLauncher.run(jobConfig.errorResBatchJob(), jobParams);	

					LOGGER.info("< ErrorResponse batchJob");
				}
			}

		} catch (Exception e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		}

		MDC.clear();
		MDC.remove("transactionId");
	}

	public boolean triggerJobFromWeb() throws Exception {
		LOGGER.info("> triggerJobFromWeb");
		Set<org.springframework.batch.core.JobExecution> jobExecutions = jobExplorer
				.findRunningJobExecutions(jobConfig.errorResBatchJob().getName());
		boolean runFilejob = !jobExecutions.isEmpty();
		if (runFilejob) {
			LOGGER.info("< triggerJobFromWeb");
			throw new Exception("JOB is running. Please try again later");
		} else {
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				scheduler();
				LOGGER.info("< triggerJobFromWeb");
			});
		}
		return true;
	}


}
