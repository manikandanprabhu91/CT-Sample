package com.carefirst.icentric.batch.service;

//import com.carefirst.pcmh.provsearch.provpracpdmo.schema._201507.ProviderResponse;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;

public interface ProvSearch {

	public ProviderResponse getProviderDetails(String rndrngProvProprietaryId) throws Exception;
	
}
