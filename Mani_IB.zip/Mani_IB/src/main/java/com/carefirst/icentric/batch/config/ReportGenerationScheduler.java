package com.carefirst.icentric.batch.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.exception.ApplicationException;

@Component
public class ReportGenerationScheduler implements SchedulingConfigurer {
	

	private static final Logger LOGGER = LogManager.getLogger(ReportGenerationScheduler.class);

	private final int POOL_SIZE = 10;

	@Autowired
	private JobLauncher jobLauncherReport;
	
	@Autowired
	private JobExplorer reportJobExplorer;
	
	@Autowired
	ReportGenerationConfig reportGenerationConfig; 

	
	@Scheduled(cron = "${medvantage.inbound.batch.extract.cron}")
	public void extractReprtScheduler() {
		LOGGER.info("> extractReprtScheduler");
		Map<String, JobParameter> jobParamMap = new HashMap<>();
		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
		JobParameters jobParams = new JobParameters(jobParamMap);
		extractReport(jobParams);
		LOGGER.info("< extractReprtScheduler");
	}
	
	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		LOGGER.info("> configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		
	}
	
	private void extractReport(JobParameters jobParams){
		LOGGER.info("> extractReport");
		try {
			while (true) {
				Set<org.springframework.batch.core.JobExecution> jobExecutions = reportJobExplorer
						.findRunningJobExecutions(reportGenerationConfig.reportBatchJob().getName());
				boolean runFilejob = !jobExecutions.isEmpty();
				if (runFilejob) {
					LOGGER.info("reportBatchJob Job is already running waiting to restart");
					try {
						Thread.sleep(30000);
					} catch (InterruptedException e) {
						LOGGER.error("Exception Occued :" + e.getMessage(), e);
					}
				} else {
					LOGGER.info("Starting the reportBatchJob job");
					break;
				}
			}
			jobLauncherReport.run(reportGenerationConfig.reportBatchJob(), jobParams);
		} catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
				| JobParametersInvalidException | JobRestartException | ApplicationException e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		} 
		LOGGER.info("< extractReport");
	}


	public boolean triggerJobFromWeb() throws Exception {
		LOGGER.info("> triggerJobFromWeb");
		Set<org.springframework.batch.core.JobExecution> jobExecutions = reportJobExplorer
				.findRunningJobExecutions(reportGenerationConfig.reportBatchJob().getName());
		boolean runFilejob = !jobExecutions.isEmpty();
		if (runFilejob) {
			LOGGER.info("< triggerJobFromWeb");
			throw new Exception("JOB is running. Please try again later");
		} else {
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				extractReprtScheduler();
				LOGGER.info("< triggerJobFromWeb");
			});
		}
		return true;
	}

	
}
