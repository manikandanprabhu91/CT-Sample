package com.carefirst.icentric.batch.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.activation.DataSource;
import javax.activation.FileDataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
/**
 * Excel file generation class
 * @author aad7740
 *
 */

@Component
public class ExcelUtils {

	private static final Logger LOGGER = LogManager.getLogger(ExcelUtils.class);
	
	@Value("${medvantage.inbound.archive.path}")
	private String archivePath;

	public DataSource getDataSource(List<ErrorResponse> errorResponses, String name) {
		DataSource dataSource = null;
		String[] columns = {"Error Code", "Provider Engagement Id", "Error Description"};
		try {
			XSSFWorkbook workbook = new XSSFWorkbook(); 
			XSSFSheet sheet = workbook.createSheet("Error Response Details");
			Font headerFont = workbook.createFont();
			headerFont.setBold(true);
			headerFont.setColor(IndexedColors.BLACK.getIndex());
			CellStyle headerCellStyle = workbook.createCellStyle();
			headerCellStyle.setFont(headerFont);
			int rownum = 1;
			Row headerRow = sheet.createRow(0);
			for(int i = 0; i < columns.length; i++) {
				Cell cell = headerRow.createCell(i);
				cell.setCellValue(columns[i]);
				cell.setCellStyle(headerCellStyle);
			}

			for (ErrorResponse user : errorResponses)
			{
				Row row = sheet.createRow(rownum++);
				createList(user, row);

			}
			for(int i = 0; i < columns.length; i++) {
				sheet.autoSizeColumn(i);
			}

			FileOutputStream out = new FileOutputStream(new File(archivePath+name+Constants.XLS));
			workbook.write(out);
			out.close();
			dataSource = new FileDataSource(new File(archivePath+name+Constants.XLS));
		} catch (Exception e) {
			LOGGER.error("Erorr Occuring while writing the excel file:::::::::::: "+e.getMessage());
		}
		return dataSource;
	}

	private void createList(ErrorResponse errorResponse, Row row) {

		Cell cell = row.createCell(0);
		cell.setCellValue(errorResponse.getErrorCode());


		cell = row.createCell(1);
		cell.setCellValue(errorResponse.getProviderEngagementID());

		cell = row.createCell(2);
		cell.setCellValue(errorResponse.getErrorDesc());

	}
}
