package com.carefirst.icentric.batch.starcare.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({ "StarsCareGapReq" })
public class StarsCareGapReqObj {

	@JsonProperty("StarsCareGapReq")
	private List<StarsCareGapReq> starsCareGapReq = null;

	/**
	 * No args constructor for use in serialization
	 * 
	 */
	public StarsCareGapReqObj() {
	}

	/**
	 * 
	 * @param starsCareGapReq
	 */
	public StarsCareGapReqObj(List<StarsCareGapReq> starsCareGapReq) {
		super();
		this.starsCareGapReq = starsCareGapReq;
	}

	@JsonProperty("StarsCareGapReq")
	public List<StarsCareGapReq> getStarsCareGapReq() {
		return starsCareGapReq;
	}

	@JsonProperty("StarsCareGapReq")
	public void setStarsCareGapReq(List<StarsCareGapReq> starsCareGapReq) {
		this.starsCareGapReq = starsCareGapReq;
	}

}