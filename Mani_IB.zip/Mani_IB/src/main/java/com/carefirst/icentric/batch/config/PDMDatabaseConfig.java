//package com.carefirst.icentric.batch.config;
//
//import javax.persistence.EntityManagerFactory;
//
//import org.apache.commons.lang3.StringUtils;
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
//import org.springframework.orm.jpa.JpaTransactionManager;
//import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
//import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
//import org.springframework.transaction.PlatformTransactionManager;
//import org.springframework.transaction.annotation.EnableTransactionManagement;
//
//import com.carefirst.eapmca.controller.PMConnector;
//import com.zaxxer.hikari.HikariConfig;
//import com.zaxxer.hikari.HikariDataSource;
//
//@Configuration
//@ConfigurationProperties("pdm")
//@EnableTransactionManagement
//@EnableJpaRepositories(basePackages = "com.carefirst.icentric.batch.pdm.dao", entityManagerFactoryRef = "pdmEntityManagerFactory", transactionManagerRef = "pdmTransactionManager")
//public class PDMDatabaseConfig {
//	private String driver;
//	private String url;
//	private String vaultquery;
//	private long connTimeOut;
//	private int maxPoolSize;
//	private String hbm2ddlauto;
//	private String showsql;
//	
//	private static HikariDataSource pdmds;
//	
//	private static final Logger logger = LogManager.getLogger(PDMDatabaseConfig.class);
//	
//	@Bean
//	public HikariDataSource pdmDataSource() throws Exception{
//		
//		HikariConfig config = new HikariConfig();
//		config.setJdbcUrl(getUrl());
//		config.setDriverClassName(getDriver());
//		config.setUsername(PMConnector.getConnector().getUserName(getVaultquery()));
//		config.setPassword(PMConnector.getConnector().getContent(getVaultquery()));
//		if (StringUtils.isEmpty(config.getUsername()) || StringUtils.isEmpty(config.getPassword())) {
//            logger.error("Error: DB credentials not retrieved from EAPM");
//            logger.info("Error: DB credentials not retrieved from EAPM");
//            throw new Exception("Error: DB credentials not retrieved from EAPM");
//        }
//
//		//Additional Parameters
//		config.setConnectionTimeout(getConnTimeOut());
//		config.setMaximumPoolSize(getMaxPoolSize());
//		return pdmds = new HikariDataSource(config);
//	}
//	
//	
//	@Bean
//	public PlatformTransactionManager pdmTransactionManager() throws Exception{
//		EntityManagerFactory factory = pdmEntityManagerFactory().getObject();
//		return new JpaTransactionManager(factory);
//	}
//
//	@Bean
//	public LocalContainerEntityManagerFactoryBean pdmEntityManagerFactory() throws Exception{
//		LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
//		factory.setDataSource(pdmDataSource());
//		factory.setPackagesToScan("com.carefirst.icentric.batch.pdm.entity");
//		factory.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
//
//		return factory;
//	}
//	
//	public String getDriver() {
//		return driver;
//	}
//
//
//	public void setDriver(String driver) {
//		this.driver = driver;
//	}
//
//
//	public String getUrl() {
//		return url;
//	}
//
//
//	public void setUrl(String url) {
//		this.url = url;
//	}
//
//
//	public String getVaultquery() {
//		return vaultquery;
//	}
//
//
//	public void setVaultquery(String vaultquery) {
//		this.vaultquery = vaultquery;
//	}
//
//	/**
//	 * @return the connTimeOut
//	 */
//	public long getConnTimeOut() {
//		return connTimeOut;
//	}
//
//	/**
//	 * @param connTimeOut the connTimeOut to set
//	 */
//	public void setConnTimeOut(long connTimeOut) {
//		this.connTimeOut = connTimeOut;
//	}
//
//	/**
//	 * @return the maxPoolSize
//	 */
//	public int getMaxPoolSize() {
//		return maxPoolSize;
//	}
//
//	/**
//	 * @param maxPoolSize the maxPoolSize to set
//	 */
//	public void setMaxPoolSize(int maxPoolSize) {
//		this.maxPoolSize = maxPoolSize;
//	}
//
//
//	/**
//	 * @return the showsql
//	 */
//	public String getShowsql() {
//		return showsql;
//	}
//
//
//	/**
//	 * @param showsql the showsql to set
//	 */
//	public void setShowsql(String showsql) {
//		this.showsql = showsql;
//	}
//
//
//	/**
//	 * @return the hbm2ddlauto
//	 */
//	public String getHbm2ddlauto() {
//		return hbm2ddlauto;
//	}
//
//
//	/**
//	 * @param hbm2ddlauto the hbm2ddlauto to set
//	 */
//	public void setHbm2ddlauto(String hbm2ddlauto) {
//		this.hbm2ddlauto = hbm2ddlauto;
//	}
//
//}
