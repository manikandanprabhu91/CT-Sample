
package com.carefirst.icentric.batch.riskadj.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
"LastMedRecReqServBeginDt",
"LastMedRecReqServEndDt"
})
public class LastMedRecReqServRangeDts {

@JsonProperty("LastMedRecReqServBeginDt")
private String lastMedRecReqServBeginDt;
@JsonProperty("LastMedRecReqServEndDt")
private String lastMedRecReqServEndDt;

/**
* No args constructor for use in serialization
*
*/
public LastMedRecReqServRangeDts() {
}

/**
*
* @param lastMedRecReqServEndDt
* @param lastMedRecReqServBeginDt
*/
public LastMedRecReqServRangeDts(String lastMedRecReqServBeginDt, String lastMedRecReqServEndDt) {
super();
this.lastMedRecReqServBeginDt = lastMedRecReqServBeginDt;
this.lastMedRecReqServEndDt = lastMedRecReqServEndDt;
}

@JsonProperty("LastMedRecReqServBeginDt")
public String getLastMedRecReqServBeginDt() {
return lastMedRecReqServBeginDt;
}

@JsonProperty("LastMedRecReqServBeginDt")
public void setLastMedRecReqServBeginDt(String lastMedRecReqServBeginDt) {
this.lastMedRecReqServBeginDt = lastMedRecReqServBeginDt;
}

@JsonProperty("LastMedRecReqServEndDt")
public String getLastMedRecReqServEndDt() {
return lastMedRecReqServEndDt;
}

@JsonProperty("LastMedRecReqServEndDt")
public void setLastMedRecReqServEndDt(String lastMedRecReqServEndDt) {
this.lastMedRecReqServEndDt = lastMedRecReqServEndDt;
}

}