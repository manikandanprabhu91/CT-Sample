package com.carefirst.icentric.batch.tasklet;

import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.model.ExtrectReportDto;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.carefirst.icentric.batch.utils.ReportUtils;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;

public class ReportGenerationTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(ReportGenerationTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	ProvSearch provSearch;

	@Autowired
	ReportUtils reportUtils;

	@Value("${medvantage.inbound.archive.path}")
	private String archivePath;

	@Value("${medvantage.extract.file.name}")
	private String fileName;

	@Autowired
	FileUtils fileUtils;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("> ReportGenerationTasklet beforeStep starts  >>>");
	}


	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("> ReportGenerationTasklet execute starts  >>>");
		List<ExtrectReportDto> extrectMRReportDtos = null;
		List<ExtrectReportDto> extrectRAReportDtos = null;
		List<ExtrectReportDto> extrectSCReportDtos = null;
		LocalDate today = LocalDate.now();
		try {

			extrectMRReportDtos = validateExtrectRecords(pexReqtMembQueueDAO.getExtractMRRecords());
			extrectRAReportDtos = validateExtrectRecords(pexReqtMembQueueDAO.getExtractRARecords());
			extrectSCReportDtos = validateExtrectRecords(pexReqtMembQueueDAO.getExtractSCRecords());

			if(!extrectMRReportDtos.isEmpty())
				reportUtils.writeToExcelInMultiSheets(archivePath+fileName+today.getMonth()+"_"+today.getYear()+".xlsx", 
						"MR_PEX_Records", extrectMRReportDtos, "MR");
			if(!extrectRAReportDtos.isEmpty())
				reportUtils.writeToExcelInMultiSheets(archivePath+fileName+today.getMonth()+"_"+today.getYear()+".xlsx", 
						"RA_PEX_Records", extrectRAReportDtos, "RA");
			if(!extrectSCReportDtos.isEmpty())
				reportUtils.writeToExcelInMultiSheets(archivePath+fileName+today.getMonth()+"_"+today.getYear()+".xlsx", 
						"SC_PEX_Records", extrectSCReportDtos, "SC");
			for(File file: fileUtils.getExtractFile(archivePath)) {
				reportUtils.sendMail(file);	
			}

			if(!extrectMRReportDtos.isEmpty()) {
				for(ExtrectReportDto extrectReportDto:extrectMRReportDtos) {
					pexReqtMembQueueDAO.updateExtractYes(extrectReportDto.getProvEngmentReqId());
				}
			}

			if(!extrectRAReportDtos.isEmpty()) {
				for(ExtrectReportDto extrectReportDto:extrectRAReportDtos) {
					pexReqtMembQueueDAO.updateExtractYes(extrectReportDto.getProvEngmentReqId());
				}

			}
			
			if(!extrectSCReportDtos.isEmpty()) {
				for(ExtrectReportDto extrectReportDto:extrectSCReportDtos) {
					pexReqtMembQueueDAO.updateExtractYes(extrectReportDto.getProvEngmentReqId());
				}
			}

		} catch(Exception e) {
			LOGGER.error("Error Occuring execute method  :::::::::: " + e.getMessage());
		}
		return RepeatStatus.FINISHED;
	}


	public List<ExtrectReportDto> validateExtrectRecords(List<Object[]> extractList)
			throws Exception {
		List<ExtrectReportDto> extrectReportDtos = new ArrayList<>();
		if(!extractList.isEmpty()) {
			for(Object mrExtract : extractList) {
				Object[] mrReport = (Object[]) mrExtract;
				ExtrectReportDto extrectReportDto = setExtrectReportDetails(mrReport);
				getProviderDetails((String) mrReport[1], extrectReportDto);
				extrectReportDtos.add(extrectReportDto);
			}
		}
		return extrectReportDtos;
	}


	private ExtrectReportDto setExtrectReportDetails(Object[] mrReport) {
		ExtrectReportDto extrectReportDto = new ExtrectReportDto();
		extrectReportDto.setProvEngmentReqId(String.valueOf(mrReport[0]));
		extrectReportDto.setRenderingProviderID(String.valueOf(mrReport[1]));
		extrectReportDto.setRenderingProviderNPI(String.valueOf(mrReport[2]));
		extrectReportDto.setMemberFullName(String.valueOf(mrReport[7]));
		extrectReportDto.setMember_DOB(String.valueOf(mrReport[8]));
		extrectReportDto.setMemberID(String.valueOf(mrReport[4]));
		extrectReportDto.setServiceBeginDate(String.valueOf(mrReport[5]));
		extrectReportDto.setServiceEndDate(String.valueOf(mrReport[6]));
		extrectReportDto.setDiagnosisCode(String.valueOf(mrReport[9]));
		extrectReportDto.setREFNC_CD_DESC(String.valueOf(mrReport[11]));
		return extrectReportDto;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		LOGGER.info("> ReportGenerationTasklet afterStep");
		return ExitStatus.COMPLETED;
	}

	public void getProviderDetails(String renderingNPI, ExtrectReportDto extrectReportDto) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch.getProviderDetails(renderingNPI);
			if (providerResponse != null) {
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							//							extrectReportDto.setFname(practitioner.getPractitionerFirstName());
							//							extrectReportDto.setLname(practitioner.getPractitionerLastName());
							extrectReportDto.setRenderingProviderName(practitioner.getPractitionerFirstName() + " "+ practitioner.getPractitionerLastName());
							extrectReportDto.setAddress1(practitioner.getPractitionerAddress1());
							extrectReportDto.setAddress2(practitioner.getPractitionerAddress2());
							extrectReportDto.setCity(practitioner.getPractitionerCityName());
							extrectReportDto.setState(practitioner.getPractitionerStateCd());
							extrectReportDto.setZip(practitioner.getPractitionerZip());
							extrectReportDto.setPractitionerID(practitioner.getPractitionerPANRID());
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

}
