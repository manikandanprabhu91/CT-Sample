package com.carefirst.icentric.batch.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;
import com.carefirst.icentric.batch.service.EmailService;

@Component
public class EmailStatusUpdateTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(EmailStatusUpdateTasklet.class);
	
	EmailService emailService; 
	
	public EmailStatusUpdateTasklet(EmailService emailService) {
		this.emailService = emailService;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("> EmailStatusUpdateTasklet beforeStep starts  >>>");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("> EmailStatusUpdateTasklet execute() Start >>>>>>>>>>>>>>");
		try {
			emailService.sendStatsUpdateEmail();
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.error("Error Occuring email send method >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "+ e.getLocalizedMessage());
		}
		
		LOGGER.info("> EmailStatusUpdateTasklet execute() End >>>>>>>>>>>>>>");
		return RepeatStatus.FINISHED;
	}

}
