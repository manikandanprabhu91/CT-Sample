package com.carefirst.icentric.batch.tasklet;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;

/**
 * This class is used to update the internal status as closed based on the criteria.
 * @author aad7740
 *
 */

public class StatusUpdateTasklet  implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(StatusUpdateTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	private String categoryInd;

	@Override
	public void beforeStep(StepExecution stepExecution) {
		LOGGER.info("> StatusUpdateTasklet beforeStep starts  >>>");
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get(Constants.CATEGORY_IND);
		categoryInd = (String) param.getValue();
		LOGGER.info("> StatusUpdateTasklet beforeStep end  >>>");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		LOGGER.info("> StatusUpdateTasklet afterStep");
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info("> StatusUpdateTasklet execute starts  >>>");

		if(Constants.CATEGORY_IND_MR.equals(categoryInd)) {
			updateInternalStatusAsClosed(Constants.CATEGORY_IND_MR);
		} else if(Constants.CATEGORY_IND_RA.equals(categoryInd)) {
			updateInternalStatusAsClosed(Constants.CATEGORY_IND_RA);
		} else if(Constants.CATEGORY_IND_SC.equals(categoryInd)) {
			updateInternalStatusAsClosed(Constants.CATEGORY_IND_SC);
		}

		LOGGER.info("> StatusUpdateTasklet execute end  >>>");

		return RepeatStatus.FINISHED;
	}

	private void updateInternalStatusAsClosed(String cpbltyIndcCd) {
		LOGGER.info("> StatusUpdateTasklet updateInternalStatusAsClosed starts  >>>");
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			List<PexReqtMembQueue> membQueues = pexReqtMembQueueDAO.findByReqtStusCdAndAudUpdtTmstp(Constants.PENDING_CLOSURE, 
					cpbltyIndcCd);
			if(!membQueues.isEmpty()) {
				for(PexReqtMembQueue membQueue : membQueues) {
					String currentDate = simpleDateFormat.format(new Date());
					String auditUpdateDate = simpleDateFormat.format(new Date(membQueue.getAudUpdtTmstp().getTime()));

					Date date1 = simpleDateFormat.parse(auditUpdateDate);
					Date date2 = simpleDateFormat.parse(currentDate);
					if(date1.compareTo(date2) < 0) {
						membQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
						membQueue.setReqtStusCd(Constants.CLOSED);
						pexReqtMembQueueDAO.saveAndFlush(membQueue);
					}

				}
			}
		} catch (ParseException e) {
			LOGGER.error("::::::::Error Occuring updateInternalStatusAsClosed method::::::::::::: "+e.getMessage());

		}
		LOGGER.info("> StatusUpdateTasklet updateInternalStatusAsClosed end  >>>");
	}

}
