
package com.carefirst.icentric.batch.medrec.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ProvEngmntReqId",
    "CapabilityInd",
    "MedRecReqType",
    "HomePlanId",
    "MemberHostPlanId",
    "RoutetoHostPlanId",
    "FirstTimeSenttoHostPlanDt",
    "LastMRRProvEngmntReqID",
    "LastMedRecReqRcptDt",
    "LastMedRecReqServRangeDts",
    "ITSSubscriberId",
    "MemberDOB",
    "MMIId",
    "MemberFullName",
    "MemberGender",
    "BillProvProprietaryId",
    "RndrngProvProprietaryId",
    "BillProvNPI",
    "RndrngProvNPI",
    "RndrngProvHostPlanId",
    "BillProvZipCode",
    "RndrngProvZipCode",
    "RndrngProvTxnmyCd",
    "SCCFIds",
    "MemberPCP5PartKey",
    "ServRangeDts",
    "HomePlanClsrInd",
    "ProvEngagementInd",
    "ProvCntrctingSts",
    "HostPlanMedRecMatchInd",
    "HostPlanClsrInd",
    "ServDts",
    "RndrngProvZipCode",
    "RndrngProvTxnmyCd",
    "HEDISMRRMeasurementType",
    "ErrCd",
    "ErrDesc"
})
public class MedRecReq {

    @JsonProperty("ProvEngmntReqId")
    private String provEngmntReqId;
    @JsonProperty("CapabilityInd")
    private String capabilityInd;
    @JsonProperty("MedRecReqType")
    private String medRecReqType;
    @JsonProperty("HomePlanId")
    private String homePlanId;
    @JsonProperty("MemberHostPlanId")
    private String memberHostPlanId;
    @JsonProperty("RoutetoHostPlanId")
    private String routetoHostPlanId;
    @JsonProperty("FirstTimeSenttoHostPlanDt")
    private String firstTimeSenttoHostPlanDt;
    @JsonProperty("LastMRRProvEngmntReqID")
    private String lastMRRProvEngmntReqID;
    @JsonProperty("LastMedRecReqRcptDt")
    private String lastMedRecReqRcptDt;
    @JsonProperty("LastMedRecReqServRangeDts")
    private LastMedRecReqServRangeDts lastMedRecReqServRangeDts;
    @JsonProperty("ITSSubscriberId")
    private String iTSSubscriberId;
    @JsonProperty("MemberDOB")
    private String memberDOB;
    @JsonProperty("MMIId")
    private String mMIId;
    @JsonProperty("MemberFullName")
    private String memberFullName;
    @JsonProperty("MemberGender")
    private String memberGender;
    @JsonProperty("BillProvProprietaryId")
    private String billProvProprietaryId;
    @JsonProperty("RndrngProvProprietaryId")
    private String rndrngProvProprietaryId;
    @JsonProperty("BillProvNPI")
    private String billProvNPI;
    @JsonProperty("RndrngProvNPI")
    private String rndrngProvNPI;
    @JsonProperty("RndrngProvHostPlanId")
    private String rndrngProvHostPlanId;
    @JsonProperty("BillProvZipCode")
    private String billProvZipCode;
    @JsonProperty(" HEDISMRRMeasurementType")
    private String hedisMRRMeasurementType;
    @JsonProperty("RndrngProvZipCode")
    private String rndrngProvZipCode;
    @JsonProperty("RndrngProvTxnmyCd")
    private String rndrngProvTxnmyCd;
    @JsonProperty("SCCFIds")
    private String sCCFIds;
    @JsonProperty("MemberPCP5PartKey")
    private MemberPCP5PartKey memberPCP5PartKey;
    @JsonProperty("ServRangeDts")
    private ServRangeDts servRangeDts;
    @JsonProperty("HomePlanClsrInd")
    private String homePlanClsrInd;
    @JsonProperty("ProvEngagementInd")
    private String provEngagementInd;
    @JsonProperty("ProvCntrctingSts")
    private String provCntrctingSts;
    @JsonProperty("HostPlanMedRecMatchInd")
    private String hostPlanMedRecMatchInd;
    @JsonProperty("HostPlanClsrInd")
    private String hostPlanClsrInd;
    @JsonProperty("ServDts")
    private List<String> servDts;
	@JsonProperty("RndrngProvTaxId")
	private String rndrngProvTaxId;
	@JsonProperty("RndrngProvAddlInfo")
	private String rndrngProvAddlInfo;
	@JsonProperty("ErrCd")
	private String errCd;
	@JsonProperty("ErrDesc")
	private String errDesc;

    /**
     * No args constructor for use in serialization
     * 
     */
    public MedRecReq() {
    }

    /**
     * 
     * @param memberHostPlanId
     * @param memberFullName
     * @param billProvZipCode
     * @param homePlanClsrInd
     * @param hostPlanMedRecMatchInd
     * @param firstTimeSenttoHostPlanDt
     * @param billProvProprietaryId
     * @param provEngagementInd
     * @param lastMedRecReqRcptDt
     * @param rndrngProvZipCode
     * @param mMIId
     * @param billProvNPI
     * @param rndrngProvProprietaryId
     * @param routetoHostPlanId
     * @param lastMedRecReqServRangeDts
     * @param memberGender
     * @param hostPlanClsrInd
     * @param rndrngProvTxnmyCd
     * @param servRangeDts
     * @param rndrngProvHostPlanId
     * @param capabilityInd
     * @param sCCFIds
     * @param provCntrctingSts
     * @param provEngmntReqId
     * @param homePlanId
     * @param lastMRRProvEngmntReqID
     * @param medRecReqType
     * @param memberDOB
     * @param rndrngProvNPI
     * @param memberPCP5PartKey
     * @param iTSSubscriberId 
     * @param servDts
     * @param rndrngProvTaxId
     * @param rndrngProvAddlInfo
     * @param hedisMRRMeasurementType
     */
    public MedRecReq(String provEngmntReqId, String capabilityInd, String medRecReqType, String homePlanId, String memberHostPlanId, String routetoHostPlanId, String firstTimeSenttoHostPlanDt, String lastMRRProvEngmntReqID, String lastMedRecReqRcptDt, LastMedRecReqServRangeDts lastMedRecReqServRangeDts, String iTSSubscriberId, String memberDOB, String mMIId, String memberFullName, String memberGender, String billProvProprietaryId, String rndrngProvProprietaryId, String billProvNPI, String rndrngProvNPI, String rndrngProvHostPlanId, String billProvZipCode, String rndrngProvZipCode, String rndrngProvTxnmyCd, String sCCFIds, MemberPCP5PartKey memberPCP5PartKey, ServRangeDts servRangeDts, String homePlanClsrInd, String provEngagementInd, String provCntrctingSts, String hostPlanMedRecMatchInd, String hostPlanClsrInd, List<String> servDts, String rndrngProvTaxId, String rndrngProvAddlInfo, String hedisMRRMeasurementType) {
        super();
        this.provEngmntReqId = provEngmntReqId;
        this.capabilityInd = capabilityInd;
        this.medRecReqType = medRecReqType;
        this.homePlanId = homePlanId;
        this.memberHostPlanId = memberHostPlanId;
        this.routetoHostPlanId = routetoHostPlanId;
        this.firstTimeSenttoHostPlanDt = firstTimeSenttoHostPlanDt;
        this.lastMRRProvEngmntReqID = lastMRRProvEngmntReqID;
        this.lastMedRecReqRcptDt = lastMedRecReqRcptDt;
        this.lastMedRecReqServRangeDts = lastMedRecReqServRangeDts;
        this.iTSSubscriberId = iTSSubscriberId;
        this.memberDOB = memberDOB;
        this.mMIId = mMIId;
        this.memberFullName = memberFullName;
        this.memberGender = memberGender;
        this.billProvProprietaryId = billProvProprietaryId;
        this.rndrngProvProprietaryId = rndrngProvProprietaryId;
        this.billProvNPI = billProvNPI;
        this.rndrngProvNPI = rndrngProvNPI;
        this.rndrngProvHostPlanId = rndrngProvHostPlanId;
        this.billProvZipCode = billProvZipCode;
        this.rndrngProvZipCode = rndrngProvZipCode;
        this.rndrngProvTxnmyCd = rndrngProvTxnmyCd;
        this.sCCFIds = sCCFIds;
        this.memberPCP5PartKey = memberPCP5PartKey;
        this.servRangeDts = servRangeDts;
        this.homePlanClsrInd = homePlanClsrInd;
        this.provEngagementInd = provEngagementInd;
        this.provCntrctingSts = provCntrctingSts;
        this.hostPlanMedRecMatchInd = hostPlanMedRecMatchInd;
        this.hostPlanClsrInd = hostPlanClsrInd;
        this.servDts = servDts;
        this.rndrngProvTaxId = rndrngProvTaxId;
        this.rndrngProvAddlInfo = rndrngProvAddlInfo;
        this.hedisMRRMeasurementType = hedisMRRMeasurementType;
    }

    @JsonProperty("ProvEngmntReqId")
    public String getProvEngmntReqId() {
        return provEngmntReqId;
    }

    @JsonProperty("ProvEngmntReqId")
    public void setProvEngmntReqId(String provEngmntReqId) {
        this.provEngmntReqId = provEngmntReqId;
    }

    @JsonProperty("CapabilityInd")
    public String getCapabilityInd() {
        return capabilityInd;
    }

    @JsonProperty("CapabilityInd")
    public void setCapabilityInd(String capabilityInd) {
        this.capabilityInd = capabilityInd;
    }

    @JsonProperty("MedRecReqType")
    public String getMedRecReqType() {
        return medRecReqType;
    }

    @JsonProperty("MedRecReqType")
    public void setMedRecReqType(String medRecReqType) {
        this.medRecReqType = medRecReqType;
    }

    @JsonProperty("HomePlanId")
    public String getHomePlanId() {
        return homePlanId;
    }

    @JsonProperty("HomePlanId")
    public void setHomePlanId(String homePlanId) {
        this.homePlanId = homePlanId;
    }

    @JsonProperty("MemberHostPlanId")
    public String getMemberHostPlanId() {
        return memberHostPlanId;
    }

    @JsonProperty("MemberHostPlanId")
    public void setMemberHostPlanId(String memberHostPlanId) {
        this.memberHostPlanId = memberHostPlanId;
    }

    @JsonProperty("RoutetoHostPlanId")
    public String getRoutetoHostPlanId() {
        return routetoHostPlanId;
    }

    @JsonProperty("RoutetoHostPlanId")
    public void setRoutetoHostPlanId(String routetoHostPlanId) {
        this.routetoHostPlanId = routetoHostPlanId;
    }

    @JsonProperty("FirstTimeSenttoHostPlanDt")
    public String getFirstTimeSenttoHostPlanDt() {
        return firstTimeSenttoHostPlanDt;
    }

    @JsonProperty("FirstTimeSenttoHostPlanDt")
    public void setFirstTimeSenttoHostPlanDt(String firstTimeSenttoHostPlanDt) {
        this.firstTimeSenttoHostPlanDt = firstTimeSenttoHostPlanDt;
    }

    @JsonProperty("LastMRRProvEngmntReqID")
    public String getLastMRRProvEngmntReqID() {
        return lastMRRProvEngmntReqID;
    }

    @JsonProperty("LastMRRProvEngmntReqID")
    public void setLastMRRProvEngmntReqID(String lastMRRProvEngmntReqID) {
        this.lastMRRProvEngmntReqID = lastMRRProvEngmntReqID;
    }

    @JsonProperty("LastMedRecReqRcptDt")
    public String getLastMedRecReqRcptDt() {
        return lastMedRecReqRcptDt;
    }

    @JsonProperty("LastMedRecReqRcptDt")
    public void setLastMedRecReqRcptDt(String lastMedRecReqRcptDt) {
        this.lastMedRecReqRcptDt = lastMedRecReqRcptDt;
    }

    @JsonProperty("LastMedRecReqServRangeDts")
    public LastMedRecReqServRangeDts getLastMedRecReqServRangeDts() {
        return lastMedRecReqServRangeDts;
    }

    @JsonProperty("LastMedRecReqServRangeDts")
    public void setLastMedRecReqServRangeDts(LastMedRecReqServRangeDts lastMedRecReqServRangeDts) {
        this.lastMedRecReqServRangeDts = lastMedRecReqServRangeDts;
    }

    @JsonProperty("ITSSubscriberId")
    public String getITSSubscriberId() {
        return iTSSubscriberId;
    }

    @JsonProperty("ITSSubscriberId")
    public void setITSSubscriberId(String iTSSubscriberId) {
        this.iTSSubscriberId = iTSSubscriberId;
    }

    @JsonProperty("MemberDOB")
    public String getMemberDOB() {
        return memberDOB;
    }

    @JsonProperty("MemberDOB")
    public void setMemberDOB(String memberDOB) {
        this.memberDOB = memberDOB;
    }

    @JsonProperty("MMIId")
    public String getMMIId() {
        return mMIId;
    }

    @JsonProperty("MMIId")
    public void setMMIId(String mMIId) {
        this.mMIId = mMIId;
    }

    @JsonProperty("MemberFullName")
    public String getMemberFullName() {
        return memberFullName;
    }

    @JsonProperty("MemberFullName")
    public void setMemberFullName(String memberFullName) {
        this.memberFullName = memberFullName;
    }

    @JsonProperty("MemberGender")
    public String getMemberGender() {
        return memberGender;
    }

    @JsonProperty("MemberGender")
    public void setMemberGender(String memberGender) {
        this.memberGender = memberGender;
    }

    @JsonProperty("BillProvProprietaryId")
    public String getBillProvProprietaryId() {
        return billProvProprietaryId;
    }

    @JsonProperty("BillProvProprietaryId")
    public void setBillProvProprietaryId(String billProvProprietaryId) {
        this.billProvProprietaryId = billProvProprietaryId;
    }

    @JsonProperty("RndrngProvProprietaryId")
    public String getRndrngProvProprietaryId() {
        return rndrngProvProprietaryId;
    }

    @JsonProperty("RndrngProvProprietaryId")
    public void setRndrngProvProprietaryId(String rndrngProvProprietaryId) {
        this.rndrngProvProprietaryId = rndrngProvProprietaryId;
    }

    @JsonProperty("BillProvNPI")
    public String getBillProvNPI() {
        return billProvNPI;
    }

    @JsonProperty("BillProvNPI")
    public void setBillProvNPI(String billProvNPI) {
        this.billProvNPI = billProvNPI;
    }

    @JsonProperty("RndrngProvNPI")
    public String getRndrngProvNPI() {
        return rndrngProvNPI;
    }

    @JsonProperty("RndrngProvNPI")
    public void setRndrngProvNPI(String rndrngProvNPI) {
        this.rndrngProvNPI = rndrngProvNPI;
    }

    @JsonProperty("RndrngProvHostPlanId")
    public String getRndrngProvHostPlanId() {
        return rndrngProvHostPlanId;
    }

    @JsonProperty("RndrngProvHostPlanId")
    public void setRndrngProvHostPlanId(String rndrngProvHostPlanId) {
        this.rndrngProvHostPlanId = rndrngProvHostPlanId;
    }

    @JsonProperty("BillProvZipCode")
    public String getBillProvZipCode() {
        return billProvZipCode;
    }

    @JsonProperty("BillProvZipCode")
    public void setBillProvZipCode(String billProvZipCode) {
        this.billProvZipCode = billProvZipCode;
    }

    @JsonProperty("RndrngProvZipCode")
    public String getRndrngProvZipCode() {
        return rndrngProvZipCode;
    }

    @JsonProperty("RndrngProvZipCode")
    public void setRndrngProvZipCode(String rndrngProvZipCode) {
        this.rndrngProvZipCode = rndrngProvZipCode;
    }

    @JsonProperty("RndrngProvTxnmyCd")
    public String getRndrngProvTxnmyCd() {
        return rndrngProvTxnmyCd;
    }

    @JsonProperty("RndrngProvTxnmyCd")
    public void setRndrngProvTxnmyCd(String rndrngProvTxnmyCd) {
        this.rndrngProvTxnmyCd = rndrngProvTxnmyCd;
    }

    @JsonProperty("SCCFIds")
    public String getSCCFIds() {
        return sCCFIds;
    }

    @JsonProperty("SCCFIds")
    public void setSCCFIds(String sCCFIds) {
        this.sCCFIds = sCCFIds;
    }

    @JsonProperty("MemberPCP5PartKey")
    public MemberPCP5PartKey getMemberPCP5PartKey() {
        return memberPCP5PartKey;
    }

    @JsonProperty("MemberPCP5PartKey")
    public void setMemberPCP5PartKey(MemberPCP5PartKey memberPCP5PartKey) {
        this.memberPCP5PartKey = memberPCP5PartKey;
    }

    @JsonProperty("ServRangeDts")
    public ServRangeDts getServRangeDts() {
        return servRangeDts;
    }

    @JsonProperty("ServRangeDts")
    public void setServRangeDts(ServRangeDts servRangeDts) {
        this.servRangeDts = servRangeDts;
    }

    @JsonProperty("HomePlanClsrInd")
    public String getHomePlanClsrInd() {
        return homePlanClsrInd;
    }

    @JsonProperty("HomePlanClsrInd")
    public void setHomePlanClsrInd(String homePlanClsrInd) {
        this.homePlanClsrInd = homePlanClsrInd;
    }

    @JsonProperty("ProvEngagementInd")
    public String getProvEngagementInd() {
        return provEngagementInd;
    }

    @JsonProperty("ProvEngagementInd")
    public void setProvEngagementInd(String provEngagementInd) {
        this.provEngagementInd = provEngagementInd;
    }

    @JsonProperty("ProvCntrctingSts")
    public String getProvCntrctingSts() {
        return provCntrctingSts;
    }

    @JsonProperty("ProvCntrctingSts")
    public void setProvCntrctingSts(String provCntrctingSts) {
        this.provCntrctingSts = provCntrctingSts;
    }

    @JsonProperty("HostPlanMedRecMatchInd")
    public String getHostPlanMedRecMatchInd() {
        return hostPlanMedRecMatchInd;
    }

    @JsonProperty("HostPlanMedRecMatchInd")
    public void setHostPlanMedRecMatchInd(String hostPlanMedRecMatchInd) {
        this.hostPlanMedRecMatchInd = hostPlanMedRecMatchInd;
    }

    @JsonProperty("HostPlanClsrInd")
    public String getHostPlanClsrInd() {
        return hostPlanClsrInd;
    }

    @JsonProperty("HostPlanClsrInd")
    public void setHostPlanClsrInd(String hostPlanClsrInd) {
        this.hostPlanClsrInd = hostPlanClsrInd;
    }

    @JsonProperty("ServDts")
    public void setServDts(List<String> servDts){
        this.servDts = servDts;
    }
    
    @JsonProperty("ServDts")
    public List<String> getServDts(){
        return this.servDts;
    }
    
	@JsonProperty("RndrngProvTaxId")
	public String getRndrngProvTaxId() {
		return rndrngProvTaxId;
	}

	@JsonProperty("RndrngProvTaxId")
	public void setRndrngProvTaxId(String rndrngProvTaxId) {
		this.rndrngProvTaxId = rndrngProvTaxId;
	}

	@JsonProperty("RndrngProvAddlInfo")
	public String getRndrngProvAddlInfo() {
		return rndrngProvAddlInfo;
	}

	@JsonProperty("RndrngProvAddlInfo")
	public void setRndrngProvAddlInfo(String rndrngProvAddlInfo) {
		this.rndrngProvAddlInfo = rndrngProvAddlInfo;
	}
    
	@JsonProperty("HEDISMRRMeasurementType")
    public String getHedisMRRMeasurementType() {
		return hedisMRRMeasurementType;
	}

	@JsonProperty("HEDISMRRMeasurementType")
	public void setHedisMRRMeasurementType(String hedisMRRMeasurementType) {
		this.hedisMRRMeasurementType = hedisMRRMeasurementType;
	}

	@JsonProperty("ErrCd")
	public String getErrCd() {
		return errCd;
	}

    @JsonProperty("ErrCd")
	public void setErrCd(String errCd) {
		this.errCd = errCd;
	}

    @JsonProperty("ErrDesc")
	public String getErrDesc() {
		return errDesc;
	}

    @JsonProperty("ErrDesc")
	public void setErrDesc(String errDesc) {
		this.errDesc = errDesc;
	}

    
    
}
