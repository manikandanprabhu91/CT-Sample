package com.carefirst.icentric.batch.service;

import java.util.List;

import com.carefirst.icentric.batch.error.model.ErrorResponse;

public interface EmailService {

	public void sendMail(List<ErrorResponse> errorResponses, String fileName, String categoryInd, int totalrecord);
	
	public void sendStatsUpdateEmail();
	
}
