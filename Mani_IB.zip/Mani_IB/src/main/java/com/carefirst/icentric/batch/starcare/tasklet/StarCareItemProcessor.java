package com.carefirst.icentric.batch.starcare.tasklet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;

@Component("StarCareItemProcessor")
@StepScope
public class StarCareItemProcessor implements ItemProcessor<StarsCareGapReq, StarsCareGapReq> {

	private static final Logger LOGGER = LogManager.getLogger(StarCareItemProcessor.class);
	
	@Override
	public StarsCareGapReq process(final StarsCareGapReq record) throws Exception {
		LOGGER.info(" Enter StarsCareGapReq record processor" );
		
		return record;
	}
}