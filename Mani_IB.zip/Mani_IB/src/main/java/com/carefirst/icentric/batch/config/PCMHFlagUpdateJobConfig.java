///**
// * 
// */
//package com.carefirst.icentric.batch.config;
//
//import javax.persistence.EntityManagerFactory;
//
//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.springframework.batch.core.Job;
//import org.springframework.batch.core.JobExecutionListener;
//import org.springframework.batch.core.Step;
//import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
//import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
//import org.springframework.batch.core.configuration.annotation.StepScope;
//import org.springframework.batch.core.launch.support.RunIdIncrementer;
//import org.springframework.batch.item.ItemProcessor;
//import org.springframework.batch.item.ItemWriter;
//import org.springframework.batch.item.database.JpaPagingItemReader;
//import org.springframework.batch.item.database.builder.JpaPagingItemReaderBuilder;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//
//import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
//import com.carefirst.icentric.batch.exception.ApplicationException;
//import com.carefirst.icentric.batch.PCMHFlagUpdate.tasklet.PCMHFlagUpdateJobCompletionListener;
//import com.carefirst.icentric.batch.PCMHFlagUpdate.tasklet.PCMHFlagUpdateItemProcessor;
//import com.carefirst.icentric.batch.PCMHFlagUpdate.tasklet.PCMHFlagUpdateItemWriter;
//import com.carefirst.icentric.batch.utils.FileUtils;
//
///**
// * @author aab0490
// *
// */
//@Configuration
//@EnableBatchProcessing
//@ComponentScan(basePackageClasses = BatchConfigurer.class)
//public class PCMHFlagUpdateJobConfig {
//	private static final Logger LOGGER = LogManager.getLogger(PCMHFlagUpdateJobConfig.class);
//	@Autowired
//	private JobBuilderFactory mrJobBuilderfactory;
//
//	@Autowired
//	private StepBuilderFactory mrStepBuilderfactory;
//
//	private int pageSize = 100;
//	
//	@Autowired
//    private EntityManagerFactory entityManagerFactory;
//	
//	@Autowired
//	FileUtils fileUtils;
//
//	@Bean
//	public Job PCMHFlagUpdateBatchJob() throws ApplicationException {
//		return mrJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB PCMHFlagUpdate").incrementer(new RunIdIncrementer())
//				.start(readPCMHFlagUpdateData()).listener(PCMHFlagupdateJobCompletionListener()).build();
//	}
//
//	@Bean
//	public JobExecutionListener PCMHFlagupdateJobCompletionListener() {
//		return new PCMHFlagUpdateJobCompletionListener();
//	}
//
//	@Bean
//	public Step readPCMHFlagUpdateData() throws ApplicationException {
//		LOGGER.info("readData - step1() start/end");
//		return mrStepBuilderfactory.get("step1").<PexReqtMembQueue, PexReqtMembQueue>chunk(pageSize)
//				.reader(jpaPCMHFlagUpdateItemReader()).processor(PCMHFlagUpdateItemProcessor()).writer(mrWriter())
//				.build();
//	}
//
//	@Bean
//	public ItemWriter<PexReqtMembQueue> mrWriter() {
//		return new PCMHFlagUpdateItemWriter();
//	}
//
//	@Bean
//	@StepScope
//	public ItemProcessor<PexReqtMembQueue, PexReqtMembQueue> PCMHFlagUpdateItemProcessor() {
//		return new PCMHFlagUpdateItemProcessor();
//	}
//	
//	@Bean
//	public JpaPagingItemReader<PexReqtMembQueue> jpaPCMHFlagUpdateItemReader() throws ApplicationException {
//		JpaPagingItemReader<PexReqtMembQueue> build = new JpaPagingItemReaderBuilder<PexReqtMembQueue>()
//			.name("PCMHFlagUpdateReader")
//			.entityManagerFactory(entityManagerFactory)
//			.queryString("SELECT p FROM PexReqtMembQueue p where p.reqtStusCd NOT IN ('PEX_REQT_STUS04')")
//			.pageSize(pageSize)
//			.build();
//		
//		return build;
//		
//	}
//
//}
