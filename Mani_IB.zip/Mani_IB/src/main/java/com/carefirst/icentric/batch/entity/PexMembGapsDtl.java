package com.carefirst.icentric.batch.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the PEX_MEMB_GAPS_DTLS database table.
 * 
 */
@Entity
@Table(name="PEX_MEMB_GAPS_DTLS")
@NamedQuery(name="PexMembGapsDtl.findAll", query="SELECT p FROM PexMembGapsDtl p")
public class PexMembGapsDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PEX_MEMB_GAPS_DTLS_PEXMEMBGAPSDTLSSKEY_GENERATOR", sequenceName="PEX_MEMB_GAPS_DTLS_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PEX_MEMB_GAPS_DTLS_PEXMEMBGAPSDTLSSKEY_GENERATOR")
	@Column(name="PEX_MEMB_GAPS_DTLS_SKEY")
	private long pexMembGapsDtlsSkey;

	@Column(name="ADDL_INFO_HOST_PLN")
	private String addlInfoHostPln;

	@Column(name="AUD_INSRT_ID")
	private String audInsrtId;

	@Column(name="AUD_INSRT_TMSTP")
	private Timestamp audInsrtTmstp;

	@Column(name="AUD_UPDT_ID")
	private String audUpdtId;

	@Column(name="AUD_UPDT_TMSTP")
	private Timestamp audUpdtTmstp;

	@Column(name="CLS_GAP_INFO_RCVD")
	private String clsGapInfoRcvd;

	@Column(name="CLS_SF_DT")
	private String clsSfDt;

	@Column(name="GAP_ID")
	private BigDecimal gapId;

	@Column(name="GAP_IDTFN_RTNL")
	private String gapIdtfnRtnl;

	@Column(name="GAP_MEAS_CD")
	private String gapMeasCd;

	@Column(name="GAP_MEAS_TYP")
	private String gapMeasTyp;

	@Column(name="HCC_CLM_CD")
	private String hccClmCd;

	@Column(name="HCC_CLM_TYP")
	private String hccClmTyp;

	@Column(name="HM_PLN_GAP_CLS_INDC")
	private String hmPlnGapClsIndc;

	@Column(name="HM_PLN_GAP_CLS_TYP")
	private String hmPlnGapClsTyp;

	@Column(name="HST_PLN_GAP_CLS_INDC")
	private String hstPlnGapClsIndc;

	@Column(name="HST_PLN_GAP_CLS_TYP")
	private String hstPlnGapClsTyp;

	@Column(name="MIS_DIAG_CD")
	private String misDiagCd;

	@Column(name="MIS_DIAG_CD_DESC")
	private String misDiagCdDesc;

	@Column(name="MIS_DIAG_CD_SRVC_DT")
	private String misDiagCdSrvcDt;

	@Column(name="MIS_HCC_CD")
	private String misHccCd;

	@Column(name="MIS_HCC_CD_DESC")
	private String misHccCdDesc;

	@Column(name="MIS_PROV_NPI_DIAG_CD")
	private String misProvNpiDiagCd;

	@Column(name="PROS_RET_IDNT_CD")
	private String prosRetIdntCd;

	@Column(name="PROS_RET_IDNT_TYP")
	private String prosRetIdntTyp;

	@Column(name="REQTD_ACTN")
	private String reqtdActn;

	@Column(name="RSK_ADJ_GAP_CD")
	private String rskAdjGapCd;

	@Column(name="RSK_ADJ_GAP_TYP")
	private String rskAdjGapTyp;

	@Column(name="SCCF_ID")
	private String sccfId;

	//bi-directional many-to-one association to PexReqtMembQueue
	@ManyToOne
	@JoinColumn(name="PEX_REQT_MEMB_QUEUE_SKEY")
	private PexReqtMembQueue pexReqtMembQueue;

	public PexMembGapsDtl() {
	}

	public long getPexMembGapsDtlsSkey() {
		return this.pexMembGapsDtlsSkey;
	}

	public void setPexMembGapsDtlsSkey(long pexMembGapsDtlsSkey) {
		this.pexMembGapsDtlsSkey = pexMembGapsDtlsSkey;
	}

	public String getAddlInfoHostPln() {
		return this.addlInfoHostPln;
	}

	public void setAddlInfoHostPln(String addlInfoHostPln) {
		this.addlInfoHostPln = addlInfoHostPln;
	}

	public String getAudInsrtId() {
		return this.audInsrtId;
	}

	public void setAudInsrtId(String audInsrtId) {
		this.audInsrtId = audInsrtId;
	}

	public Timestamp getAudInsrtTmstp() {
		return this.audInsrtTmstp;
	}

	public void setAudInsrtTmstp(Timestamp audInsrtTmstp) {
		this.audInsrtTmstp = audInsrtTmstp;
	}

	public String getAudUpdtId() {
		return this.audUpdtId;
	}

	public void setAudUpdtId(String audUpdtId) {
		this.audUpdtId = audUpdtId;
	}

	public Timestamp getAudUpdtTmstp() {
		return this.audUpdtTmstp;
	}

	public void setAudUpdtTmstp(Timestamp audUpdtTmstp) {
		this.audUpdtTmstp = audUpdtTmstp;
	}

	public String getClsGapInfoRcvd() {
		return this.clsGapInfoRcvd;
	}

	public void setClsGapInfoRcvd(String clsGapInfoRcvd) {
		this.clsGapInfoRcvd = clsGapInfoRcvd;
	}

	public String getClsSfDt() {
		return this.clsSfDt;
	}

	public void setClsSfDt(String clsSfDt) {
		this.clsSfDt = clsSfDt;
	}

	public BigDecimal getGapId() {
		return this.gapId;
	}

	public void setGapId(BigDecimal gapId) {
		this.gapId = gapId;
	}

	public String getGapIdtfnRtnl() {
		return this.gapIdtfnRtnl;
	}

	public void setGapIdtfnRtnl(String gapIdtfnRtnl) {
		this.gapIdtfnRtnl = gapIdtfnRtnl;
	}

	public String getGapMeasCd() {
		return this.gapMeasCd;
	}

	public void setGapMeasCd(String gapMeasCd) {
		this.gapMeasCd = gapMeasCd;
	}

	public String getGapMeasTyp() {
		return this.gapMeasTyp;
	}

	public void setGapMeasTyp(String gapMeasTyp) {
		this.gapMeasTyp = gapMeasTyp;
	}

	public String getHccClmCd() {
		return this.hccClmCd;
	}

	public void setHccClmCd(String hccClmCd) {
		this.hccClmCd = hccClmCd;
	}

	public String getHccClmTyp() {
		return this.hccClmTyp;
	}

	public void setHccClmTyp(String hccClmTyp) {
		this.hccClmTyp = hccClmTyp;
	}

	public String getHmPlnGapClsIndc() {
		return this.hmPlnGapClsIndc;
	}

	public void setHmPlnGapClsIndc(String hmPlnGapClsIndc) {
		this.hmPlnGapClsIndc = hmPlnGapClsIndc;
	}

	public String getHmPlnGapClsTyp() {
		return this.hmPlnGapClsTyp;
	}

	public void setHmPlnGapClsTyp(String hmPlnGapClsTyp) {
		this.hmPlnGapClsTyp = hmPlnGapClsTyp;
	}

	public String getHstPlnGapClsIndc() {
		return this.hstPlnGapClsIndc;
	}

	public void setHstPlnGapClsIndc(String hstPlnGapClsIndc) {
		this.hstPlnGapClsIndc = hstPlnGapClsIndc;
	}

	public String getHstPlnGapClsTyp() {
		return this.hstPlnGapClsTyp;
	}

	public void setHstPlnGapClsTyp(String hstPlnGapClsTyp) {
		this.hstPlnGapClsTyp = hstPlnGapClsTyp;
	}

	public String getMisDiagCd() {
		return this.misDiagCd;
	}

	public void setMisDiagCd(String misDiagCd) {
		this.misDiagCd = misDiagCd;
	}

	public String getMisDiagCdDesc() {
		return this.misDiagCdDesc;
	}

	public void setMisDiagCdDesc(String misDiagCdDesc) {
		this.misDiagCdDesc = misDiagCdDesc;
	}

	public String getMisDiagCdSrvcDt() {
		return this.misDiagCdSrvcDt;
	}

	public void setMisDiagCdSrvcDt(String misDiagCdSrvcDt) {
		this.misDiagCdSrvcDt = misDiagCdSrvcDt;
	}

	public String getMisHccCd() {
		return this.misHccCd;
	}

	public void setMisHccCd(String misHccCd) {
		this.misHccCd = misHccCd;
	}

	public String getMisHccCdDesc() {
		return this.misHccCdDesc;
	}

	public void setMisHccCdDesc(String misHccCdDesc) {
		this.misHccCdDesc = misHccCdDesc;
	}

	public String getMisProvNpiDiagCd() {
		return this.misProvNpiDiagCd;
	}

	public void setMisProvNpiDiagCd(String misProvNpiDiagCd) {
		this.misProvNpiDiagCd = misProvNpiDiagCd;
	}

	public String getProsRetIdntCd() {
		return this.prosRetIdntCd;
	}

	public void setProsRetIdntCd(String prosRetIdntCd) {
		this.prosRetIdntCd = prosRetIdntCd;
	}

	public String getProsRetIdntTyp() {
		return this.prosRetIdntTyp;
	}

	public void setProsRetIdntTyp(String prosRetIdntTyp) {
		this.prosRetIdntTyp = prosRetIdntTyp;
	}

	public String getReqtdActn() {
		return this.reqtdActn;
	}

	public void setReqtdActn(String reqtdActn) {
		this.reqtdActn = reqtdActn;
	}

	public String getRskAdjGapCd() {
		return this.rskAdjGapCd;
	}

	public void setRskAdjGapCd(String rskAdjGapCd) {
		this.rskAdjGapCd = rskAdjGapCd;
	}

	public String getRskAdjGapTyp() {
		return this.rskAdjGapTyp;
	}

	public void setRskAdjGapTyp(String rskAdjGapTyp) {
		this.rskAdjGapTyp = rskAdjGapTyp;
	}

	public String getSccfId() {
		return this.sccfId;
	}

	public void setSccfId(String sccfId) {
		this.sccfId = sccfId;
	}

	public PexReqtMembQueue getPexReqtMembQueue() {
		return this.pexReqtMembQueue;
	}

	public void setPexReqtMembQueue(PexReqtMembQueue pexReqtMembQueue) {
		this.pexReqtMembQueue = pexReqtMembQueue;
	}

}