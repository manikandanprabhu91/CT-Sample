package com.carefirst.icentric.batch.utils;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.StringJoiner;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.medrec.model.MedRecReq;
import com.carefirst.icentric.batch.medrec.model.MedRecReqObj;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.NetworkDetails;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to process MedRec records.
 * @author aad7740
 *
 */
@Component
public class MedRecUtils {

	private static final Logger LOGGER = LogManager.getLogger(MedRecUtils.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	@Autowired
	ProvSearch provSearch;

	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;

	public void updatePexTableColumns(MedRecReq medRecpReq, List<PexReqtMembQueue> pexReqtMembQueueList) throws Exception {
		LOGGER.info(":::::::::::MedRecUtils execute method updatePexTableColumns::::::>>>>>> ");

		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);

		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));

		pexReqtMembQueue.setMembDob(medRecpReq.getMemberDOB());
		pexReqtMembQueue.setHmPlanClsInd(medRecpReq.getHomePlanClsrInd());
		//new
		pexReqtMembQueue.setRndrProvTnxmyCd(medRecpReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setCpbltyIndcCd(medRecpReq.getCapabilityInd());
		pexReqtMembQueue.setItsSubscrId(medRecpReq.getITSSubscriberId());
		pexReqtMembQueue.setBillProvNpi(medRecpReq.getBillProvNPI());	
		pexReqtMembQueue.setRndrProvNpi(medRecpReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(medRecpReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(medRecpReq.getBillProvZipCode());
		pexReqtMembQueue.setHedisMeasmtTyp(medRecpReq.getHedisMRRMeasurementType());
		pexReqtMembQueue.setMedRecMtchTyp(medRecpReq.getMedRecReqType());
		pexReqtMembQueue.setMmiId(medRecpReq.getMMIId());
		pexReqtMembQueue.setMembFullNm(medRecpReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(medRecpReq.getMemberGender());
		pexReqtMembQueue.setSccfId(medRecpReq.getSCCFIds());
		pexReqtMembQueue.setProvEngmtIndc(medRecpReq.getProvEngagementInd());
		pexReqtMembQueue.setHmPlanId(medRecpReq.getHomePlanId());
		pexReqtMembQueue.setBillProvId(medRecpReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(medRecpReq.getRndrngProvProprietaryId());
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat dateFormatTwo = new SimpleDateFormat("MM/dd/yyyy");
		if(medRecpReq.getServDts() != null) {
			StringJoiner joiner = new StringJoiner(",");
			for(String servDt : medRecpReq.getServDts()) {
				if(servDt != null) {
					
						joiner.add(String.valueOf(dateFormatTwo.format(dateFormat.parse(servDt))));
					
				}
			}
			pexReqtMembQueue.setServcDt(joiner.toString());
		}
		pexReqtMembQueue.setRndrProvTaxId(medRecpReq.getRndrngProvTaxId());
		pexReqtMembQueue.setAddnlInfo(medRecpReq.getRndrngProvAddlInfo());
		//new	
		pexReqtMembQueue.setMembHstPlnId(medRecpReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(medRecpReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(medRecpReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(medRecpReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setRndrProvZipCd(medRecpReq.getRndrngProvZipCode());
//		pexReqtMembQueue.setMedRecMtchIndc(medRecpReq.getHostPlanMedRecMatchInd());
//		pexReqtMembQueue.setHstPlnClsInd(medRecpReq.getHostPlanClsrInd());
		
		//new
		pexReqtMembQueue.setProvPlnCd(medRecpReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(medRecpReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(medRecpReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(medRecpReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(medRecpReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());

		String[] clsInd = Constants.CLSR_IND;
		if(Arrays.asList(clsInd).contains(medRecpReq.getHomePlanClsrInd()) || Constants.MATCHED.equalsIgnoreCase(medRecpReq.getHostPlanMedRecMatchInd())){
			LOGGER.info(":::::::::::MedRecUtils execute method  updatePexTableColumns getHomePlanClsrInd::::::>>>>>> "
					+ medRecpReq.getHomePlanClsrInd() +"MedrecMatchIndc:" + medRecpReq.getHostPlanMedRecMatchInd());
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}

		pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
	}

	public PexReqtMembQueue setJsonPojoToEntityClass(MedRecReq medRecpReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(medRecpReq, pexReqtMembQueue);
		setPexReqtJsonDetails(medRecpReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	public void setPexReqtMembQueueData(MedRecReq medRecpReq, PexReqtMembQueue pexReqtMembQueue) throws Exception {

		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setProvEngmtReqtId(medRecpReq.getProvEngmntReqId());
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setCpbltyIndcCd(medRecpReq.getCapabilityInd());
		pexReqtMembQueue.setMedRecTypCd(medRecpReq.getMedRecReqType());
		pexReqtMembQueue.setHmPlanId(medRecpReq.getHomePlanId());
		pexReqtMembQueue.setMembHstPlnId(medRecpReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(medRecpReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(medRecpReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(medRecpReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setItsSubscrId(medRecpReq.getITSSubscriberId());
		pexReqtMembQueue.setMembDob(medRecpReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(medRecpReq.getMMIId());
	// pexReqtMembQueue.setMembFrstNm(riskAdjGapReq.getMemberFullName());
		// //need to set first name
		//pexReqtMembQueue.setMembLastNm(riskAdjGapReq.getMemberFullName());
		// //need to set last name
		pexReqtMembQueue.setMembFullNm(medRecpReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(medRecpReq.getMemberGender());
		// pexReqtMembQueue.setCloseGapCnt(new
		// BigDecimal(medRecpReq.getNumofGapClosures()));
		pexReqtMembQueue.setBillProvId(medRecpReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(medRecpReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setBillProvNpi(medRecpReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(medRecpReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(medRecpReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(medRecpReq.getBillProvZipCode());
		pexReqtMembQueue.setRndrProvZipCd(medRecpReq.getRndrngProvZipCode());
		pexReqtMembQueue.setSccfId(medRecpReq.getSCCFIds());
		pexReqtMembQueue.setRndrProvTnxmyCd(medRecpReq.getRndrngProvTxnmyCd());
		// pexReqtMembQueue.setPrevGapClsProv(riskAdjGapReq.getGapPrevouslyClosedByThisProv());
		// pexReqtMembQueue.setPrsntDiag(medRecpReq.getPresentDiagnoses());
		// pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(medRecpReq.getCurrentDiagnosesRndrngProvNPI()));
		pexReqtMembQueue.setProvEngmtIndc(medRecpReq.getProvEngagementInd());
		pexReqtMembQueue.setProvPartStus(medRecpReq.getProvCntrctingSts());
		pexReqtMembQueue.setMedRecMtchIndc(medRecpReq.getHostPlanMedRecMatchInd());

		pexReqtMembQueue.setHstPlnClsInd(medRecpReq.getHostPlanClsrInd());
		// pexReqtMembQueue.setReqtStusTyp(reqtStusTyp);
		// pexReqtMembQueue.setReqtStusCd(reqtStusCd);
		pexReqtMembQueue.setServcBegDt(medRecpReq.getServRangeDts().getServBeginDt());
		pexReqtMembQueue.setServcEndDt(medRecpReq.getServRangeDts().getServEndDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setProvPlnCd(medRecpReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(medRecpReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(medRecpReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(medRecpReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(medRecpReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setHmPlanClsInd(medRecpReq.getHomePlanClsrInd());
		LOGGER.info("::::::::::::::setPexReqtMembQueueData >>> getHomePlanClsrInd" +medRecpReq.getHomePlanClsrInd());
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);
		String[] clsInd = Constants.CLSR_IND;
		if(Arrays.asList(clsInd).contains(medRecpReq.getHomePlanClsrInd()) || Constants.MATCHED.equalsIgnoreCase(medRecpReq.getHostPlanMedRecMatchInd())){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat dateFormatTwo = new SimpleDateFormat("MM/dd/yyyy");
		pexReqtMembQueue.setAddnlInfo(medRecpReq.getRndrngProvAddlInfo());
		pexReqtMembQueue.setRndrProvTaxId(medRecpReq.getRndrngProvTaxId());
		pexReqtMembQueue.setHedisMeasmtTyp(medRecpReq.getHedisMRRMeasurementType());
		if(medRecpReq.getServDts() != null) {
			StringJoiner joiner = new StringJoiner(",");
			for(String servDt : medRecpReq.getServDts()) {
				if(servDt != null) {
					joiner.add(String.valueOf(dateFormatTwo.format(dateFormat.parse(servDt))));
				}
			}
			pexReqtMembQueue.setServcDt(joiner.toString());
		}

		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(medRecpReq.getRndrngProvProprietaryId(), pexReqtMembQueue);
	}

	public void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch
					.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				boolean isStatusCheck = false;
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderName::::::::: "
									+ practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber ::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							// pexReqtMembQueue.setRndrProvZipCd(practitioner.getPractitionerZip());
							// pexReqtMembQueue.setRndrProvNpi(practitioner.getPractitionerNPI());

							/*if(practitioner.getNetworkDetails().size() > 0) {
								for(NetworkDetails networkDetails : practitioner.getNetworkDetails()) {
									if(Constants.NT_ID_200.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(!Constants.NT_ID_200.equals(networkDetails.getNetworkID()) || !Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = false;
										break;
									}
								}
							} 

							if(isStatusCheck) {
								pexReqtMembQueue.setProvPartStus("N");
							} else {
								pexReqtMembQueue.setProvPartStus("P");
							}*/
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	public void setPexReqtJsonDetails(MedRecReq medRecpReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String medRecReqJson = mapper.writeValueAsString(medRecpReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(medRecReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}

	public void updatePexReqtJsonDetails(MedRecReq medRecpReq, List<PexReqtMembQueue> pexReqtMembQueueList) throws Exception {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			MedRecReq readValue = objectMapper.readValue(reqtJson, MedRecReq.class);
			readValue.setMemberHostPlanId(medRecpReq.getMemberHostPlanId());
			//new
			readValue.setCapabilityInd(medRecpReq.getCapabilityInd());
			readValue.setITSSubscriberId(medRecpReq.getITSSubscriberId());
			readValue.setBillProvNPI(medRecpReq.getBillProvNPI());	
			readValue.setRndrngProvNPI(medRecpReq.getRndrngProvNPI());
			readValue.setRndrngProvHostPlanId(medRecpReq.getRndrngProvHostPlanId());
			readValue.setBillProvZipCode(medRecpReq.getBillProvZipCode());
			readValue.setHedisMRRMeasurementType(medRecpReq.getHedisMRRMeasurementType());
			readValue.setMedRecReqType(medRecpReq.getMedRecReqType());
			readValue.setMMIId(medRecpReq.getMMIId());
			readValue.setMemberFullName(medRecpReq.getMemberFullName());
			readValue.setMemberGender(medRecpReq.getMemberGender());
			readValue.setRndrngProvTxnmyCd(medRecpReq.getRndrngProvTxnmyCd());
			readValue.setSCCFIds(medRecpReq.getSCCFIds());
			readValue.setProvEngagementInd(medRecpReq.getProvEngagementInd());
			readValue.setHomePlanId(medRecpReq.getHomePlanId());
			readValue.setBillProvProprietaryId(medRecpReq.getBillProvProprietaryId());
			readValue.setRndrngProvProprietaryId(medRecpReq.getRndrngProvProprietaryId());
			readValue.setProvCntrctingSts(medRecpReq.getProvCntrctingSts());
			readValue.setMemberPCP5PartKey(medRecpReq.getMemberPCP5PartKey());
			readValue.setServDts(medRecpReq.getServDts());
			readValue.setRndrngProvTaxId(medRecpReq.getRndrngProvTaxId());
			readValue.setRndrngProvAddlInfo(medRecpReq.getRndrngProvAddlInfo());
			//new	
			readValue.setRoutetoHostPlanId(medRecpReq.getRoutetoHostPlanId());
			readValue.setFirstTimeSenttoHostPlanDt(medRecpReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(medRecpReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(medRecpReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(medRecpReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(medRecpReq.getMemberDOB());
			readValue.setRndrngProvZipCode(medRecpReq.getRndrngProvZipCode());
			readValue.setHomePlanClsrInd(medRecpReq.getHomePlanClsrInd());
			readValue.setHostPlanMedRecMatchInd(medRecpReq.getHostPlanMedRecMatchInd());
			readValue.setHostPlanClsrInd(medRecpReq.getHostPlanClsrInd());	

			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		} catch (JsonParseException ex) {
			LOGGER.error("Error Occuring MedRecUtils updatePexReqtJsonDetails JsonParseException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (JsonMappingException ex) {
			LOGGER.error("Error Occuring MedRecUtils updatePexReqtJsonDetails JsonMappingException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (IOException ex) {
			LOGGER.error("Error Occuring MedRecUtils updatePexReqtJsonDetails IOException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}

	public List<ErrorResponse> medicalRecordsErrorResponse(MedRecReqObj medRecReqObj , String filename)
			throws Exception {
		int firstIndx = filename.indexOf(Constants.ERROR_REPORT_STR);
		int last = filename.indexOf(Constants.DOT);
		String fileName = filename.substring(firstIndx, last);
		List<ErrorResponse> errorResponses = new ArrayList<>();
		if(medRecReqObj != null) {
			if(!medRecReqObj.getMedRecReq().isEmpty()) {
				for(MedRecReq medRecReq : medRecReqObj.getMedRecReq()) {
					if(medRecReq.getErrCd() != null) {
						ErrorResponse errorResponse = new ErrorResponse();
						errorResponse.setCategory(Constants.CATEGORY_IND_MR);
						errorResponse.setFileName(fileName.replace(Constants.ERROR_REPORT, Constants.EMPTY_STRING));
						errorResponse.setErrorCode(medRecReq.getErrCd());
						errorResponse.setErrorDesc(medRecReq.getErrDesc());
						errorResponse.setProviderEngagementID(medRecReq.getProvEngmntReqId());
						errorResponses.add(errorResponse);
					}
				}
			}
		}
		return errorResponses;
	}

}
