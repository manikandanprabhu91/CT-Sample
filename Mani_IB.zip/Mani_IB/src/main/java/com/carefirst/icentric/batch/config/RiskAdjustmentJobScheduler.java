package com.carefirst.icentric.batch.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.utils.FileUtils;

/**
 * @author aab8788
 *
 */
@Component
public class RiskAdjustmentJobScheduler implements SchedulingConfigurer {
	private static final Logger LOGGER = LogManager.getLogger(RiskAdjustmentJobScheduler.class);

	private final int POOL_SIZE = 10;

	@Autowired
	private JobLauncher jobLauncherRiskAdj;

	@Autowired
	private RiskAdjustmentJobConfig riskAdjJobConfig;

	@Autowired
	private JobExplorer riskAdjJobExplorer;

	@Autowired
	private FileUtils fileUtil;

	/**
	 * This method is used to register the scheduled tasks
	 * 
	 * @param scheduledTaskRegistrar
	 */
	@Override
	public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
		LOGGER.info("> configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		LOGGER.info("< configureTasks");

	}

	/**
	 * This method is used to schedule the Risk Adj batch Job
	 * 
	 */
//	@Scheduled(cron = "${medvantage.inbound.batch.riskadj.cron}")
	public void scheduler() {
		// set transaction ID for daily job run
		String transactionId = UUID.randomUUID().toString();
		MDC.put("transactionId", "RiskAdj: " + transactionId);
		LOGGER.info("> RiskAdj batchJob");
		Map<String, JobParameter> jobParamMap = new HashMap<>();
		jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));

		List<FileSystemResource> list = fileUtil.getFiles("ra");
		if (list.isEmpty()) {
			LOGGER.info("No Files to Process, Hence returning from riskAdjScheduler()");
			return;
		}
		
		Pattern digitPattern = Pattern.compile("\\d{3}");
		List<String> jsonFiles = new ArrayList<>();
		List<String> attachFiles = new ArrayList<>();
		String fileType = "";
		
		for (FileSystemResource fileSystemResource : list) {
			if(fileSystemResource.getFilename().toLowerCase().contains("_ra")) {
				jsonFiles.add(fileSystemResource.getPath());
			} else if (fileSystemResource.getFilename().toLowerCase().contains("ra".toLowerCase()) && digitPattern.matcher(
					fileSystemResource.getFilename().substring(0, 3)).matches()) {
				attachFiles.add(fileSystemResource.getPath());
			}

		}

		if(!jsonFiles.isEmpty()) {
			fileType = "json";
			jobParamMap.put("attachFileExten", new JobParameter("json"));
			runRiskAdjustmentRecord(jsonFiles, fileType, jobParamMap);
		}
		
		if(!attachFiles.isEmpty()){
			fileType = "attachment";
			jobParamMap.put("attachFileExten", new JobParameter("attachment"));
			runRiskAdjustmentRecord(attachFiles, fileType, jobParamMap);
		}

		MDC.clear();
		MDC.remove("transactionId");
	}

	private void runRiskAdjustmentRecord(List<String> files, String fileType, Map<String, JobParameter> jobParamMap) {
		LOGGER.info("> runRiskAdjustmentRecord");
		try {
			String filesPath = "";
			for(String file : files) {

				filesPath = file.toString().replace("[", "").replace("]", "").replace("\"", "");
				jobParamMap.put("riskAdjFileName", new JobParameter(filesPath));
				jobParamMap.put("attchFileName", new JobParameter(filesPath));
				jobParamMap.put(Constants.CATEGORY_IND, new JobParameter(Constants.CATEGORY_IND_RA));
				
//				if("json".equals(fileType)) {
//					fileUtil.modifyJsonFileContent(filesPath,"RiskAdjustmentGapReq");
//				}
				JobParameters jobParams = new JobParameters(jobParamMap);

				try {
					while (true) {
						Set<org.springframework.batch.core.JobExecution> jobExecutions = riskAdjJobExplorer
								.findRunningJobExecutions(riskAdjJobConfig.riskAdjBatchJob().getName());
						boolean runFilejob = !jobExecutions.isEmpty();
						if (runFilejob) {
							LOGGER.info("RiskAdj Job is already running waiting to restart");
							Thread.sleep(30000);
						} else {
							LOGGER.info("RiskAdj the MedRecReq job");
							break;
						}
					}
					// Job is triggered to execute the tasks
					if("json".equals(fileType)) {
						jobLauncherRiskAdj.run(riskAdjJobConfig.riskAdjBatchJob(), jobParams);	
					} else if("attachment".equals(fileType)) {
						jobLauncherRiskAdj.run(riskAdjJobConfig.riskAdjAttachmentBatchJob(), jobParams);
					}


					LOGGER.info("< RiskAdj batchJob");
				} catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
						| JobParametersInvalidException | org.springframework.batch.core.repository.JobRestartException
						| InterruptedException e) {
					LOGGER.error("Exception Occued :" + e.getMessage(), e);
				}

			}
		} catch (Exception e) {
			LOGGER.error("Exception Occued :" + e.getMessage(), e);
		}
		
	}

	public boolean triggerJobFromWeb() throws Exception {
		LOGGER.info("> triggerJobFromWeb");
		Set<org.springframework.batch.core.JobExecution> jobExecutions = riskAdjJobExplorer
				.findRunningJobExecutions(riskAdjJobConfig.riskAdjBatchJob().getName());
		boolean runFilejob = !jobExecutions.isEmpty();
		if (runFilejob) {
			LOGGER.info("< triggerJobFromWeb");
			throw new Exception("JOB is running. Please try again later");
		} else {
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				scheduler();
				LOGGER.info("< triggerJobFromWeb");
			});
		}
		return true;
	}

}
