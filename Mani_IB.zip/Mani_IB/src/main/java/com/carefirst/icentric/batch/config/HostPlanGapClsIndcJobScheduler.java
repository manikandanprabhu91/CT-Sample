package com.carefirst.icentric.batch.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;

/**
 * @author aaa6364
 *
 */
@Component
public class HostPlanGapClsIndcJobScheduler implements SchedulingConfigurer {
	private static final Logger LOGGER = LogManager.getLogger(HostPlanGapClsIndcJobScheduler.class);

	private static final int POOL_SIZE = 10;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;
	
	@Autowired
	PexReqtMembQueueDAO pexMemQueueDao;
	
	@Scheduled(cron = "${medvantage.inbound.batch.updategap.cron}")
	public void hostPlanScheduler() {
		LOGGER.info("> hostPlanScheduler");
		updateHostPlan();
		LOGGER.info("< hostPlanScheduler");
	}

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		LOGGER.info("> Error Response configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		taskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		
	}
	
	private int updateHostPlan(){
		LOGGER.info("> updateHostPlan");
		
		int noOfRowsScRa = pexMembGapsDtlDAO.updateHstPlanIndcGreaterThan180Days();
		pexMembGapsDtlDAO.flush();
		LOGGER.info("< updateHostPlan. Total Nnumber of rows updated in gaps table" + noOfRowsScRa);
		
		int noOfRowsfrStatusUpdateForSCandRA = pexMemQueueDao.updateStatusForScRa();
		pexMemQueueDao.flush();
		LOGGER.info("< updateHostPlan. Total Nnumber of rows updated in memQueue table" + noOfRowsfrStatusUpdateForSCandRA);
		
		int noOfRowsMR = pexMemQueueDao.updateHstPlanIndMRcGreaterThan180Days();
		pexMemQueueDao.flush();
		LOGGER.info("< updateHostPlan. Total Nnumber of rows updated for MR in maintable" + noOfRowsMR);
		
		LOGGER.info("< updateHostPlan");
		return noOfRowsfrStatusUpdateForSCandRA+noOfRowsMR;
		
	}

}
