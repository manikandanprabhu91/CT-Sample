package com.carefirst.icentric.batch.tasklet;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.FileAtchDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.utils.FileUtils;

public class AttachmentFileInsertTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(AttachmentFileInsertTasklet.class);

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	private FileUtils fileUtil;

	@Value("${medvantage.file.attachment.path}")
	String fileAttchPath;

	String fileName;

	String fileExtension;

	String fileInbundPath;

	public String getFileAttchPath() {
		return fileAttchPath;
	}


	@Override
	public void beforeStep(StepExecution stepExecution) {
		JobParameters parameters = stepExecution.getJobExecution().getJobParameters();
		Map<String, JobParameter> jobParamMap = parameters.getParameters();
		JobParameter param = jobParamMap.get("attchFileName");
		JobParameter fileExtnparam = jobParamMap.get("attachFileExten");
		String filePath = (String) param.getValue();
		fileInbundPath = (String) param.getValue();
		this.fileExtension = (String) fileExtnparam.getValue();
		this.fileName = filePath.replaceAll(fileUtil.getInBoundPath(), "");
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		LOGGER.info("> afterStep");
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {

		LOGGER.info(":::::::::::: Inside AttachmentItemWriter write method::::::::::::::: ");
		try {
			if("attachment".equals(this.fileExtension)) {
				long pexReqtMembQueueSkey = 0;
				FileAtchDtl fileAtchDtl = null;
				String provEngmtReqtId = "";
				int startIndex = this.fileName.indexOf(".");

				if(this.fileName.contains("_")) {
					provEngmtReqtId = this.fileName.substring(0, startIndex).substring(0, this.fileName.substring(0, startIndex).indexOf("_"));
				} else {
					provEngmtReqtId = this.fileName.substring(0, startIndex);
				}

				List<PexReqtMembQueue> membQueues = pexReqtMembQueueDAO.findByProvEngmtReqtId(provEngmtReqtId);
				if(membQueues != null) {
					for(PexReqtMembQueue membQueue : membQueues) {
						pexReqtMembQueueSkey = membQueue.getPexReqtMembQueueSkey();
						break;
					}
				}
				if(pexReqtMembQueueSkey > 0) {
					fileAtchDtl = setFileAtchDtl(pexReqtMembQueueSkey);
					fileAtchDtlDAO.saveAndFlush(fileAtchDtl);
				} else {
					//Need to construct error message send to mail...s
				}
			}
		} catch (Exception ex) {
			LOGGER.error("Exception found attachment file processing :: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}

		return RepeatStatus.FINISHED;
	}


	private FileAtchDtl setFileAtchDtl(long pexReqtMembQueueSkey) throws Exception {
		FileAtchDtl fileAtchDtl = new FileAtchDtl();
		try {
			fileAtchDtl.setAudInsrtId("SYSTEM");
			fileAtchDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
			fileAtchDtl.setAudUpdtId("SYSTEM");
			fileAtchDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
			fileAtchDtl.setAtchNm(this.fileName);
			if(this.fileName.toLowerCase().contains("sc")) {
				fileAtchDtl.setFilePath(fileAttchPath+"\\SC\\");
			} else if(this.fileName.toLowerCase().contains("ra")) {
				fileAtchDtl.setFilePath(fileAttchPath+"\\RA\\");
			} else if(this.fileName.toLowerCase().contains("mr")) {
				fileAtchDtl.setFilePath(fileAttchPath+"\\MR\\");
			}
			fileAtchDtl.setAtchAsscdEntSkey(pexReqtMembQueueSkey);
			fileAtchDtl.setAtchAsscdEntQlfr("PEX_REQT_MEMB_QUEUE_SKEY");
			fileAtchDtl.setRefncFileTyp("FILE_ATCH_TYP");
			fileAtchDtl.setRefncFileTypCd("INBND"); // SRCFILE for currently-INBOUND


		} catch (Exception ex) {
			LOGGER.error("Exception found while reading the input file:: ::::::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
		return fileAtchDtl;
	}

}
