package com.carefirst.icentric.batch.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.constant.Constants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtJsonDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.error.model.ErrorResponse;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGap;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjGapReqObj;
import com.carefirst.icentric.batch.riskadj.model.RiskAdjustmentGapReq;
import com.carefirst.icentric.batch.service.ProvSearch;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.NetworkDetails;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Practitioner;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.Provider;
import com.carefirst.pcmh.provsearch.provpractitioner.schema._201307.ProviderResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to process RiskAdj records.
 * @author aad7740
 *
 */
@Component
public class RiskAdjUtils {
	
	private static final Logger LOGGER = LogManager.getLogger(RiskAdjUtils.class);
	
	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtlDAO;

	@Autowired
	FileAtchDtlDAO fileAtchDtlDAO;

	@Autowired
	ProvSearch provSearch;

	String fileName;

	String fileExtension;
	
	@Autowired
	PexReqtJsonDtlDAO pexReqtJsonDtlDAO;
	
	public void updatePexReqtJsonDetails(RiskAdjustmentGapReq riskAdjGapReq, List<PexReqtMembQueue> pexReqtMembQueueList) throws Exception {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		long pexReqtMembQueueSkey = pexReqtMembQueue.getPexReqtMembQueueSkey();
		PexReqtJsonDtl pexReqtJsonDtl = pexReqtJsonDtlDAO.findByPexReqtMembQueueSkey(pexReqtMembQueueSkey);
		String reqtJson = pexReqtJsonDtl.getReqtJson();
		ObjectMapper objectMapper = new ObjectMapper();
		
		try {
			RiskAdjustmentGapReq readValue = objectMapper.readValue(reqtJson, RiskAdjustmentGapReq.class);
			
			//new
			readValue.setCapabilityInd(riskAdjGapReq.getCapabilityInd());
			readValue.setHomePlanId(riskAdjGapReq.getHomePlanId());
			readValue.setITSSubscriberId(riskAdjGapReq.getITSSubscriberId());
			readValue.setNumofGapClosures(riskAdjGapReq.getNumofGapClosures());
			readValue.setBillProvProprietaryId(riskAdjGapReq.getBillProvProprietaryId());
			readValue.setRndrngProvProprietaryId(riskAdjGapReq.getRndrngProvProprietaryId());
			readValue.setBillProvNPI(riskAdjGapReq.getBillProvNPI());
			readValue.setRndrngProvNPI(riskAdjGapReq.getRndrngProvNPI());
			readValue.setRndrngProvHostPlanId(riskAdjGapReq.getRndrngProvHostPlanId());
			readValue.setBillProvZipCode(riskAdjGapReq.getBillProvZipCode());
			readValue.setRndrngProvZipCode(riskAdjGapReq.getRndrngProvZipCode());
			readValue.setRndrngProvTxnmyCd(riskAdjGapReq.getRndrngProvTxnmyCd());
			readValue.setSCCFIds(riskAdjGapReq.getSCCFIds());
			readValue.setProvEngagementInd(riskAdjGapReq.getProvEngagementInd());
			readValue.setRndrngProvTaxId(riskAdjGapReq.getRndrngProvTaxId());
			readValue.setRndrngProvAddlInfo(riskAdjGapReq.getRndrngProvAddlInfo());
			readValue.setMemberHostPlanId(riskAdjGapReq.getMemberHostPlanId());
			readValue.setRoutetoHostPlanId(riskAdjGapReq.getRoutetoHostPlanId());
			readValue.setFirstTimeSenttoHostPlanDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
			readValue.setLastMRRProvEngmntReqID(riskAdjGapReq.getLastMRRProvEngmntReqID());
			readValue.setLastMedRecReqRcptDt(riskAdjGapReq.getLastMedRecReqRcptDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServBeginDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
			readValue.getLastMedRecReqServRangeDts().setLastMedRecReqServEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
			readValue.setMemberDOB(riskAdjGapReq.getMemberDOB());
			readValue.setMMIId(riskAdjGapReq.getMMIId());
			readValue.setMemberFullName(riskAdjGapReq.getMemberFullName());
			readValue.setMemberGender(riskAdjGapReq.getMemberGender());
			readValue.getMemberPCP5PartKey().setProvPlanCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
			readValue.getMemberPCP5PartKey().setProductCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
			readValue.getMemberPCP5PartKey().setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
			readValue.getMemberPCP5PartKey().setProvNumSuffix(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
			readValue.getMemberPCP5PartKey().setProvNetwrkLocSeqNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
			readValue.setPresentDiagnoses(riskAdjGapReq.getPresentDiagnoses());
			readValue.setCurrentDiagnosesRndrngProvNPI(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI());
			readValue.setProvCntrctingSts(riskAdjGapReq.getProvCntrctingSts());
			
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				for (RiskAdjGap readValueGap : readValue.getRiskAdjGaps()) {
					if(readValueGap.getGapId() == riskAdjGap.getGapId()){
						//new
						readValueGap.setRiskAdjGapType(riskAdjGap.getRiskAdjGapType());
						readValueGap.setMissingDiagCd(riskAdjGap.getMissingDiagCd());
						readValueGap.setMissingDiagCdDesc(riskAdjGap.getMissingDiagCdDesc());
						readValueGap.setMissingHCCCd(riskAdjGap.getMissingHCCCd());
						readValueGap.setMissingHCCCdDesc(riskAdjGap.getMissingHCCCdDesc());
						readValueGap.setHCCClaimType(riskAdjGap.getHCCClaimType());
						readValueGap.setMissingDiagCdServDt(riskAdjGap.getMissingDiagCdServDt());
						readValueGap.setMissingDiagCdProvNPI(riskAdjGap.getMissingDiagCdProvNPI());
						readValueGap.setGapIdentificationRationale(riskAdjGap.getGapIdentificationRationale());
						readValueGap.setProspRetrospId(riskAdjGap.getProspRetrospId());
						readValueGap.setRequestedAction(riskAdjGap.getRequestedAction());
						readValueGap.setInfoRcvdtocloseGap(riskAdjGap.getInfoRcvdtocloseGap());
						readValueGap.setGapClsrSCCFId(riskAdjGap.getGapClsrSCCFId());
						readValueGap.setClsrSFReceiptDt(riskAdjGap.getClsrSFReceiptDt());
//						readValueGap.setHostPlanGaplvlClsrInd(riskAdjGap.getHostPlanGaplvlClsrInd());
					}
				}
			}
			String writeValueAsString = objectMapper.writeValueAsString(readValue);
			pexReqtJsonDtl.setReqtJson(writeValueAsString);
			pexReqtJsonDtlDAO.saveAndFlush(pexReqtJsonDtl);
		}  catch (JsonParseException ex) {
			LOGGER.error("Error Occuring RiskAdjUtils updatePexReqtJsonDetails JsonParseException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (JsonMappingException ex) {
			LOGGER.error("Error Occuring RiskAdjUtils updatePexReqtJsonDetails JsonMappingException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} catch (IOException ex) {
			LOGGER.error("Error Occuring RiskAdjUtils updatePexReqtJsonDetails IOException :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}
	public void updatePexTableColumns(RiskAdjustmentGapReq riskAdjGapReq,
			List<PexReqtMembQueue> pexReqtMembQueueList) {
		PexReqtMembQueue pexReqtMembQueue;
		pexReqtMembQueue = pexReqtMembQueueList.get(0);
		
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		//new
		pexReqtMembQueue.setCloseGapCnt(new BigDecimal(riskAdjGapReq.getNumofGapClosures()));
		pexReqtMembQueue.setItsSubscrId(riskAdjGapReq.getITSSubscriberId());
		pexReqtMembQueue.setRndrProvTnxmyCd(riskAdjGapReq.getRndrngProvTxnmyCd());
		pexReqtMembQueue.setProvEngmtReqtId(riskAdjGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setHmPlanId(riskAdjGapReq.getHomePlanId());
		pexReqtMembQueue.setBillProvId(riskAdjGapReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(riskAdjGapReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setBillProvNpi(riskAdjGapReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(riskAdjGapReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(riskAdjGapReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(riskAdjGapReq.getBillProvZipCode());
		pexReqtMembQueue.setRndrProvZipCd(riskAdjGapReq.getRndrngProvZipCode());
		pexReqtMembQueue.setSccfId(riskAdjGapReq.getSCCFIds());
		pexReqtMembQueue.setProvEngmtIndc(riskAdjGapReq.getProvEngagementInd());
		pexReqtMembQueue.setRndrProvTaxId(riskAdjGapReq.getRndrngProvTaxId());
		pexReqtMembQueue.setCpbltyIndcCd(riskAdjGapReq.getCapabilityInd());
		
		pexReqtMembQueue.setRoutHstPlnId(riskAdjGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setMembDob(riskAdjGapReq.getMemberDOB());
		pexReqtMembQueue.setPrsntDiag(riskAdjGapReq.getPresentDiagnoses());
		pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI()));
		pexReqtMembQueue.setMembHstPlnId(riskAdjGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(riskAdjGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(riskAdjGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(riskAdjGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setLastMedRecReqtBegDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue.setLastMedRecReqtEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setMmiId(riskAdjGapReq.getMMIId());
		pexReqtMembQueue.setMembFullNm(riskAdjGapReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(riskAdjGapReq.getMemberGender());
		pexReqtMembQueue.setProvPlnCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setProvPartStus(riskAdjGapReq.getProvCntrctingSts());
		pexReqtMembQueue.setAddnlInfo(riskAdjGapReq.getRndrngProvAddlInfo());

		updateGaps(pexReqtMembQueue, riskAdjGapReq);
		pexReqtMembQueueDAO.saveAndFlush(pexReqtMembQueue);
	}

	public void updateGaps(PexReqtMembQueue pexReqtMembQueue, RiskAdjustmentGapReq riskAdjGapReq) {
		
		
		if (!riskAdjGapReq.getRiskAdjGaps().isEmpty()) {
			
			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				List<PexMembGapsDtl> gaps = pexMembGapsDtlDAO.findByGapIdAndPexReqtMembQueueSkey(
						new BigDecimal(riskAdjGap.getGapId()), pexReqtMembQueue.getPexReqtMembQueueSkey());
				if (!gaps.isEmpty()) {
					PexMembGapsDtl gap = gaps.get(0);
					gap.setAudUpdtId("SYSTEM");
					gap.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
					gap.setReqtdActn(riskAdjGap.getRequestedAction());
					gap.setHmPlnGapClsIndc(riskAdjGap.getHomePlanGaplvlClsrInd());
					gap.setClsGapInfoRcvd(riskAdjGap.getInfoRcvdtocloseGap());
					gap.setSccfId(riskAdjGap.getGapClsrSCCFId());
					gap.setClsSfDt(riskAdjGap.getClsrSFReceiptDt());
					gap.setHstPlnGapClsIndc(riskAdjGap.getHostPlanGaplvlClsrInd());
					
					gap.setMisProvNpiDiagCd(riskAdjGap.getMissingDiagCdProvNPI());
					gap.setMisDiagCd(riskAdjGap.getMissingDiagCd());
					gap.setMisDiagCdDesc(riskAdjGap.getMissingDiagCdDesc());
					gap.setMisHccCd(String.valueOf(riskAdjGap.getMissingHCCCd()));
					gap.setMisHccCdDesc(riskAdjGap.getMissingHCCCdDesc());
					gap.setHccClmTyp(riskAdjGap.getHCCClaimType());
					gap.setGapIdtfnRtnl(riskAdjGap.getGapIdentificationRationale());
					gap.setMisDiagCdSrvcDt(riskAdjGap.getMissingDiagCdServDt());
					gap.setRskAdjGapCd(riskAdjGap.getRiskAdjGapType());
					//new
					pexMembGapsDtlDAO.saveAndFlush(gap);
					hmPlanClsrIndList.add(gap.getHmPlnGapClsIndc());
					hostPlanClsrIndList.add(gap.getHstPlnGapClsIndc());
				}
			}
			
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList, hostPlanClsrIndList);
		}
		}
		
	
	

	public void updateReqtStusCode(PexReqtMembQueue pexReqtMembQueue, List<String> hmPlanClsrIndList, List<String> hostPlanClsrIndList) {
		boolean areAllGapsClosed = true;
		boolean allhstPlanInd = true;
		String[] clsInd = Constants.CLSR_IND;
		for(String hmPlanClsrInd : hmPlanClsrIndList){
			if(!(Arrays.asList(clsInd).contains(hmPlanClsrInd))){
				areAllGapsClosed = false;
				break;
			}
		}
		if(areAllGapsClosed){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
		Iterator<String> iterator = hostPlanClsrIndList.iterator();
		while (iterator.hasNext()) {
			String hstPlanInd = iterator.next();
			if(null == hstPlanInd || hstPlanInd.isEmpty()){
				allhstPlanInd = false;
				break;
			}
		}
		if(allhstPlanInd){
			pexReqtMembQueue.setReqtStusCd(Constants.PENDING_CLOSURE);
		}
	}

	public PexReqtMembQueue setJsonPojoToEntityClass(RiskAdjustmentGapReq riskAdjGapReq) throws Exception {
		PexReqtMembQueue pexReqtMembQueue = new PexReqtMembQueue();
		setPexReqtMembQueueData(riskAdjGapReq, pexReqtMembQueue);
		setPexMembGapDetails(riskAdjGapReq, pexReqtMembQueue);
		setPexReqtJsonDetails(riskAdjGapReq, pexReqtMembQueue);
		return pexReqtMembQueue;
	}

	public void setPexReqtMembQueueData(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws Exception {

		pexReqtMembQueue.setAudInsrtId("SYSTEM");
		pexReqtMembQueue.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setAudUpdtId("SYSTEM");
		pexReqtMembQueue.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtMembQueue.setProvEngmtReqtId(riskAdjGapReq.getProvEngmntReqId());
		pexReqtMembQueue.setCpbltyIndcTyp("CPBLTY_INDC");
		pexReqtMembQueue.setCpbltyIndcCd(riskAdjGapReq.getCapabilityInd());
		pexReqtMembQueue.setHmPlanId(riskAdjGapReq.getHomePlanId());
		pexReqtMembQueue.setMembHstPlnId(riskAdjGapReq.getMemberHostPlanId());
		pexReqtMembQueue.setRoutHstPlnId(riskAdjGapReq.getRoutetoHostPlanId());
		pexReqtMembQueue.setIntlHstPlnDt(riskAdjGapReq.getFirstTimeSenttoHostPlanDt());
		pexReqtMembQueue.setLastMrrProvEngmtRetId(riskAdjGapReq.getLastMRRProvEngmntReqID());
		pexReqtMembQueue.setLastMedRecReqtDt(riskAdjGapReq.getLastMedRecReqRcptDt());
		pexReqtMembQueue.setItsSubscrId(riskAdjGapReq.getITSSubscriberId());
		pexReqtMembQueue.setMembDob(riskAdjGapReq.getMemberDOB());
		pexReqtMembQueue.setMmiId(riskAdjGapReq.getMMIId());
		pexReqtMembQueue.setMembFullNm(riskAdjGapReq.getMemberFullName());
		pexReqtMembQueue.setMembGndr(riskAdjGapReq.getMemberGender());
		pexReqtMembQueue.setCloseGapCnt(new BigDecimal(riskAdjGapReq.getNumofGapClosures()));
		pexReqtMembQueue.setBillProvId(riskAdjGapReq.getBillProvProprietaryId());
		pexReqtMembQueue.setRndrProvId(riskAdjGapReq.getRndrngProvProprietaryId());
		pexReqtMembQueue.setBillProvNpi(riskAdjGapReq.getBillProvNPI());
		pexReqtMembQueue.setRndrProvNpi(riskAdjGapReq.getRndrngProvNPI());
		pexReqtMembQueue.setRndrProvHstPlnId(riskAdjGapReq.getRndrngProvHostPlanId());
		pexReqtMembQueue.setBillProvZipCd(riskAdjGapReq.getBillProvZipCode());
		pexReqtMembQueue.setRndrProvZipCd(riskAdjGapReq.getRndrngProvZipCode());
		pexReqtMembQueue.setSccfId(riskAdjGapReq.getSCCFIds());
		pexReqtMembQueue.setPrsntDiag(riskAdjGapReq.getPresentDiagnoses());
		pexReqtMembQueue.setRndrProvCurrDiag(String.valueOf(riskAdjGapReq.getCurrentDiagnosesRndrngProvNPI()));

		pexReqtMembQueue.setProvEngmtIndc(riskAdjGapReq.getProvEngagementInd());
		pexReqtMembQueue.setProvPartStus(riskAdjGapReq.getProvCntrctingSts());
		pexReqtMembQueue
		.setLastMedRecReqtBegDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServBeginDt());
		pexReqtMembQueue
		.setLastMedRecReqtEndDt(riskAdjGapReq.getLastMedRecReqServRangeDts().getLastMedRecReqServEndDt());
		pexReqtMembQueue.setProvPlnCd(riskAdjGapReq.getMemberPCP5PartKey().getProvPlanCd());
		pexReqtMembQueue.setProvProdCd(riskAdjGapReq.getMemberPCP5PartKey().getProductCd());
		pexReqtMembQueue.setProvNum(riskAdjGapReq.getMemberPCP5PartKey().getProvNum());
		pexReqtMembQueue.setProvSufx(riskAdjGapReq.getMemberPCP5PartKey().getProvNumSuffix());
		pexReqtMembQueue.setProvNtwrkLoc(riskAdjGapReq.getMemberPCP5PartKey().getProvNetwrkLocSeqNum());
		pexReqtMembQueue.setReqtStusCd(Constants.OPEN);
		pexReqtMembQueue.setAddnlInfo(riskAdjGapReq.getRndrngProvAddlInfo());
		pexReqtMembQueue.setRndrProvTaxId(riskAdjGapReq.getRndrngProvTaxId());
		pexReqtMembQueue.setRndrProvTnxmyCd(riskAdjGapReq.getRndrngProvTxnmyCd());
		//set default values
		pexReqtMembQueue.setReqtStusTyp("PEX_REQT_STUS_TYP");
		pexReqtMembQueue.setHmPlanClsIndTyp("HM_PLN_GAP_CLS");
		pexReqtMembQueue.setHstPlnClsIndTyp("HST_PLN_CLS_IND");
		pexReqtMembQueue.setMedRecMtchTyp("MED_REC_MTCH_TYP");
		pexReqtMembQueue.setProvPartStusTyp("PROV_PART_STUS");
		pexReqtMembQueue.setProvEngmtIndcTyp("PROV_ENGMT_INDC");

		getProviderSearchDetails(riskAdjGapReq.getRndrngProvProprietaryId(), pexReqtMembQueue);

	}

	public void getProviderSearchDetails(String rndrngProvPropId, PexReqtMembQueue pexReqtMembQueue) throws Exception {
		try {
			ProviderResponse providerResponse = provSearch.getProviderDetails(rndrngProvPropId);
			if (providerResponse != null) {
				boolean isStatusCheck = false;
				for (Provider provider : providerResponse.getProvider()) {
					if (provider.getPractitioner().size() > 0) {
						for (Practitioner practitioner : provider.getPractitioner()) {
							LOGGER.info("::::::::::ProviderResponse getProviderName ::::::::: "
									+ practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							LOGGER.info("::::::::::ProviderResponse getProviderPhoneNumber::::::::: "
									+ practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrPhonNbr(practitioner.getPractitionerPhoneNumber());
							pexReqtMembQueue.setRndrProvNm(practitioner.getPractitionerFirstName() + " "
									+ practitioner.getPractitionerLastName());
							
							/*if(practitioner.getNetworkDetails().size() > 0) {
								for(NetworkDetails networkDetails : practitioner.getNetworkDetails()) {
									if(Constants.NT_ID_200.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = true;
									} else if(!Constants.NT_ID_200.equals(networkDetails.getNetworkID()) || !Constants.NT_ID_074.equals(networkDetails.getNetworkID())) {
										isStatusCheck = false;
										break;
									}
								}
							} */
							
							/*if(isStatusCheck) {
								pexReqtMembQueue.setProvPartStus("N");
							} else {
								pexReqtMembQueue.setProvPartStus("P");
							}*/
						}
					}
				}
			}

		} catch (Exception ex) {
			LOGGER.error("Error Occuring getProviderDetails service :::::::::: " + ex.getMessage());
			LOGGER.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}
	}


	public void setPexReqtJsonDetails(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue)
			throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		String riskAdjGapReqJson = mapper.writeValueAsString(riskAdjGapReq);

		PexReqtJsonDtl pexReqtJsonDtl = new PexReqtJsonDtl();
		pexReqtJsonDtl.setAudInsrtId("SYSTEM");
		pexReqtJsonDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setAudUpdtId("SYSTEM");
		pexReqtJsonDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
		pexReqtJsonDtl.setReqtJson(riskAdjGapReqJson);
		pexReqtMembQueue.addPexReqtJsonDtl(pexReqtJsonDtl);
	}


	public void setPexMembGapDetails(RiskAdjustmentGapReq riskAdjGapReq, PexReqtMembQueue pexReqtMembQueue) {
		if (!riskAdjGapReq.getRiskAdjGaps().isEmpty()) {
			List<String> hmPlanClsrIndList = new ArrayList<>();
			List<String> hostPlanClsrIndList = new ArrayList<>();
			for (RiskAdjGap riskAdjGap : riskAdjGapReq.getRiskAdjGaps()) {
				PexMembGapsDtl pexMembGapsDtl = new PexMembGapsDtl();

				pexMembGapsDtl.setAudInsrtId("SYSTEM");
				pexMembGapsDtl.setAudInsrtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setAudUpdtId("SYSTEM");
				pexMembGapsDtl.setAudUpdtTmstp(new Timestamp(new Date().getTime()));
				pexMembGapsDtl.setGapId(new BigDecimal(riskAdjGap.getGapId()));
				pexMembGapsDtl.setMisDiagCd(riskAdjGap.getMissingDiagCd());
				pexMembGapsDtl.setMisDiagCdDesc(riskAdjGap.getMissingDiagCdDesc());
				pexMembGapsDtl.setMisHccCd(String.valueOf(riskAdjGap.getMissingHCCCd()));
				pexMembGapsDtl.setMisHccCdDesc(riskAdjGap.getMissingHCCCdDesc());
				pexMembGapsDtl.setMisDiagCdSrvcDt(riskAdjGap.getMissingDiagCdServDt());
				pexMembGapsDtl.setMisProvNpiDiagCd(riskAdjGap.getMissingDiagCdProvNPI());
				pexMembGapsDtl.setGapIdtfnRtnl(riskAdjGap.getGapIdentificationRationale());
				pexMembGapsDtl.setProsRetIdntCd(riskAdjGap.getProspRetrospId());
				pexMembGapsDtl.setReqtdActn(riskAdjGap.getRequestedAction());
				pexMembGapsDtl.setHmPlnGapClsIndc(riskAdjGap.getHomePlanGaplvlClsrInd());
				pexMembGapsDtl.setClsGapInfoRcvd(riskAdjGap.getInfoRcvdtocloseGap());
				pexMembGapsDtl.setSccfId(riskAdjGap.getGapClsrSCCFId());
				pexMembGapsDtl.setClsSfDt(riskAdjGap.getClsrSFReceiptDt());
				pexMembGapsDtl.setHstPlnGapClsIndc(riskAdjGap.getHostPlanGaplvlClsrInd());
				pexMembGapsDtl.setRskAdjGapCd(riskAdjGap.getRiskAdjGapType());
				pexMembGapsDtl.setHccClmCd(riskAdjGap.getHCCClaimType());
				//Set Column default Values
				pexMembGapsDtl.setGapMeasTyp("STAR_MEAS_SCGRE_TYP");
				pexMembGapsDtl.setHmPlnGapClsTyp("HM_PLN_GAP_CLS");
				pexMembGapsDtl.setHstPlnGapClsTyp("HST_PLN_GAP_CLS_INDC");
				pexMembGapsDtl.setRskAdjGapTyp("RSK_ADJ_GAP_TYP");
				pexMembGapsDtl.setHccClmTyp("HCC_CLM_TYP");
				pexMembGapsDtl.setProsRetIdntTyp("PROS_RET_IDNT");

				pexReqtMembQueue.addPexMembGapsDtl(pexMembGapsDtl);
				hmPlanClsrIndList.add(pexMembGapsDtl.getHmPlnGapClsIndc());
				hostPlanClsrIndList.add(pexMembGapsDtl.getHstPlnGapClsIndc());
			}
			
			updateReqtStusCode(pexReqtMembQueue, hmPlanClsrIndList,hostPlanClsrIndList);
		}
	}

	public List<ErrorResponse> risAdjustmentErrorResponse(RiskAdjGapReqObj adjGapReqObj, String filename)
			throws Exception {
		int firstIndx = filename.indexOf("error_report");
		int last = filename.indexOf(".");
		String fileName = filename.substring(firstIndx, last);
		List<ErrorResponse> errorResponses = new ArrayList<>();
		if(adjGapReqObj != null) {
			if(!adjGapReqObj.getRiskAdjustmentGapReq().isEmpty()) {
				for(RiskAdjustmentGapReq adjustmentGapReq : adjGapReqObj.getRiskAdjustmentGapReq()) {
					if(adjustmentGapReq.getErrCd() != null) {
						ErrorResponse errorResponse = new ErrorResponse();
						errorResponse.setCategory(Constants.CATEGORY_IND_RA);
						errorResponse.setFileName(fileName.replace("error_report_", ""));
						errorResponse.setErrorCode(adjustmentGapReq.getErrCd());
						errorResponse.setErrorDesc(adjustmentGapReq.getErrDesc());
						errorResponse.setProviderEngagementID(adjustmentGapReq.getProvEngmntReqId());
						errorResponses.add(errorResponse);
					}
				}
			}
		}
		return errorResponses;
	}
	
}
