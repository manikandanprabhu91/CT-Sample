package com.carefirst.icentric.batch.model;

import java.io.Serializable;
import java.util.Date;

public class JobResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5320492464798397334L;

	Date jobTriggerDate = new Date();
	
	/**
	 * @return jobTriggerDate
	 */
	public Date getJobTriggerDate() {
		return jobTriggerDate;
	}
	
	/**
	 * @param jobTriggerDate
	 * 				the jobTriggerDate to set
	 */
	public void setJobTriggerDate(Date jobTriggerDate) {
		this.jobTriggerDate = jobTriggerDate;
	}
	
}
