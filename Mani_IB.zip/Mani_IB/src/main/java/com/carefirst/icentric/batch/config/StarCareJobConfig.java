/**
 * 
 */
package com.carefirst.icentric.batch.config;

import java.io.File;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.json.JacksonJsonObjectReader;
import org.springframework.batch.item.json.JsonItemReader;
import org.springframework.batch.item.json.builder.JsonItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;
import com.carefirst.icentric.batch.starcare.tasklet.JobCompletionListener;
import com.carefirst.icentric.batch.starcare.tasklet.StarCareItemProcessor;
import com.carefirst.icentric.batch.starcare.tasklet.StarCareItemWriter;
import com.carefirst.icentric.batch.starcare.tasklet.StarCaresItemWriterTasklet;
import com.carefirst.icentric.batch.tasklet.AttachmentFileInsertTasklet;
import com.carefirst.icentric.batch.tasklet.StatusUpdateTasklet;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author aab0490
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class StarCareJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(StarCareJobConfig.class);
	@Autowired
	private JobBuilderFactory screeningJobBuilderfactory;

	@Autowired
	private StepBuilderFactory screeningStepBuilderfactory;

	private int chunkSize = 100;

	@Bean
	public Job starcareBatchJob() {
		return screeningJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB StarCare").incrementer(new RunIdIncrementer())
				.start(starCareGapWriter()).next(internalStatusUpdate()).listener(jobcompletionListener()).build();
	}

	@Bean
	public Job starcareAttachmentBatchJob() {
		return screeningJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB StarCare").incrementer(new RunIdIncrementer())
				.start(insertAttachmentFile()).listener(jobcompletionListener()).build();
	}
	
	@Bean
	public JobExecutionListener jobcompletionListener() {
		return new JobCompletionListener();
	}

	@Bean
	public Step starCareGapWriter() {
		LOGGER.info("insertData - step1() start/end");
		return screeningStepBuilderfactory.get("step1").tasklet(starCareGapTasklet()).build();
	}
	
	@Bean
	public StarCaresItemWriterTasklet starCareGapTasklet() {
		StarCaresItemWriterTasklet tasklet = new StarCaresItemWriterTasklet();
		return tasklet;
	}

	
	
//	@Bean
//	public Step readStarCareData() {
//		LOGGER.info("readData - step1() start/end");
//
//		return screeningStepBuilderfactory.get("step1").<StarsCareGapReq, StarsCareGapReq>chunk(chunkSize)
//				.reader(jsonItemReader(null)).processor(starsCareGapReqItemProcessor()).writer(starsCareGapReqWriter())
//				.build();
//	}
	
//	@Bean
//	public ItemWriter<StarsCareGapReq> starsCareGapReqWriter() {
//		return new StarCareItemWriter();
//	}

//	@Bean
//	@StepScope
//	public ItemProcessor<StarsCareGapReq, StarsCareGapReq> starsCareGapReqItemProcessor() {
//		return new StarCareItemProcessor();
//	}

	@Bean
	public Step insertAttachmentFile() {
		LOGGER.info("insertData - step1() start/end");
		return screeningStepBuilderfactory.get("step1").tasklet(insertAttachmentFileInsertTasklet()).build();
	}
	
	@Bean
	public AttachmentFileInsertTasklet insertAttachmentFileInsertTasklet() {
		AttachmentFileInsertTasklet tasklet = new AttachmentFileInsertTasklet();
		return tasklet;
	}
	
	@Bean
	public Step internalStatusUpdate() {
		LOGGER.info("insertData - step1() start/end");
		return screeningStepBuilderfactory.get("step1").tasklet(internalStatusUpdateTasklet()).build();
	}
	
	@Bean
	public StatusUpdateTasklet internalStatusUpdateTasklet() {
		StatusUpdateTasklet tasklet = new StatusUpdateTasklet();
		return tasklet;
	}
	
	
	
//	@Bean
//	@StepScope
//	public JsonItemReader<StarsCareGapReq> jsonItemReader(@Value("#{jobParameters['starcareFileName']}") String file) {
//
//		ObjectMapper objectMapper = new ObjectMapper();
//		// configure the objectMapper as required
//		JacksonJsonObjectReader<StarsCareGapReq> jsonObjectReader = new JacksonJsonObjectReader<>(
//				StarsCareGapReq.class);
//		jsonObjectReader.setMapper(objectMapper);
//
//		return new JsonItemReaderBuilder<StarsCareGapReq>().jsonObjectReader(jsonObjectReader)
//				.resource(new FileSystemResource(new File(file.trim()))).name("starCareJsonItemReader").build();
//	}

}
