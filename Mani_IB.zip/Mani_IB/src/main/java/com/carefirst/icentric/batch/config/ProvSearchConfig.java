package com.carefirst.icentric.batch.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties("provsearch")
public class ProvSearchConfig {
	
	private String endPoint;
	private String wsdlUrl;
	private String vaultQuery;
	private int timeout;
	
	/**
	 * @return the endPoint
	 */
	public String getEndPoint() {
		return endPoint;
	}
	/**
	 * @param endPoint the endPoint to set
	 */
	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}
	/**
	 * @return the wsdlUrl
	 */
	public String getWsdlUrl() {
		return wsdlUrl;
	}
	/**
	 * @param wsdlUrl the wsdlUrl to set
	 */
	public void setWsdlUrl(String wsdlUrl) {
		this.wsdlUrl = wsdlUrl;
	}
	/**
	 * @return the vaultQuery
	 */
	public String getVaultQuery() {
		return vaultQuery;
	}
	/**
	 * @param vaultQuery the vaultQuery to set
	 */
	public void setVaultQuery(String vaultQuery) {
		this.vaultQuery = vaultQuery;
	}
	/**
	 * @return the timeout
	 */
	public int getTimeout() {
		return timeout;
	}
	/**
	 * @param timeout the timeout to set
	 */
	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}
	


}
