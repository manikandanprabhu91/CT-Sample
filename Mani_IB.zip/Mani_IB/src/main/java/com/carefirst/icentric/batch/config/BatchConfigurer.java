package com.carefirst.icentric.batch.config;


import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.stereotype.Component;

@Component
public class BatchConfigurer extends DefaultBatchConfigurer {
	
	//added to solve hdb meta db issue
}