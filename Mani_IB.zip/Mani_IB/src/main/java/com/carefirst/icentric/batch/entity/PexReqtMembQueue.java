package com.carefirst.icentric.batch.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;


/**
 * The persistent class for the PEX_REQT_MEMB_QUEUE database table.
 * 
 */
@Entity
@Table(name="PEX_REQT_MEMB_QUEUE")
@NamedQuery(name="PexReqtMembQueue.findAll", query="SELECT p FROM PexReqtMembQueue p")
public class PexReqtMembQueue implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PEX_REQT_MEMB_QUEUE_PEXREQTMEMBQUEUESKEY_GENERATOR", sequenceName="PEX_REQT_MEMB_QUEUE_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PEX_REQT_MEMB_QUEUE_PEXREQTMEMBQUEUESKEY_GENERATOR")
	@Column(name="PEX_REQT_MEMB_QUEUE_SKEY")
	private long pexReqtMembQueueSkey;

	@Column(name="AUD_INSRT_ID")
	private String audInsrtId;

	@Column(name="AUD_INSRT_TMSTP")
	private Timestamp audInsrtTmstp;

	@Column(name="AUD_UPDT_ID")
	private String audUpdtId;

	@Column(name="AUD_UPDT_TMSTP")
	private Timestamp audUpdtTmstp;

	@Column(name="BILL_PROV_ID")
	private String billProvId;

	@Column(name="BILL_PROV_NPI")
	private String billProvNpi;

	@Column(name="BILL_PROV_ZIP_CD")
	private String billProvZipCd;

	@Column(name="CLOSE_GAP_CNT")
	private BigDecimal closeGapCnt;

	@Column(name="CPBLTY_INDC_CD")
	private String cpbltyIndcCd;

	@Column(name="CPBLTY_INDC_TYP")
	private String cpbltyIndcTyp;

	@Column(name="HM_PLAN_ID")
	private String hmPlanId;
	
	@Column(name="HM_PLN_CLS_IND_TYP")
	private String hmPlanClsIndTyp;
	
	@Column(name="HM_PLN_CLS_IND")
	private String hmPlanClsInd;

	@Column(name="HST_PLN_CLS_IND")
	private String hstPlnClsInd;

	@Column(name="HST_PLN_CLS_IND_TYP")
	private String hstPlnClsIndTyp;

	@Column(name="INTL_HST_PLN_DT")
	private String intlHstPlnDt;

	@Column(name="ITS_SUBSCR_ID")
	private String itsSubscrId;

	@Column(name="LAST_MED_REC_REQT_BEG_DT")
	private String lastMedRecReqtBegDt;

	@Column(name="LAST_MED_REC_REQT_DT")
	private String lastMedRecReqtDt;

	@Column(name="LAST_MED_REC_REQT_END_DT")
	private String lastMedRecReqtEndDt;

	@Column(name="LAST_MRR_PROV_ENGMT_RET_ID")
	private String lastMrrProvEngmtRetId;

	@Column(name="MED_REC_MTCH_INDC")
	private String medRecMtchIndc;

	@Column(name="MED_REC_MTCH_TYP")
	private String medRecMtchTyp;

	@Column(name="MED_REC_TYP_CD")
	private String medRecTypCd;

	@Column(name="MEMB_DOB")
	private String membDob;

	@Column(name="MEMB_FRST_NM")
	private String membFrstNm;

	@Column(name="MEMB_FULL_NM")
	private String membFullNm;

	@Column(name="MEMB_GNDR")
	private String membGndr;

	@Column(name="MEMB_HST_PLN_ID")
	private String membHstPlnId;

	@Column(name="MEMB_LAST_NM")
	private String membLastNm;

	@Column(name="MMI_ID")
	private String mmiId;

	@Column(name="PREV_GAP_CLS_PROV")
	private String prevGapClsProv;

	@Column(name="PROV_ENGMT_INDC")
	private String provEngmtIndc;

	@Column(name="PROV_ENGMT_INDC_TYP")
	private String provEngmtIndcTyp;

	@Column(name="PROV_ENGMT_REQT_ID")
	private String provEngmtReqtId;

	@Column(name="PROV_NTWRK_LOC")
	private String provNtwrkLoc;

	@Column(name="PROV_NUM")
	private String provNum;

	@Column(name="PROV_PART_STUS")
	private String provPartStus;

	@Column(name="PROV_PART_STUS_TYP")
	private String provPartStusTyp;

	@Column(name="PROV_PLN_CD")
	private String provPlnCd;

	@Column(name="PROV_PROD_CD")
	private String provProdCd;

	@Column(name="PROV_SUFX")
	private String provSufx;

	@Column(name="PRSNT_DIAG")
	private String prsntDiag;

	@Column(name="REQT_STUS_CD")
	private String reqtStusCd;

	@Column(name="REQT_STUS_TYP")
	private String reqtStusTyp;

	@Column(name="RNDR_PROV_CURR_DIAG")
	private String rndrProvCurrDiag;

	@Column(name="RNDR_PROV_HST_PLN_ID")
	private String rndrProvHstPlnId;

	@Column(name="RNDR_PROV_ID")
	private String rndrProvId;

	@Column(name="RNDR_PROV_NPI")
	private String rndrProvNpi;

	@Column(name="RNDR_PROV_TAX_ID")
	private String rndrProvTaxId;

	@Column(name="RNDR_PROV_ZIP_CD")
	private String rndrProvZipCd;

	@Column(name="ROUT_HST_PLN_ID")
	private String routHstPlnId;

	@Column(name="SCCF_ID")
	private String sccfId;

	@Column(name="SERVC_BEG_DT")
	private String servcBegDt;

	@Column(name="SERVC_END_DT")
	private String servcEndDt;
	

	@Column(name="BILL_PROV_NM")
	private String billProvNm;
	
	@Column(name="RNDR_PROV_NM")
	private String rndrProvNm;
	
	@Column(name="RNDR_PROV_SPCLTY")
	private String rndrProvSpclty;
	
	@Column(name="RNDR_PHON_NBR")
	private String rndrPhonNbr;
	
	@Column(name="HEDIS_MEASMT_TYP")
	private String hedisMeasmtTyp;	

//	@Column(name="PROV_TAX_ID")
//	private String provTaxId;
	
	@Column(name="RNDR_ADDNL_INFO")
	private String addnlInfo;
	
	@Column(name="SERVC_DT")
	private String servcDt;
	
	@Column(name="RNDR_PROV_TXNMY_CD")
	private String rndrProvTnxmyCd;
	 
	
	//bi-directional many-to-one association to PexMembGapsDtl
	@OneToMany(cascade = CascadeType.ALL, mappedBy="pexReqtMembQueue")
	private List<PexMembGapsDtl> pexMembGapsDtls = new ArrayList<>();

	//bi-directional many-to-one association to PexReqtAtchDtl
	@OneToMany(cascade = CascadeType.ALL, mappedBy="pexReqtMembQueue")
	private List<PexReqtAtchDtl> pexReqtAtchDtls = new ArrayList<>();

	//bi-directional many-to-one association to PexReqtJsonDtl
	@OneToMany(cascade = CascadeType.ALL, mappedBy="pexReqtMembQueue")
	private List<PexReqtJsonDtl> pexReqtJsonDtls = new ArrayList<>();
	
	@Column(name="PCMH_INDC")
	private long pcmhIndicator;

	public PexReqtMembQueue() {
	}

	public long getPexReqtMembQueueSkey() {
		return this.pexReqtMembQueueSkey;
	}

	public void setPexReqtMembQueueSkey(long pexReqtMembQueueSkey) {
		this.pexReqtMembQueueSkey = pexReqtMembQueueSkey;
	}

	public String getAudInsrtId() {
		return this.audInsrtId;
	}

	public void setAudInsrtId(String audInsrtId) {
		this.audInsrtId = audInsrtId;
	}

	public Timestamp getAudInsrtTmstp() {
		return this.audInsrtTmstp;
	}

	public void setAudInsrtTmstp(Timestamp audInsrtTmstp) {
		this.audInsrtTmstp = audInsrtTmstp;
	}

	public String getAudUpdtId() {
		return this.audUpdtId;
	}

	public void setAudUpdtId(String audUpdtId) {
		this.audUpdtId = audUpdtId;
	}

	public Timestamp getAudUpdtTmstp() {
		return this.audUpdtTmstp;
	}

	public void setAudUpdtTmstp(Timestamp audUpdtTmstp) {
		this.audUpdtTmstp = audUpdtTmstp;
	}

	public String getBillProvId() {
		return this.billProvId;
	}

	public void setBillProvId(String billProvId) {
		this.billProvId = billProvId;
	}

	public String getBillProvNpi() {
		return this.billProvNpi;
	}

	public void setBillProvNpi(String billProvNpi) {
		this.billProvNpi = billProvNpi;
	}

	public String getBillProvZipCd() {
		return this.billProvZipCd;
	}

	public void setBillProvZipCd(String billProvZipCd) {
		this.billProvZipCd = billProvZipCd;
	}

	public BigDecimal getCloseGapCnt() {
		return this.closeGapCnt;
	}

	public void setCloseGapCnt(BigDecimal closeGapCnt) {
		this.closeGapCnt = closeGapCnt;
	}

	public String getCpbltyIndcCd() {
		return this.cpbltyIndcCd;
	}

	public void setCpbltyIndcCd(String cpbltyIndcCd) {
		this.cpbltyIndcCd = cpbltyIndcCd;
	}

	public String getCpbltyIndcTyp() {
		return this.cpbltyIndcTyp;
	}

	public void setCpbltyIndcTyp(String cpbltyIndcTyp) {
		this.cpbltyIndcTyp = cpbltyIndcTyp;
	}

	public String getHmPlanId() {
		return this.hmPlanId;
	}

	public void setHmPlanId(String hmPlanId) {
		this.hmPlanId = hmPlanId;
	}

	public String getHstPlnClsInd() {
		return this.hstPlnClsInd;
	}

	public void setHstPlnClsInd(String hstPlnClsInd) {
		this.hstPlnClsInd = hstPlnClsInd;
	}

	public String getHstPlnClsIndTyp() {
		return this.hstPlnClsIndTyp;
	}

	public void setHstPlnClsIndTyp(String hstPlnClsIndTyp) {
		this.hstPlnClsIndTyp = hstPlnClsIndTyp;
	}

	public String getIntlHstPlnDt() {
		return this.intlHstPlnDt;
	}

	public void setIntlHstPlnDt(String intlHstPlnDt) {
		this.intlHstPlnDt = intlHstPlnDt;
	}

	public String getItsSubscrId() {
		return this.itsSubscrId;
	}

	public void setItsSubscrId(String itsSubscrId) {
		this.itsSubscrId = itsSubscrId;
	}

	public String getLastMedRecReqtBegDt() {
		return this.lastMedRecReqtBegDt;
	}

	public void setLastMedRecReqtBegDt(String lastMedRecReqtBegDt) {
		this.lastMedRecReqtBegDt = lastMedRecReqtBegDt;
	}

	public String getLastMedRecReqtDt() {
		return this.lastMedRecReqtDt;
	}

	public void setLastMedRecReqtDt(String lastMedRecReqtDt) {
		this.lastMedRecReqtDt = lastMedRecReqtDt;
	}

	public String getLastMedRecReqtEndDt() {
		return this.lastMedRecReqtEndDt;
	}

	public void setLastMedRecReqtEndDt(String lastMedRecReqtEndDt) {
		this.lastMedRecReqtEndDt = lastMedRecReqtEndDt;
	}

	public String getLastMrrProvEngmtRetId() {
		return this.lastMrrProvEngmtRetId;
	}

	public void setLastMrrProvEngmtRetId(String lastMrrProvEngmtRetId) {
		this.lastMrrProvEngmtRetId = lastMrrProvEngmtRetId;
	}

	public String getMedRecMtchIndc() {
		return this.medRecMtchIndc;
	}

	public void setMedRecMtchIndc(String medRecMtchIndc) {
		this.medRecMtchIndc = medRecMtchIndc;
	}

	public String getMedRecMtchTyp() {
		return this.medRecMtchTyp;
	}

	public void setMedRecMtchTyp(String medRecMtchTyp) {
		this.medRecMtchTyp = medRecMtchTyp;
	}

	public String getMedRecTypCd() {
		return this.medRecTypCd;
	}

	public void setMedRecTypCd(String medRecTypCd) {
		this.medRecTypCd = medRecTypCd;
	}

	public String getMembDob() {
		return this.membDob;
	}

	public void setMembDob(String membDob) {
		this.membDob = membDob;
	}

	public String getMembFrstNm() {
		return this.membFrstNm;
	}

	public void setMembFrstNm(String membFrstNm) {
		this.membFrstNm = membFrstNm;
	}

	public String getMembFullNm() {
		return this.membFullNm;
	}

	public void setMembFullNm(String membFullNm) {
		this.membFullNm = membFullNm;
	}

	public String getMembGndr() {
		return this.membGndr;
	}

	public void setMembGndr(String membGndr) {
		this.membGndr = membGndr;
	}

	public String getMembHstPlnId() {
		return this.membHstPlnId;
	}

	public void setMembHstPlnId(String membHstPlnId) {
		this.membHstPlnId = membHstPlnId;
	}

	public String getMembLastNm() {
		return this.membLastNm;
	}

	public void setMembLastNm(String membLastNm) {
		this.membLastNm = membLastNm;
	}

	public String getMmiId() {
		return this.mmiId;
	}

	public void setMmiId(String mmiId) {
		this.mmiId = mmiId;
	}

	public String getPrevGapClsProv() {
		return this.prevGapClsProv;
	}

	public void setPrevGapClsProv(String prevGapClsProv) {
		this.prevGapClsProv = prevGapClsProv;
	}

	public String getProvEngmtIndc() {
		return this.provEngmtIndc;
	}

	public void setProvEngmtIndc(String provEngmtIndc) {
		this.provEngmtIndc = provEngmtIndc;
	}

	public String getProvEngmtIndcTyp() {
		return this.provEngmtIndcTyp;
	}

	public void setProvEngmtIndcTyp(String provEngmtIndcTyp) {
		this.provEngmtIndcTyp = provEngmtIndcTyp;
	}

	public String getProvEngmtReqtId() {
		return this.provEngmtReqtId;
	}

	public void setProvEngmtReqtId(String provEngmtReqtId) {
		this.provEngmtReqtId = provEngmtReqtId;
	}

	public String getProvNtwrkLoc() {
		return this.provNtwrkLoc;
	}

	public void setProvNtwrkLoc(String provNtwrkLoc) {
		this.provNtwrkLoc = provNtwrkLoc;
	}

	public String getProvNum() {
		return this.provNum;
	}

	public void setProvNum(String provNum) {
		this.provNum = provNum;
	}

	public String getProvPartStus() {
		return this.provPartStus;
	}

	public void setProvPartStus(String provPartStus) {
		this.provPartStus = provPartStus;
	}

	public String getProvPartStusTyp() {
		return this.provPartStusTyp;
	}

	public void setProvPartStusTyp(String provPartStusTyp) {
		this.provPartStusTyp = provPartStusTyp;
	}

	public String getProvPlnCd() {
		return this.provPlnCd;
	}

	public void setProvPlnCd(String provPlnCd) {
		this.provPlnCd = provPlnCd;
	}

	public String getProvProdCd() {
		return this.provProdCd;
	}

	public void setProvProdCd(String provProdCd) {
		this.provProdCd = provProdCd;
	}

	public String getProvSufx() {
		return this.provSufx;
	}

	public void setProvSufx(String provSufx) {
		this.provSufx = provSufx;
	}

	public String getPrsntDiag() {
		return this.prsntDiag;
	}

	public void setPrsntDiag(String prsntDiag) {
		this.prsntDiag = prsntDiag;
	}

	public String getReqtStusCd() {
		return this.reqtStusCd;
	}

	public void setReqtStusCd(String reqtStusCd) {
		this.reqtStusCd = reqtStusCd;
	}

	public String getReqtStusTyp() {
		return this.reqtStusTyp;
	}

	public void setReqtStusTyp(String reqtStusTyp) {
		this.reqtStusTyp = reqtStusTyp;
	}

	public String getRndrProvCurrDiag() {
		return this.rndrProvCurrDiag;
	}

	public void setRndrProvCurrDiag(String rndrProvCurrDiag) {
		this.rndrProvCurrDiag = rndrProvCurrDiag;
	}

	public String getRndrProvHstPlnId() {
		return this.rndrProvHstPlnId;
	}

	public void setRndrProvHstPlnId(String rndrProvHstPlnId) {
		this.rndrProvHstPlnId = rndrProvHstPlnId;
	}

	public String getRndrProvId() {
		return this.rndrProvId;
	}

	public void setRndrProvId(String rndrProvId) {
		this.rndrProvId = rndrProvId;
	}

	public String getRndrProvNpi() {
		return this.rndrProvNpi;
	}

	public void setRndrProvNpi(String rndrProvNpi) {
		this.rndrProvNpi = rndrProvNpi;
	}

	public String getRndrProvTaxId() {
		return this.rndrProvTaxId;
	}

	public void setRndrProvTaxId(String rndrProvTaxId) {
		this.rndrProvTaxId = rndrProvTaxId;
	}

	public String getRndrProvZipCd() {
		return this.rndrProvZipCd;
	}

	public void setRndrProvZipCd(String rndrProvZipCd) {
		this.rndrProvZipCd = rndrProvZipCd;
	}

	public String getRoutHstPlnId() {
		return this.routHstPlnId;
	}

	public void setRoutHstPlnId(String routHstPlnId) {
		this.routHstPlnId = routHstPlnId;
	}

	public String getSccfId() {
		return this.sccfId;
	}

	public void setSccfId(String sccfId) {
		this.sccfId = sccfId;
	}

	public String getServcBegDt() {
		return this.servcBegDt;
	}

	public void setServcBegDt(String servcBegDt) {
		this.servcBegDt = servcBegDt;
	}

	public String getServcEndDt() {
		return this.servcEndDt;
	}

	public void setServcEndDt(String servcEndDt) {
		this.servcEndDt = servcEndDt;
	}

	public List<PexMembGapsDtl> getPexMembGapsDtls() {
		return this.pexMembGapsDtls;
	}

	public void setPexMembGapsDtls(List<PexMembGapsDtl> pexMembGapsDtls) {
		this.pexMembGapsDtls = pexMembGapsDtls;
	}

	public PexMembGapsDtl addPexMembGapsDtl(PexMembGapsDtl pexMembGapsDtl) {
		getPexMembGapsDtls().add(pexMembGapsDtl);
		pexMembGapsDtl.setPexReqtMembQueue(this);

		return pexMembGapsDtl;
	}

	public PexMembGapsDtl removePexMembGapsDtl(PexMembGapsDtl pexMembGapsDtl) {
		getPexMembGapsDtls().remove(pexMembGapsDtl);
		pexMembGapsDtl.setPexReqtMembQueue(null);

		return pexMembGapsDtl;
	}

	public List<PexReqtAtchDtl> getPexReqtAtchDtls() {
		return this.pexReqtAtchDtls;
	}

	public void setPexReqtAtchDtls(List<PexReqtAtchDtl> pexReqtAtchDtls) {
		this.pexReqtAtchDtls = pexReqtAtchDtls;
	}

	public PexReqtAtchDtl addPexReqtAtchDtl(PexReqtAtchDtl pexReqtAtchDtl) {
		getPexReqtAtchDtls().add(pexReqtAtchDtl);
		pexReqtAtchDtl.setPexReqtMembQueue(this);

		return pexReqtAtchDtl;
	}

	public PexReqtAtchDtl removePexReqtAtchDtl(PexReqtAtchDtl pexReqtAtchDtl) {
		getPexReqtAtchDtls().remove(pexReqtAtchDtl);
		pexReqtAtchDtl.setPexReqtMembQueue(null);

		return pexReqtAtchDtl;
	}

	public List<PexReqtJsonDtl> getPexReqtJsonDtls() {
		return this.pexReqtJsonDtls;
	}

	public void setPexReqtJsonDtls(List<PexReqtJsonDtl> pexReqtJsonDtls) {
		this.pexReqtJsonDtls = pexReqtJsonDtls;
	}

	public PexReqtJsonDtl addPexReqtJsonDtl(PexReqtJsonDtl pexReqtJsonDtl) {
		getPexReqtJsonDtls().add(pexReqtJsonDtl);
		pexReqtJsonDtl.setPexReqtMembQueue(this);

		return pexReqtJsonDtl;
	}

	public PexReqtJsonDtl removePexReqtJsonDtl(PexReqtJsonDtl pexReqtJsonDtl) {
		getPexReqtJsonDtls().remove(pexReqtJsonDtl);
		pexReqtJsonDtl.setPexReqtMembQueue(null);

		return pexReqtJsonDtl;
	}

	public String getHmPlanClsIndTyp() {
		return hmPlanClsIndTyp;
	}

	public void setHmPlanClsIndTyp(String hmPlanClsIndTyp) {
		this.hmPlanClsIndTyp = hmPlanClsIndTyp;
	}

	public String getHmPlanClsInd() {
		return hmPlanClsInd;
	}

	public void setHmPlanClsInd(String hmPlanClsInd) {
		this.hmPlanClsInd = hmPlanClsInd;
	}

	public String getBillProvNm() {
		return billProvNm;
	}

	public void setBillProvNm(String billProvNm) {
		this.billProvNm = billProvNm;
	}

	public String getRndrProvNm() {
		return rndrProvNm;
	}

	public void setRndrProvNm(String rndrProvNm) {
		this.rndrProvNm = rndrProvNm;
	}

	public String getRndrProvSpclty() {
		return rndrProvSpclty;
	}

	public void setRndrProvSpclty(String rndrProvSpclty) {
		this.rndrProvSpclty = rndrProvSpclty;
	}

	public String getRndrPhonNbr() {
		return rndrPhonNbr;
	}

	public void setRndrPhonNbr(String rndrPhonNbr) {
		this.rndrPhonNbr = rndrPhonNbr;
	}

	public long getPcmhIndicator() {
		return pcmhIndicator;
	}

	public void setPcmhIndicator(long pcmhIndicator) {
		this.pcmhIndicator = pcmhIndicator;
	}

	public String getHedisMeasmtTyp() {
		return hedisMeasmtTyp;
	}

	public void setHedisMeasmtTyp(String hedisMeasmtTyp) {
		this.hedisMeasmtTyp = hedisMeasmtTyp;
	}

//	public String getProvTaxId() {
//		return provTaxId;
//	}
//
//	public void setProvTaxId(String provTaxId) {
//		this.provTaxId = provTaxId;
//	}

	public String getAddnlInfo() {
		return addnlInfo;
	}

	public void setAddnlInfo(String addnlInfo) {
		this.addnlInfo = addnlInfo;
	}

	public String getServcDt() {
		return servcDt;
	}

	public void setServcDt(String servcDt) {
		this.servcDt = servcDt;
	}

	public String getRndrProvTnxmyCd() {
		return rndrProvTnxmyCd;
	}

	public void setRndrProvTnxmyCd(String rndrProvTnxmyCd) {
		this.rndrProvTnxmyCd = rndrProvTnxmyCd;
	}

}