package com.carefirst.icentric.batch.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.carefirst.icentric.batch.entity.PexReqtMembQueue;

@Repository
public interface PexReqtMembQueueDAO extends JpaRepository<PexReqtMembQueue, Long>{

	public List<PexReqtMembQueue> findByProvEngmtReqtId(String provEngmtReqtId);

	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Query("SELECT p FROM PexReqtMembQueue p where p.reqtStusCd = :internalStatus and p.cpbltyIndcCd = :cpbltyIndcCd")
	public List<PexReqtMembQueue> findByReqtStusCdAndAudUpdtTmstp(@Param("internalStatus") String internalStatus, 
			@Param("cpbltyIndcCd") String cpbltyIndcCd);

	@Transactional
	@Modifying
	@Query(value = "UPDATE PCMH_RSTR.PEX_REQT_MEMB_QUEUE PRMQ SET HST_PLN_CLS_IND ='ANC',REQT_STUS_CD='PEX_REQT_STUS03',"
			+   " AUD_UPDT_TMSTP = CURRENT_TIMESTAMP, AUD_UPDT_ID = 'SYSTEM' WHERE  HST_PLN_CLS_IND IS NULL AND PRMQ.CPBLTY_INDC_CD = 'MR'"
			+ " AND 1 ="
			+ " CASE"
			+ " WHEN TRUNC (SYSDATE)"
			+ "  - TO_DATE ("
			+ " INTL_HST_PLN_DT,"
			+ " 'YYYYMMDD') > 180"
			+ " THEN"
			+ " 1"
			+ " ELSE"
			+ " 0"
			+ " END", nativeQuery=true)
	int updateHstPlanIndMRcGreaterThan180Days();

	@Transactional
	@Modifying
	@Query(value = "UPDATE PCMH_RSTR.PEX_REQT_MEMB_QUEUE PRMQ SET PRMQ.REQT_STUS_CD =  'PEX_REQT_STUS03',PRMQ.AUD_UPDT_TMSTP = CURRENT_TIMESTAMP, PRMQ.AUD_UPDT_ID = 'SYSTEM' WHERE PRMQ.CPBLTY_INDC_CD IN ('RA','SC')"
			+ " AND PRMQ.PEX_REQT_MEMB_QUEUE_SKEY IN (SELECT PMGD.PEX_REQT_MEMB_QUEUE_SKEY FROM PCMH_RSTR.PEX_MEMB_GAPS_DTLS PMGD WHERE HST_PLN_GAP_CLS_INDC = 'ANC' AND TRUNC(AUD_UPDT_TMSTP) = TRUNC(SYSDATE))", nativeQuery=true)
	int updateStatusForScRa();

	@Query(value="SELECT REFNC_CD_DESC FROM cp_ph2.refnc_data_lkup WHERE REFNC_LKUP_TYP = 'PEX_ERR_CD' AND REFNC_LKUP_CD=?1",nativeQuery=true)
	String getErrorDescription(String errorCode);

	@Query(value="select reqt_stus_cd, cpblty_indc_cd, count(*) from pcmh_rstr.PEX_REQT_MEMB_QUEUE where aud_insrt_tmstp > ?1 group by reqt_stus_cd, cpblty_indc_cd order by cpblty_indc_cd, reqt_stus_cd",nativeQuery=true)
	List<Object[]> getPendingStatusList(String date);

	@Query(value="SELECT REFNC_CD_DESC FROM CP_PH2.REFNC_DATA_LKUP LKUP WHERE REFNC_LKUP_CD= ?1",nativeQuery=true)
	String findRequestType(String code);

	@Query(value="SELECT MEM.PROV_ENGMT_REQT_ID,MEM.RNDR_PROV_ID,NVL(MEM.RNDR_PROV_NPI,' ') RNDR_PROV_NPI,' ' RNDR_PROV_NM,NVL(MEM.MMI_ID,' ') MEMBER_ID,NVL(MEM.SERVC_BEG_DT,' ') SERVC_BEG_DT,NVL(MEM.SERVC_END_DT,' ') SERVC_END_DT,NVL(UPPER(LTRIM(RTRIM(REPLACE(REPLACE(MEM.MEMB_FULL_NM,',',' '),'.',' ')))),' ') MEMB_FULL_NM,NVL(MEM.MEMB_DOB, ' ') MEMB_DOB,' ' GAP_MEAS_DESC,MEM.CPBLTY_INDC_CD,LKUP.REFNC_CD_DESC FROM PCMH_RSTR.PEX_REQT_MEMB_QUEUE MEM INNER JOIN CP_PH2.REFNC_DATA_LKUP LKUP ON LKUP.REFNC_LKUP_TYP=MEM.REQT_STUS_TYP AND LKUP.REFNC_LKUP_CD=MEM.REQT_STUS_CD WHERE UPPER(LKUP.REFNC_CD_DESC)='OPEN' AND MEM.CPBLTY_INDC_CD='MR' AND NVL(MEM.PROV_ENGMT_INDC,'NE')='NE' AND UPPER(NVL(MEM.EXTR_SENT,'N'))='N'", nativeQuery=true)
	List<Object[]> getExtractMRRecords();
	
	@Query(value="SELECT MEM.PROV_ENGMT_REQT_ID,MEM.RNDR_PROV_ID,NVL(MEM.RNDR_PROV_NPI,' ') RNDR_PROV_NPI,' ' RNDR_PROV_NM,NVL(MEM.MMI_ID,' ') MEMBER_ID,NVL(MEM.SERVC_BEG_DT,' ') SERVC_BEG_DT,NVL(MEM.SERVC_END_DT,' ') SERVC_END_DT,NVL(UPPER(LTRIM(RTRIM(REPLACE(REPLACE(MEM.MEMB_FULL_NM,',',' '),'.',' ')))),' ') MEMB_FULL_NM,NVL(MEM.MEMB_DOB, ' ') MEMB_DOB,NVL(LISTAGG(GAPLKUP.REFNC_CD_DESC,';') WITHIN GROUP (ORDER BY GAP.PEX_REQT_MEMB_QUEUE_SKEY),' ') GAP_MEAS_DESC,MEM.CPBLTY_INDC_CD,LKUP.REFNC_CD_DESC FROM PCMH_RSTR.PEX_REQT_MEMB_QUEUE MEM LEFT JOIN PCMH_RSTR.PEX_MEMB_GAPS_DTLS GAP ON MEM.PEX_REQT_MEMB_QUEUE_SKEY=GAP.PEX_REQT_MEMB_QUEUE_SKEY INNER JOIN CP_PH2.REFNC_DATA_LKUP LKUP ON LKUP.REFNC_LKUP_TYP=MEM.REQT_STUS_TYP AND LKUP.REFNC_LKUP_CD=MEM.REQT_STUS_CD LEFT JOIN CP_PH2.REFNC_DATA_LKUP GAPLKUP ON GAPLKUP.REFNC_LKUP_TYP=GAP.GAP_MEAS_TYP AND GAPLKUP.REFNC_LKUP_CD=GAP.GAP_MEAS_CD WHERE UPPER(LKUP.REFNC_CD_DESC)='OPEN' AND MEM.CPBLTY_INDC_CD='SC' AND NVL(MEM.PROV_ENGMT_INDC,'NE')='NE' AND UPPER(NVL(MEM.EXTR_SENT,'N'))='N' GROUP BY NVL(MEM.MMI_ID,' '),NVL(MEM.SERVC_BEG_DT,' '),NVL(MEM.SERVC_END_DT,' '), MEM.PROV_ENGMT_REQT_ID,MEM.RNDR_PROV_ID,NVL(MEM.RNDR_PROV_NPI,' '),NVL(UPPER(LTRIM(RTRIM(REPLACE(REPLACE(MEM.MEMB_FULL_NM,',',' '),'.',' ')))),' '),NVL(MEM.MEMB_DOB, ' '),MEM.CPBLTY_INDC_CD,LKUP.REFNC_CD_DESC", nativeQuery=true)
	List<Object[]> getExtractSCRecords();
	
	@Query(value="SELECT MEM.PROV_ENGMT_REQT_ID,MEM.RNDR_PROV_ID,NVL(MEM.RNDR_PROV_NPI,' ') RNDR_PROV_NPI,' ' RNDR_PROV_NM,NVL(MEM.MMI_ID,' ') MEMBER_ID,NVL(MEM.SERVC_BEG_DT,' ') SERVC_BEG_DT,NVL(MEM.SERVC_END_DT,' ') SERVC_END_DT,NVL(UPPER(LTRIM(RTRIM(REPLACE(REPLACE(MEM.MEMB_FULL_NM,',',' '),'.',' ')))),' ') MEMB_FULL_NM,NVL(MEM.MEMB_DOB, ' ') MEMB_DOB,NVL(LISTAGG(GAP.MIS_DIAG_CD,';') WITHIN GROUP (ORDER BY GAP.PEX_REQT_MEMB_QUEUE_SKEY),' ')  GAP_MEAS_DESC,MEM.CPBLTY_INDC_CD,LKUP.REFNC_CD_DESC FROM PCMH_RSTR.PEX_REQT_MEMB_QUEUE MEM LEFT JOIN PCMH_RSTR.PEX_MEMB_GAPS_DTLS GAP ON MEM.PEX_REQT_MEMB_QUEUE_SKEY=GAP.PEX_REQT_MEMB_QUEUE_SKEY INNER JOIN CP_PH2.REFNC_DATA_LKUP LKUP ON LKUP.REFNC_LKUP_TYP=MEM.REQT_STUS_TYP AND LKUP.REFNC_LKUP_CD=MEM.REQT_STUS_CD WHERE UPPER(LKUP.REFNC_CD_DESC)='OPEN' AND MEM.CPBLTY_INDC_CD='RA' AND NVL(MEM.PROV_ENGMT_INDC,'NE')='NE' AND UPPER(NVL(MEM.EXTR_SENT,'N'))='N' GROUP BY NVL(MEM.MMI_ID,' '),NVL(MEM.SERVC_BEG_DT,' '),NVL(MEM.SERVC_END_DT,' '),MEM.PROV_ENGMT_REQT_ID,MEM.RNDR_PROV_ID,NVL(MEM.RNDR_PROV_NPI,' '),NVL(UPPER(LTRIM(RTRIM(REPLACE(REPLACE(MEM.MEMB_FULL_NM,',',' '),'.',' ')))),' '),NVL(MEM.MEMB_DOB, ' '),MEM.CPBLTY_INDC_CD,LKUP.REFNC_CD_DESC", nativeQuery=true)
	List<Object[]> getExtractRARecords();
	
	@Transactional
	@Modifying
	@Query(value="UPDATE PCMH_RSTR.PEX_REQT_MEMB_QUEUE SET AUD_UPDT_ID='ADHOC',AUD_UPDT_TMSTP=CURRENT_TIMESTAMP,EXTR_SENT='Y' WHERE PROV_ENGMT_REQT_ID = ?1",nativeQuery=true)
	int updateExtractYes(String engagementId);
}
