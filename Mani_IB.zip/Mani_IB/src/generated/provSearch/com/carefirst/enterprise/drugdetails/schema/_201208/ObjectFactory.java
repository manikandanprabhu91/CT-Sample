
package com.carefirst.enterprise.drugdetails.schema._201208;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.enterprise.drugdetails.schema._201208 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DrugCodeTypeIndicator_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugCodeTypeIndicator");
    private final static QName _AuthIndicator_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "authIndicator");
    private final static QName _NextLevelReviewer_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "nextLevelReviewer");
    private final static QName _DrugTierName_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugTierName");
    private final static QName _DosageForm_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "dosageForm");
    private final static QName _Classification_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "classification");
    private final static QName _EffStartDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "effStartDate");
    private final static QName _DrugSkey_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugSkey");
    private final static QName _DrugDosageSKey_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugDosageSKey");
    private final static QName _MedQtyLmtNote_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "medQtyLmtNote");
    private final static QName _Dosage_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "dosage");
    private final static QName _Freq_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "freq");
    private final static QName _DrugDescription_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugDescription");
    private final static QName _DrugTier_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugTier");
    private final static QName _AuthDuration_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "authDuration");
    private final static QName _AuthNextLevelDuration_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "authNextLevelDuration");
    private final static QName _GenTier_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "genTier");
    private final static QName _AutoApprovalInd_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "autoApprovalInd");
    private final static QName _DosageDescription_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "dosageDescription");
    private final static QName _Reviewer_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "reviewer");
    private final static QName _DosageSKey_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "dosageSKey");
    private final static QName _LengthAuth_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "lengthAuth");
    private final static QName _GenericName_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "genericName");
    private final static QName _Strength_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "strength");
    private final static QName _DrugTierType_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugTierType");
    private final static QName _DenialDecisionRoute_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "denialDecisionRoute");
    private final static QName _GcnCode_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "gcnCode");
    private final static QName _ActiveRecordIndicator_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "activeRecordIndicator");
    private final static QName _DosageCLSNSkey_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "dosageCLSNSkey");
    private final static QName _Qty_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "qty");
    private final static QName _DrugName_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugName");
    private final static QName _Name_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "name");
    private final static QName _PriorAuthId_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "priorAuthId");
    private final static QName _AuthId_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "authId");
    private final static QName _GenericTier_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "genericTier");
    private final static QName _ComQtyLmtNote_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "comQtyLmtNote");
    private final static QName _NdcCode_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "ndcCode");
    private final static QName _EffEndDate_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "effEndDate");
    private final static QName _Value_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "value");
    private final static QName _DrugPAQLMapKey_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "drugPAQLMapKey");
    private final static QName _AuthForStrength_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "authForStrength");
    private final static QName _ComMedIndicator_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "comMedIndicator");
    private final static QName _Form_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "form");
    private final static QName _Category_QNAME = new QName("http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", "category");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.enterprise.drugdetails.schema._201208
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link QtyLimitNote }
     * 
     */
    public QtyLimitNote createQtyLimitNote() {
        return new QtyLimitNote();
    }

    /**
     * Create an instance of {@link TypQtyLimitNote }
     * 
     */
    public TypQtyLimitNote createTypQtyLimitNote() {
        return new TypQtyLimitNote();
    }

    /**
     * Create an instance of {@link CoverageIndicator }
     * 
     */
    public CoverageIndicator createCoverageIndicator() {
        return new CoverageIndicator();
    }

    /**
     * Create an instance of {@link TypNameValue }
     * 
     */
    public TypNameValue createTypNameValue() {
        return new TypNameValue();
    }

    /**
     * Create an instance of {@link DrugNameNTier }
     * 
     */
    public DrugNameNTier createDrugNameNTier() {
        return new DrugNameNTier();
    }

    /**
     * Create an instance of {@link TypName }
     * 
     */
    public TypName createTypName() {
        return new TypName();
    }

    /**
     * Create an instance of {@link DrugAssociation }
     * 
     */
    public DrugAssociation createDrugAssociation() {
        return new DrugAssociation();
    }

    /**
     * Create an instance of {@link EffectiveDate }
     * 
     */
    public EffectiveDate createEffectiveDate() {
        return new EffectiveDate();
    }

    /**
     * Create an instance of {@link TypEffectiveDate }
     * 
     */
    public TypEffectiveDate createTypEffectiveDate() {
        return new TypEffectiveDate();
    }

    /**
     * Create an instance of {@link DrugReviewer }
     * 
     */
    public DrugReviewer createDrugReviewer() {
        return new DrugReviewer();
    }

    /**
     * Create an instance of {@link TypReviewer }
     * 
     */
    public TypReviewer createTypReviewer() {
        return new TypReviewer();
    }

    /**
     * Create an instance of {@link DrugDosageInfo }
     * 
     */
    public DrugDosageInfo createDrugDosageInfo() {
        return new DrugDosageInfo();
    }

    /**
     * Create an instance of {@link DrugDetails }
     * 
     */
    public DrugDetails createDrugDetails() {
        return new DrugDetails();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugCodeTypeIndicator")
    public JAXBElement<String> createDrugCodeTypeIndicator(String value) {
        return new JAXBElement<String>(_DrugCodeTypeIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "authIndicator")
    public JAXBElement<String> createAuthIndicator(String value) {
        return new JAXBElement<String>(_AuthIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "nextLevelReviewer")
    public JAXBElement<String> createNextLevelReviewer(String value) {
        return new JAXBElement<String>(_NextLevelReviewer_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugTierName")
    public JAXBElement<String> createDrugTierName(String value) {
        return new JAXBElement<String>(_DrugTierName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "dosageForm")
    public JAXBElement<String> createDosageForm(String value) {
        return new JAXBElement<String>(_DosageForm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "classification")
    public JAXBElement<String> createClassification(String value) {
        return new JAXBElement<String>(_Classification_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "effStartDate")
    public JAXBElement<String> createEffStartDate(String value) {
        return new JAXBElement<String>(_EffStartDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugSkey")
    public JAXBElement<String> createDrugSkey(String value) {
        return new JAXBElement<String>(_DrugSkey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugDosageSKey")
    public JAXBElement<String> createDrugDosageSKey(String value) {
        return new JAXBElement<String>(_DrugDosageSKey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "medQtyLmtNote")
    public JAXBElement<String> createMedQtyLmtNote(String value) {
        return new JAXBElement<String>(_MedQtyLmtNote_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "dosage")
    public JAXBElement<String> createDosage(String value) {
        return new JAXBElement<String>(_Dosage_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "freq")
    public JAXBElement<String> createFreq(String value) {
        return new JAXBElement<String>(_Freq_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugDescription")
    public JAXBElement<String> createDrugDescription(String value) {
        return new JAXBElement<String>(_DrugDescription_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugTier")
    public JAXBElement<String> createDrugTier(String value) {
        return new JAXBElement<String>(_DrugTier_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "authDuration")
    public JAXBElement<String> createAuthDuration(String value) {
        return new JAXBElement<String>(_AuthDuration_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "authNextLevelDuration")
    public JAXBElement<String> createAuthNextLevelDuration(String value) {
        return new JAXBElement<String>(_AuthNextLevelDuration_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "genTier")
    public JAXBElement<String> createGenTier(String value) {
        return new JAXBElement<String>(_GenTier_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "autoApprovalInd")
    public JAXBElement<String> createAutoApprovalInd(String value) {
        return new JAXBElement<String>(_AutoApprovalInd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "dosageDescription")
    public JAXBElement<String> createDosageDescription(String value) {
        return new JAXBElement<String>(_DosageDescription_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "reviewer")
    public JAXBElement<String> createReviewer(String value) {
        return new JAXBElement<String>(_Reviewer_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "dosageSKey")
    public JAXBElement<String> createDosageSKey(String value) {
        return new JAXBElement<String>(_DosageSKey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "lengthAuth")
    public JAXBElement<String> createLengthAuth(String value) {
        return new JAXBElement<String>(_LengthAuth_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "genericName")
    public JAXBElement<String> createGenericName(String value) {
        return new JAXBElement<String>(_GenericName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "strength")
    public JAXBElement<String> createStrength(String value) {
        return new JAXBElement<String>(_Strength_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugTierType")
    public JAXBElement<String> createDrugTierType(String value) {
        return new JAXBElement<String>(_DrugTierType_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "denialDecisionRoute")
    public JAXBElement<String> createDenialDecisionRoute(String value) {
        return new JAXBElement<String>(_DenialDecisionRoute_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "gcnCode")
    public JAXBElement<String> createGcnCode(String value) {
        return new JAXBElement<String>(_GcnCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "activeRecordIndicator")
    public JAXBElement<String> createActiveRecordIndicator(String value) {
        return new JAXBElement<String>(_ActiveRecordIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "dosageCLSNSkey")
    public JAXBElement<String> createDosageCLSNSkey(String value) {
        return new JAXBElement<String>(_DosageCLSNSkey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "qty")
    public JAXBElement<String> createQty(String value) {
        return new JAXBElement<String>(_Qty_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugName")
    public JAXBElement<String> createDrugName(String value) {
        return new JAXBElement<String>(_DrugName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "name")
    public JAXBElement<String> createName(String value) {
        return new JAXBElement<String>(_Name_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "priorAuthId")
    public JAXBElement<String> createPriorAuthId(String value) {
        return new JAXBElement<String>(_PriorAuthId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "authId")
    public JAXBElement<String> createAuthId(String value) {
        return new JAXBElement<String>(_AuthId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "genericTier")
    public JAXBElement<String> createGenericTier(String value) {
        return new JAXBElement<String>(_GenericTier_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "comQtyLmtNote")
    public JAXBElement<String> createComQtyLmtNote(String value) {
        return new JAXBElement<String>(_ComQtyLmtNote_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "ndcCode")
    public JAXBElement<String> createNdcCode(String value) {
        return new JAXBElement<String>(_NdcCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "effEndDate")
    public JAXBElement<String> createEffEndDate(String value) {
        return new JAXBElement<String>(_EffEndDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "value")
    public JAXBElement<String> createValue(String value) {
        return new JAXBElement<String>(_Value_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "drugPAQLMapKey")
    public JAXBElement<String> createDrugPAQLMapKey(String value) {
        return new JAXBElement<String>(_DrugPAQLMapKey_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "authForStrength")
    public JAXBElement<String> createAuthForStrength(String value) {
        return new JAXBElement<String>(_AuthForStrength_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "comMedIndicator")
    public JAXBElement<String> createComMedIndicator(String value) {
        return new JAXBElement<String>(_ComMedIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "form")
    public JAXBElement<String> createForm(String value) {
        return new JAXBElement<String>(_Form_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", name = "category")
    public JAXBElement<String> createCategory(String value) {
        return new JAXBElement<String>(_Category_QNAME, String.class, null, value);
    }

}
