
package com.carefirst.enterprise.drugdetails.schema._201208;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}dosageCLSNSkey" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}dosageSKey" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}ndcCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}gcnCode" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}dosageDescription" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugCodeTypeIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}dosage" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}qty" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}dosageForm" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}strength" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugNameNTier" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}category" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}classification" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}freq" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}qtyLimitNote" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "dosageCLSNSkey",
    "dosageSKey",
    "ndcCode",
    "gcnCode",
    "dosageDescription",
    "drugCodeTypeIndicator",
    "dosage",
    "qty",
    "dosageForm",
    "strength",
    "drugNameNTier",
    "category",
    "classification",
    "freq",
    "qtyLimitNote"
})
@XmlRootElement(name = "drugDosageInfo")
public class DrugDosageInfo {

    protected String dosageCLSNSkey;
    protected String dosageSKey;
    protected String ndcCode;
    protected String gcnCode;
    protected String dosageDescription;
    protected String drugCodeTypeIndicator;
    protected String dosage;
    protected String qty;
    protected String dosageForm;
    protected String strength;
    protected List<DrugNameNTier> drugNameNTier;
    protected String category;
    protected String classification;
    protected String freq;
    protected QtyLimitNote qtyLimitNote;

    /**
     * Gets the value of the dosageCLSNSkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosageCLSNSkey() {
        return dosageCLSNSkey;
    }

    /**
     * Sets the value of the dosageCLSNSkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosageCLSNSkey(String value) {
        this.dosageCLSNSkey = value;
    }

    /**
     * Gets the value of the dosageSKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosageSKey() {
        return dosageSKey;
    }

    /**
     * Sets the value of the dosageSKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosageSKey(String value) {
        this.dosageSKey = value;
    }

    /**
     * Gets the value of the ndcCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNdcCode() {
        return ndcCode;
    }

    /**
     * Sets the value of the ndcCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNdcCode(String value) {
        this.ndcCode = value;
    }

    /**
     * Gets the value of the gcnCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGcnCode() {
        return gcnCode;
    }

    /**
     * Sets the value of the gcnCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGcnCode(String value) {
        this.gcnCode = value;
    }

    /**
     * Gets the value of the dosageDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosageDescription() {
        return dosageDescription;
    }

    /**
     * Sets the value of the dosageDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosageDescription(String value) {
        this.dosageDescription = value;
    }

    /**
     * Gets the value of the drugCodeTypeIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugCodeTypeIndicator() {
        return drugCodeTypeIndicator;
    }

    /**
     * Sets the value of the drugCodeTypeIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugCodeTypeIndicator(String value) {
        this.drugCodeTypeIndicator = value;
    }

    /**
     * Gets the value of the dosage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosage() {
        return dosage;
    }

    /**
     * Sets the value of the dosage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosage(String value) {
        this.dosage = value;
    }

    /**
     * Gets the value of the qty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getQty() {
        return qty;
    }

    /**
     * Sets the value of the qty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setQty(String value) {
        this.qty = value;
    }

    /**
     * Gets the value of the dosageForm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDosageForm() {
        return dosageForm;
    }

    /**
     * Sets the value of the dosageForm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDosageForm(String value) {
        this.dosageForm = value;
    }

    /**
     * Gets the value of the strength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrength() {
        return strength;
    }

    /**
     * Sets the value of the strength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrength(String value) {
        this.strength = value;
    }

    /**
     * Gets the value of the drugNameNTier property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the drugNameNTier property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDrugNameNTier().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DrugNameNTier }
     * 
     * 
     */
    public List<DrugNameNTier> getDrugNameNTier() {
        if (drugNameNTier == null) {
            drugNameNTier = new ArrayList<DrugNameNTier>();
        }
        return this.drugNameNTier;
    }

    /**
     * Gets the value of the category property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCategory() {
        return category;
    }

    /**
     * Sets the value of the category property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCategory(String value) {
        this.category = value;
    }

    /**
     * Gets the value of the classification property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClassification() {
        return classification;
    }

    /**
     * Sets the value of the classification property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClassification(String value) {
        this.classification = value;
    }

    /**
     * Gets the value of the freq property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFreq() {
        return freq;
    }

    /**
     * Sets the value of the freq property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFreq(String value) {
        this.freq = value;
    }

    /**
     * Gets the value of the qtyLimitNote property.
     * 
     * @return
     *     possible object is
     *     {@link QtyLimitNote }
     *     
     */
    public QtyLimitNote getQtyLimitNote() {
        return qtyLimitNote;
    }

    /**
     * Sets the value of the qtyLimitNote property.
     * 
     * @param value
     *     allowed object is
     *     {@link QtyLimitNote }
     *     
     */
    public void setQtyLimitNote(QtyLimitNote value) {
        this.qtyLimitNote = value;
    }

}
