
package com.carefirst.enterprise.drugdetails.schema._201208;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for typ_Name complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="typ_Name">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugTierType" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugTierName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugTier" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "typ_Name", propOrder = {
    "drugTierType",
    "drugTierName",
    "drugTier"
})
@XmlSeeAlso({
    DrugNameNTier.class
})
public class TypName {

    protected String drugTierType;
    protected String drugTierName;
    protected String drugTier;

    /**
     * Gets the value of the drugTierType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugTierType() {
        return drugTierType;
    }

    /**
     * Sets the value of the drugTierType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugTierType(String value) {
        this.drugTierType = value;
    }

    /**
     * Gets the value of the drugTierName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugTierName() {
        return drugTierName;
    }

    /**
     * Sets the value of the drugTierName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugTierName(String value) {
        this.drugTierName = value;
    }

    /**
     * Gets the value of the drugTier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugTier() {
        return drugTier;
    }

    /**
     * Sets the value of the drugTier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugTier(String value) {
        this.drugTier = value;
    }

}
