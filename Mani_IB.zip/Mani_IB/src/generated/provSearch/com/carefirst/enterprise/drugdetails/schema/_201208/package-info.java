@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.carefirst.enterprise.drugdetails.schema._201208;
