
package com.carefirst.enterprise.drugdetails.schema._201208;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;extension base="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}typ_Reviewer">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}autoApprovalInd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}authForStrength" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}authDuration" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}authNextLevelDuration" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "autoApprovalInd",
    "authForStrength",
    "authDuration",
    "authNextLevelDuration"
})
@XmlRootElement(name = "drugReviewer")
public class DrugReviewer
    extends TypReviewer
{

    protected String autoApprovalInd;
    protected String authForStrength;
    protected String authDuration;
    protected String authNextLevelDuration;

    /**
     * Gets the value of the autoApprovalInd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAutoApprovalInd() {
        return autoApprovalInd;
    }

    /**
     * Sets the value of the autoApprovalInd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAutoApprovalInd(String value) {
        this.autoApprovalInd = value;
    }

    /**
     * Gets the value of the authForStrength property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthForStrength() {
        return authForStrength;
    }

    /**
     * Sets the value of the authForStrength property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthForStrength(String value) {
        this.authForStrength = value;
    }

    /**
     * Gets the value of the authDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthDuration() {
        return authDuration;
    }

    /**
     * Sets the value of the authDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthDuration(String value) {
        this.authDuration = value;
    }

    /**
     * Gets the value of the authNextLevelDuration property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthNextLevelDuration() {
        return authNextLevelDuration;
    }

    /**
     * Sets the value of the authNextLevelDuration property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthNextLevelDuration(String value) {
        this.authNextLevelDuration = value;
    }

}
