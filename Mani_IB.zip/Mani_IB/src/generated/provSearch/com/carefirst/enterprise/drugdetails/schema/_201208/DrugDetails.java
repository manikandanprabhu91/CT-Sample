
package com.carefirst.enterprise.drugdetails.schema._201208;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugSkey" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugDescription" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugReviewer" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugNameNTier" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugAssociation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugDosageInfo" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "drugSkey",
    "drugName",
    "drugDescription",
    "drugReviewer",
    "drugNameNTier",
    "drugAssociation",
    "drugDosageInfo"
})
@XmlRootElement(name = "drugDetails")
public class DrugDetails {

    protected String drugSkey;
    protected String drugName;
    protected String drugDescription;
    protected DrugReviewer drugReviewer;
    protected List<DrugNameNTier> drugNameNTier;
    protected List<DrugAssociation> drugAssociation;
    protected List<DrugDosageInfo> drugDosageInfo;

    /**
     * Gets the value of the drugSkey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugSkey() {
        return drugSkey;
    }

    /**
     * Sets the value of the drugSkey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugSkey(String value) {
        this.drugSkey = value;
    }

    /**
     * Gets the value of the drugName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugName() {
        return drugName;
    }

    /**
     * Sets the value of the drugName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugName(String value) {
        this.drugName = value;
    }

    /**
     * Gets the value of the drugDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugDescription() {
        return drugDescription;
    }

    /**
     * Sets the value of the drugDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugDescription(String value) {
        this.drugDescription = value;
    }

    /**
     * Gets the value of the drugReviewer property.
     * 
     * @return
     *     possible object is
     *     {@link DrugReviewer }
     *     
     */
    public DrugReviewer getDrugReviewer() {
        return drugReviewer;
    }

    /**
     * Sets the value of the drugReviewer property.
     * 
     * @param value
     *     allowed object is
     *     {@link DrugReviewer }
     *     
     */
    public void setDrugReviewer(DrugReviewer value) {
        this.drugReviewer = value;
    }

    /**
     * Gets the value of the drugNameNTier property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the drugNameNTier property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDrugNameNTier().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DrugNameNTier }
     * 
     * 
     */
    public List<DrugNameNTier> getDrugNameNTier() {
        if (drugNameNTier == null) {
            drugNameNTier = new ArrayList<DrugNameNTier>();
        }
        return this.drugNameNTier;
    }

    /**
     * Gets the value of the drugAssociation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the drugAssociation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDrugAssociation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DrugAssociation }
     * 
     * 
     */
    public List<DrugAssociation> getDrugAssociation() {
        if (drugAssociation == null) {
            drugAssociation = new ArrayList<DrugAssociation>();
        }
        return this.drugAssociation;
    }

    /**
     * Gets the value of the drugDosageInfo property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the drugDosageInfo property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getDrugDosageInfo().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link DrugDosageInfo }
     * 
     * 
     */
    public List<DrugDosageInfo> getDrugDosageInfo() {
        if (drugDosageInfo == null) {
            drugDosageInfo = new ArrayList<DrugDosageInfo>();
        }
        return this.drugDosageInfo;
    }

}
