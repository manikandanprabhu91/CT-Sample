
package com.carefirst.enterprise.drugdetails.schema._201208;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugPAQLMapKey"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}drugDosageSKey" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}comMedIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}activeRecordIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}authIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/Enterprise/DrugDetails/Schema/201208}effectiveDate" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "drugPAQLMapKey",
    "drugDosageSKey",
    "comMedIndicator",
    "activeRecordIndicator",
    "authIndicator",
    "effectiveDate"
})
@XmlRootElement(name = "drugAssociation")
public class DrugAssociation {

    @XmlElement(required = true)
    protected String drugPAQLMapKey;
    protected String drugDosageSKey;
    protected String comMedIndicator;
    protected String activeRecordIndicator;
    protected String authIndicator;
    protected EffectiveDate effectiveDate;

    /**
     * Gets the value of the drugPAQLMapKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugPAQLMapKey() {
        return drugPAQLMapKey;
    }

    /**
     * Sets the value of the drugPAQLMapKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugPAQLMapKey(String value) {
        this.drugPAQLMapKey = value;
    }

    /**
     * Gets the value of the drugDosageSKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDrugDosageSKey() {
        return drugDosageSKey;
    }

    /**
     * Sets the value of the drugDosageSKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDrugDosageSKey(String value) {
        this.drugDosageSKey = value;
    }

    /**
     * Gets the value of the comMedIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComMedIndicator() {
        return comMedIndicator;
    }

    /**
     * Sets the value of the comMedIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComMedIndicator(String value) {
        this.comMedIndicator = value;
    }

    /**
     * Gets the value of the activeRecordIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getActiveRecordIndicator() {
        return activeRecordIndicator;
    }

    /**
     * Sets the value of the activeRecordIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setActiveRecordIndicator(String value) {
        this.activeRecordIndicator = value;
    }

    /**
     * Gets the value of the authIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthIndicator() {
        return authIndicator;
    }

    /**
     * Sets the value of the authIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthIndicator(String value) {
        this.authIndicator = value;
    }

    /**
     * Gets the value of the effectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link EffectiveDate }
     *     
     */
    public EffectiveDate getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Sets the value of the effectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link EffectiveDate }
     *     
     */
    public void setEffectiveDate(EffectiveDate value) {
        this.effectiveDate = value;
    }

}
