@javax.xml.bind.annotation.XmlSchema(namespace = "http://carefirst.com/Enterprise/Operations/SoapFault", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.carefirst.enterprise.operations.soapfault;
