
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}StatusBlock" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}ProviderResponse" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "statusBlock",
    "providerResponse"
})
@XmlRootElement(name = "ProviderResponseMessage")
public class ProviderResponseMessage {

    @XmlElement(name = "StatusBlock")
    protected StatusBlock statusBlock;
    @XmlElement(name = "ProviderResponse")
    protected ProviderResponse providerResponse;

    /**
     * Gets the value of the statusBlock property.
     * 
     * @return
     *     possible object is
     *     {@link StatusBlock }
     *     
     */
    public StatusBlock getStatusBlock() {
        return statusBlock;
    }

    /**
     * Sets the value of the statusBlock property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusBlock }
     *     
     */
    public void setStatusBlock(StatusBlock value) {
        this.statusBlock = value;
    }

    /**
     * Gets the value of the providerResponse property.
     * 
     * @return
     *     possible object is
     *     {@link ProviderResponse }
     *     
     */
    public ProviderResponse getProviderResponse() {
        return providerResponse;
    }

    /**
     * Sets the value of the providerResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProviderResponse }
     *     
     */
    public void setProviderResponse(ProviderResponse value) {
        this.providerResponse = value;
    }

}
