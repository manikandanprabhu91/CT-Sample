
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.carefirst.pcmh.provsearch.provpractitioner.schema._201307 package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _PANRID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "PANR_ID");
    private final static QName _PanelIDIndc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panel_IDIndc");
    private final static QName _StartRecord_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "startRecord");
    private final static QName _ProviderZip_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerZip");
    private final static QName _PanelID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelID");
    private final static QName _IPAddress_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "IPAddress");
    private final static QName _PanelTermDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelTermDate");
    private final static QName _PanelEffectiveDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelEffectiveDate");
    private final static QName _FecilityName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "fecilityName");
    private final static QName _RecordNum_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "recordNum");
    private final static QName _Practitioner4DigitZip_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitioner4digitZip");
    private final static QName _NetworkStatus_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "networkStatus");
    private final static QName _MesgCode_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "mesgCode");
    private final static QName _MedlPanelEfftDt_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "medlPanelEfftDt");
    private final static QName _TaxIDEfftDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "taxIDEfftDate");
    private final static QName _MedlPanlPtnrSeg_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "medlPanlPtnrSeg");
    private final static QName _TenantID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "tenantID");
    private final static QName _TAXID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "TAX_ID");
    private final static QName _PanelIndicator_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelIndicator");
    private final static QName _PractitionerStateCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerStateCd");
    private final static QName _PractitionerSecondarySpecialtyDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerSecondarySpecialtyDesc");
    private final static QName _ProviderNPIEfftDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerNPIEfftDate");
    private final static QName _ProviderNPI_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerNPI");
    private final static QName _PractitionerZip_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerZip");
    private final static QName _PractitionerFaxNumber_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerFaxNumber");
    private final static QName _MesgDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "mesgDesc");
    private final static QName _StatusCode_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "statusCode");
    private final static QName _NetworkID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "networkID");
    private final static QName _ProviderCountyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerCountyCd");
    private final static QName _SortOrder_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "sortOrder");
    private final static QName _ProviderTaxID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerTaxID");
    private final static QName _ProviderPrimarySpecialtyDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerPrimarySpecialtyDesc");
    private final static QName _UserID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "userID");
    private final static QName _Type_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "type");
    private final static QName _DateofService_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "dateofService");
    private final static QName _PractitionerSecondarySpecialtyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerSecondarySpecialtyCd");
    private final static QName _PractitionerNPIEfftDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerNPIEfftDate");
    private final static QName _TaxIDEndDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "taxIDEndDate");
    private final static QName _PractitionerCityName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerCityName");
    private final static QName _ProviderSecondarySpecialtyDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerSecondarySpecialtyDesc");
    private final static QName _ProviderCity_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerCity");
    private final static QName _PractitionerDegree_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerDegree");
    private final static QName _PanelTermReason_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelTermReason");
    private final static QName _ProviderName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerName");
    private final static QName _PractitionerAddress1_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerAddress1");
    private final static QName _ProvIDTypeCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "provIDTypeCd");
    private final static QName _SortBy_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "sortBy");
    private final static QName _PractitionerAddress2_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerAddress2");
    private final static QName _PractitionerAddress3_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerAddress3");
    private final static QName _PractitionerPANRID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerPANRID");
    private final static QName _ContractRateShtID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "contractRateShtID");
    private final static QName _UserName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "userName");
    private final static QName _TotalRecordCount_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "totalRecordCount");
    private final static QName _PractitionerLastName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerLastName");
    private final static QName _PractitionerPrimarySpecialtyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerPrimarySpecialtyCd");
    private final static QName _PractitionerNPI_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerNPI");
    private final static QName _PractitionerCountyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerCountyCd");
    private final static QName _UserRole_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "userRole");
    private final static QName _PractitionerFirstName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerFirstName");
    private final static QName _PractitionerPhoneNumber_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerPhoneNumber");
    private final static QName _SecurityToken_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "securityToken");
    private final static QName _Network_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "network");
    private final static QName _ContractEfftDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "contractEfftDate");
    private final static QName _ProviderNPITermDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerNPITermDate");
    private final static QName _PanelSegmentName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "panelSegmentName");
    private final static QName _NPI_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "NPI");
    private final static QName _Value_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "value");
    private final static QName _FacilityName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "facilityName");
    private final static QName _TypeSearch_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "typeSearch");
    private final static QName _MedlPanelTermDt_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "medlPanelTermDt");
    private final static QName _PractitionerCountryCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerCountryCd");
    private final static QName _ProviderCountyName_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerCountyName");
    private final static QName _ProviderPrimarySpecialtyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerPrimarySpecialtyCd");
    private final static QName _ContractTermDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "contractTermDate");
    private final static QName _ProviderAddressLine3_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerAddressLine3");
    private final static QName _DateTimeValue_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "dateTimeValue");
    private final static QName _ProviderAddressLine1_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerAddressLine1");
    private final static QName _PractProvID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practProvID");
    private final static QName _PractitionerNPITermDate_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerNPITermDate");
    private final static QName _ProviderAddressLine2_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerAddressLine2");
    private final static QName _ProviderState_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerState");
    private final static QName _Name_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "name");
    private final static QName _DateOfService_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "dateOfService");
    private final static QName _PractitionerCountryNm_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerCountryNm");
    private final static QName _PractitionerPrimarySpecialtyDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerPrimarySpecialtyDesc");
    private final static QName _ProviderTypeCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerTypeCd");
    private final static QName _ProviderFaxNumber_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerFaxNumber");
    private final static QName _ProviderSubTypeCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerSubTypeCd");
    private final static QName _Threshold_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "threshold");
    private final static QName _ProviderPhoneNumber_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerPhoneNumber");
    private final static QName _PractitionerCountyNm_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerCountyNm");
    private final static QName _NetworkIdDesc_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "networkIdDesc");
    private final static QName _PractitionerTitle_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "practitionerTitle");
    private final static QName _ProviderSecondarySpecialtyCd_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerSecondarySpecialtyCd");
    private final static QName _ProviderPANRID_QNAME = new QName("http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", "providerPANR_ID");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.carefirst.pcmh.provsearch.provpractitioner.schema._201307
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link NameValueReq }
     * 
     */
    public NameValueReq createNameValueReq() {
        return new NameValueReq();
    }

    /**
     * Create an instance of {@link NameValueGrp }
     * 
     */
    public NameValueGrp createNameValueGrp() {
        return new NameValueGrp();
    }

    /**
     * Create an instance of {@link TypeNameValue }
     * 
     */
    public TypeNameValue createTypeNameValue() {
        return new TypeNameValue();
    }

    /**
     * Create an instance of {@link Practitioner }
     * 
     */
    public Practitioner createPractitioner() {
        return new Practitioner();
    }

    /**
     * Create an instance of {@link NetworkDetails }
     * 
     */
    public NetworkDetails createNetworkDetails() {
        return new NetworkDetails();
    }

    /**
     * Create an instance of {@link StatusBlock }
     * 
     */
    public StatusBlock createStatusBlock() {
        return new StatusBlock();
    }

    /**
     * Create an instance of {@link StatusMessage }
     * 
     */
    public StatusMessage createStatusMessage() {
        return new StatusMessage();
    }

    /**
     * Create an instance of {@link ProviderDetails }
     * 
     */
    public ProviderDetails createProviderDetails() {
        return new ProviderDetails();
    }

    /**
     * Create an instance of {@link ProviderResponse }
     * 
     */
    public ProviderResponse createProviderResponse() {
        return new ProviderResponse();
    }

    /**
     * Create an instance of {@link Provider }
     * 
     */
    public Provider createProvider() {
        return new Provider();
    }

    /**
     * Create an instance of {@link CFProviderResponse }
     * 
     */
    public CFProviderResponse createCFProviderResponse() {
        return new CFProviderResponse();
    }

    /**
     * Create an instance of {@link ProviderRequestMessage }
     * 
     */
    public ProviderRequestMessage createProviderRequestMessage() {
        return new ProviderRequestMessage();
    }

    /**
     * Create an instance of {@link RequesteeDetails }
     * 
     */
    public RequesteeDetails createRequesteeDetails() {
        return new RequesteeDetails();
    }

    /**
     * Create an instance of {@link Sort }
     * 
     */
    public Sort createSort() {
        return new Sort();
    }

    /**
     * Create an instance of {@link Pagination }
     * 
     */
    public Pagination createPagination() {
        return new Pagination();
    }

    /**
     * Create an instance of {@link Results }
     * 
     */
    public Results createResults() {
        return new Results();
    }

    /**
     * Create an instance of {@link GenericResponse }
     * 
     */
    public GenericResponse createGenericResponse() {
        return new GenericResponse();
    }

    /**
     * Create an instance of {@link ProviderResponseMessage }
     * 
     */
    public ProviderResponseMessage createProviderResponseMessage() {
        return new ProviderResponseMessage();
    }

    /**
     * Create an instance of {@link CFProviderRequest }
     * 
     */
    public CFProviderRequest createCFProviderRequest() {
        return new CFProviderRequest();
    }

    /**
     * Create an instance of {@link GenericRequest }
     * 
     */
    public GenericRequest createGenericRequest() {
        return new GenericRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "PANR_ID")
    public JAXBElement<String> createPANRID(String value) {
        return new JAXBElement<String>(_PANRID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panel_IDIndc")
    public JAXBElement<String> createPanelIDIndc(String value) {
        return new JAXBElement<String>(_PanelIDIndc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "startRecord")
    public JAXBElement<String> createStartRecord(String value) {
        return new JAXBElement<String>(_StartRecord_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerZip")
    public JAXBElement<String> createProviderZip(String value) {
        return new JAXBElement<String>(_ProviderZip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelID")
    public JAXBElement<String> createPanelID(String value) {
        return new JAXBElement<String>(_PanelID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "IPAddress")
    public JAXBElement<String> createIPAddress(String value) {
        return new JAXBElement<String>(_IPAddress_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelTermDate")
    public JAXBElement<String> createPanelTermDate(String value) {
        return new JAXBElement<String>(_PanelTermDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelEffectiveDate")
    public JAXBElement<String> createPanelEffectiveDate(String value) {
        return new JAXBElement<String>(_PanelEffectiveDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "fecilityName")
    public JAXBElement<String> createFecilityName(String value) {
        return new JAXBElement<String>(_FecilityName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "recordNum")
    public JAXBElement<String> createRecordNum(String value) {
        return new JAXBElement<String>(_RecordNum_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitioner4digitZip")
    public JAXBElement<String> createPractitioner4DigitZip(String value) {
        return new JAXBElement<String>(_Practitioner4DigitZip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "networkStatus")
    public JAXBElement<String> createNetworkStatus(String value) {
        return new JAXBElement<String>(_NetworkStatus_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "mesgCode")
    public JAXBElement<String> createMesgCode(String value) {
        return new JAXBElement<String>(_MesgCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "medlPanelEfftDt")
    public JAXBElement<String> createMedlPanelEfftDt(String value) {
        return new JAXBElement<String>(_MedlPanelEfftDt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "taxIDEfftDate")
    public JAXBElement<String> createTaxIDEfftDate(String value) {
        return new JAXBElement<String>(_TaxIDEfftDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "medlPanlPtnrSeg")
    public JAXBElement<String> createMedlPanlPtnrSeg(String value) {
        return new JAXBElement<String>(_MedlPanlPtnrSeg_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "tenantID")
    public JAXBElement<String> createTenantID(String value) {
        return new JAXBElement<String>(_TenantID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "TAX_ID")
    public JAXBElement<String> createTAXID(String value) {
        return new JAXBElement<String>(_TAXID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelIndicator")
    public JAXBElement<String> createPanelIndicator(String value) {
        return new JAXBElement<String>(_PanelIndicator_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerStateCd")
    public JAXBElement<String> createPractitionerStateCd(String value) {
        return new JAXBElement<String>(_PractitionerStateCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerSecondarySpecialtyDesc")
    public JAXBElement<String> createPractitionerSecondarySpecialtyDesc(String value) {
        return new JAXBElement<String>(_PractitionerSecondarySpecialtyDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerNPIEfftDate")
    public JAXBElement<String> createProviderNPIEfftDate(String value) {
        return new JAXBElement<String>(_ProviderNPIEfftDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerNPI")
    public JAXBElement<String> createProviderNPI(String value) {
        return new JAXBElement<String>(_ProviderNPI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerZip")
    public JAXBElement<String> createPractitionerZip(String value) {
        return new JAXBElement<String>(_PractitionerZip_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerFaxNumber")
    public JAXBElement<String> createPractitionerFaxNumber(String value) {
        return new JAXBElement<String>(_PractitionerFaxNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "mesgDesc")
    public JAXBElement<String> createMesgDesc(String value) {
        return new JAXBElement<String>(_MesgDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "statusCode")
    public JAXBElement<String> createStatusCode(String value) {
        return new JAXBElement<String>(_StatusCode_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "networkID")
    public JAXBElement<String> createNetworkID(String value) {
        return new JAXBElement<String>(_NetworkID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerCountyCd")
    public JAXBElement<String> createProviderCountyCd(String value) {
        return new JAXBElement<String>(_ProviderCountyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "sortOrder")
    public JAXBElement<String> createSortOrder(String value) {
        return new JAXBElement<String>(_SortOrder_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerTaxID")
    public JAXBElement<String> createProviderTaxID(String value) {
        return new JAXBElement<String>(_ProviderTaxID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerPrimarySpecialtyDesc")
    public JAXBElement<String> createProviderPrimarySpecialtyDesc(String value) {
        return new JAXBElement<String>(_ProviderPrimarySpecialtyDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "userID")
    public JAXBElement<String> createUserID(String value) {
        return new JAXBElement<String>(_UserID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "type")
    public JAXBElement<String> createType(String value) {
        return new JAXBElement<String>(_Type_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "dateofService")
    public JAXBElement<String> createDateofService(String value) {
        return new JAXBElement<String>(_DateofService_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerSecondarySpecialtyCd")
    public JAXBElement<String> createPractitionerSecondarySpecialtyCd(String value) {
        return new JAXBElement<String>(_PractitionerSecondarySpecialtyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerNPIEfftDate")
    public JAXBElement<String> createPractitionerNPIEfftDate(String value) {
        return new JAXBElement<String>(_PractitionerNPIEfftDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "taxIDEndDate")
    public JAXBElement<String> createTaxIDEndDate(String value) {
        return new JAXBElement<String>(_TaxIDEndDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerCityName")
    public JAXBElement<String> createPractitionerCityName(String value) {
        return new JAXBElement<String>(_PractitionerCityName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerSecondarySpecialtyDesc")
    public JAXBElement<String> createProviderSecondarySpecialtyDesc(String value) {
        return new JAXBElement<String>(_ProviderSecondarySpecialtyDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerCity")
    public JAXBElement<String> createProviderCity(String value) {
        return new JAXBElement<String>(_ProviderCity_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerDegree")
    public JAXBElement<String> createPractitionerDegree(String value) {
        return new JAXBElement<String>(_PractitionerDegree_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelTermReason")
    public JAXBElement<String> createPanelTermReason(String value) {
        return new JAXBElement<String>(_PanelTermReason_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerName")
    public JAXBElement<String> createProviderName(String value) {
        return new JAXBElement<String>(_ProviderName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerAddress1")
    public JAXBElement<String> createPractitionerAddress1(String value) {
        return new JAXBElement<String>(_PractitionerAddress1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "provIDTypeCd")
    public JAXBElement<String> createProvIDTypeCd(String value) {
        return new JAXBElement<String>(_ProvIDTypeCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "sortBy")
    public JAXBElement<String> createSortBy(String value) {
        return new JAXBElement<String>(_SortBy_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerAddress2")
    public JAXBElement<String> createPractitionerAddress2(String value) {
        return new JAXBElement<String>(_PractitionerAddress2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerAddress3")
    public JAXBElement<String> createPractitionerAddress3(String value) {
        return new JAXBElement<String>(_PractitionerAddress3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerPANRID")
    public JAXBElement<String> createPractitionerPANRID(String value) {
        return new JAXBElement<String>(_PractitionerPANRID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "contractRateShtID")
    public JAXBElement<String> createContractRateShtID(String value) {
        return new JAXBElement<String>(_ContractRateShtID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "userName")
    public JAXBElement<String> createUserName(String value) {
        return new JAXBElement<String>(_UserName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "totalRecordCount")
    public JAXBElement<String> createTotalRecordCount(String value) {
        return new JAXBElement<String>(_TotalRecordCount_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerLastName")
    public JAXBElement<String> createPractitionerLastName(String value) {
        return new JAXBElement<String>(_PractitionerLastName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerPrimarySpecialtyCd")
    public JAXBElement<String> createPractitionerPrimarySpecialtyCd(String value) {
        return new JAXBElement<String>(_PractitionerPrimarySpecialtyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerNPI")
    public JAXBElement<String> createPractitionerNPI(String value) {
        return new JAXBElement<String>(_PractitionerNPI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerCountyCd")
    public JAXBElement<String> createPractitionerCountyCd(String value) {
        return new JAXBElement<String>(_PractitionerCountyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "userRole")
    public JAXBElement<String> createUserRole(String value) {
        return new JAXBElement<String>(_UserRole_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerFirstName")
    public JAXBElement<String> createPractitionerFirstName(String value) {
        return new JAXBElement<String>(_PractitionerFirstName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerPhoneNumber")
    public JAXBElement<String> createPractitionerPhoneNumber(String value) {
        return new JAXBElement<String>(_PractitionerPhoneNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "securityToken")
    public JAXBElement<String> createSecurityToken(String value) {
        return new JAXBElement<String>(_SecurityToken_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "network")
    public JAXBElement<String> createNetwork(String value) {
        return new JAXBElement<String>(_Network_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "contractEfftDate")
    public JAXBElement<String> createContractEfftDate(String value) {
        return new JAXBElement<String>(_ContractEfftDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerNPITermDate")
    public JAXBElement<String> createProviderNPITermDate(String value) {
        return new JAXBElement<String>(_ProviderNPITermDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "panelSegmentName")
    public JAXBElement<String> createPanelSegmentName(String value) {
        return new JAXBElement<String>(_PanelSegmentName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "NPI")
    public JAXBElement<String> createNPI(String value) {
        return new JAXBElement<String>(_NPI_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "value")
    public JAXBElement<String> createValue(String value) {
        return new JAXBElement<String>(_Value_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "facilityName")
    public JAXBElement<String> createFacilityName(String value) {
        return new JAXBElement<String>(_FacilityName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "typeSearch")
    public JAXBElement<String> createTypeSearch(String value) {
        return new JAXBElement<String>(_TypeSearch_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "medlPanelTermDt")
    public JAXBElement<String> createMedlPanelTermDt(String value) {
        return new JAXBElement<String>(_MedlPanelTermDt_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerCountryCd")
    public JAXBElement<String> createPractitionerCountryCd(String value) {
        return new JAXBElement<String>(_PractitionerCountryCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerCountyName")
    public JAXBElement<String> createProviderCountyName(String value) {
        return new JAXBElement<String>(_ProviderCountyName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerPrimarySpecialtyCd")
    public JAXBElement<String> createProviderPrimarySpecialtyCd(String value) {
        return new JAXBElement<String>(_ProviderPrimarySpecialtyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "contractTermDate")
    public JAXBElement<String> createContractTermDate(String value) {
        return new JAXBElement<String>(_ContractTermDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerAddressLine3")
    public JAXBElement<String> createProviderAddressLine3(String value) {
        return new JAXBElement<String>(_ProviderAddressLine3_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "dateTimeValue")
    public JAXBElement<XMLGregorianCalendar> createDateTimeValue(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_DateTimeValue_QNAME, XMLGregorianCalendar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerAddressLine1")
    public JAXBElement<String> createProviderAddressLine1(String value) {
        return new JAXBElement<String>(_ProviderAddressLine1_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practProvID")
    public JAXBElement<String> createPractProvID(String value) {
        return new JAXBElement<String>(_PractProvID_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerNPITermDate")
    public JAXBElement<String> createPractitionerNPITermDate(String value) {
        return new JAXBElement<String>(_PractitionerNPITermDate_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerAddressLine2")
    public JAXBElement<String> createProviderAddressLine2(String value) {
        return new JAXBElement<String>(_ProviderAddressLine2_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerState")
    public JAXBElement<String> createProviderState(String value) {
        return new JAXBElement<String>(_ProviderState_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "name")
    public JAXBElement<String> createName(String value) {
        return new JAXBElement<String>(_Name_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "dateOfService")
    public JAXBElement<String> createDateOfService(String value) {
        return new JAXBElement<String>(_DateOfService_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerCountryNm")
    public JAXBElement<String> createPractitionerCountryNm(String value) {
        return new JAXBElement<String>(_PractitionerCountryNm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerPrimarySpecialtyDesc")
    public JAXBElement<String> createPractitionerPrimarySpecialtyDesc(String value) {
        return new JAXBElement<String>(_PractitionerPrimarySpecialtyDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerTypeCd")
    public JAXBElement<String> createProviderTypeCd(String value) {
        return new JAXBElement<String>(_ProviderTypeCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerFaxNumber")
    public JAXBElement<String> createProviderFaxNumber(String value) {
        return new JAXBElement<String>(_ProviderFaxNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerSubTypeCd")
    public JAXBElement<String> createProviderSubTypeCd(String value) {
        return new JAXBElement<String>(_ProviderSubTypeCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "threshold")
    public JAXBElement<String> createThreshold(String value) {
        return new JAXBElement<String>(_Threshold_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerPhoneNumber")
    public JAXBElement<String> createProviderPhoneNumber(String value) {
        return new JAXBElement<String>(_ProviderPhoneNumber_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerCountyNm")
    public JAXBElement<String> createPractitionerCountyNm(String value) {
        return new JAXBElement<String>(_PractitionerCountyNm_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "networkIdDesc")
    public JAXBElement<String> createNetworkIdDesc(String value) {
        return new JAXBElement<String>(_NetworkIdDesc_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "practitionerTitle")
    public JAXBElement<String> createPractitionerTitle(String value) {
        return new JAXBElement<String>(_PractitionerTitle_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerSecondarySpecialtyCd")
    public JAXBElement<String> createProviderSecondarySpecialtyCd(String value) {
        return new JAXBElement<String>(_ProviderSecondarySpecialtyCd_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307", name = "providerPANR_ID")
    public JAXBElement<String> createProviderPANRID(String value) {
        return new JAXBElement<String>(_ProviderPANRID_QNAME, String.class, null, value);
    }

}
