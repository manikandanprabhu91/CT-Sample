
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}network" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}networkID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}networkIdDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}networkStatus" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}contractEfftDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}contractTermDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}contractRateShtID" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "network",
    "networkID",
    "networkIdDesc",
    "networkStatus",
    "contractEfftDate",
    "contractTermDate",
    "contractRateShtID"
})
@XmlRootElement(name = "networkDetails")
public class NetworkDetails {

    protected String network;
    protected String networkID;
    protected String networkIdDesc;
    protected String networkStatus;
    protected String contractEfftDate;
    protected String contractTermDate;
    protected String contractRateShtID;

    /**
     * Gets the value of the network property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetwork() {
        return network;
    }

    /**
     * Sets the value of the network property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetwork(String value) {
        this.network = value;
    }

    /**
     * Gets the value of the networkID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkID() {
        return networkID;
    }

    /**
     * Sets the value of the networkID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkID(String value) {
        this.networkID = value;
    }

    /**
     * Gets the value of the networkIdDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkIdDesc() {
        return networkIdDesc;
    }

    /**
     * Sets the value of the networkIdDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkIdDesc(String value) {
        this.networkIdDesc = value;
    }

    /**
     * Gets the value of the networkStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNetworkStatus() {
        return networkStatus;
    }

    /**
     * Sets the value of the networkStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNetworkStatus(String value) {
        this.networkStatus = value;
    }

    /**
     * Gets the value of the contractEfftDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractEfftDate() {
        return contractEfftDate;
    }

    /**
     * Sets the value of the contractEfftDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractEfftDate(String value) {
        this.contractEfftDate = value;
    }

    /**
     * Gets the value of the contractTermDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractTermDate() {
        return contractTermDate;
    }

    /**
     * Sets the value of the contractTermDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractTermDate(String value) {
        this.contractTermDate = value;
    }

    /**
     * Gets the value of the contractRateShtID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getContractRateShtID() {
        return contractRateShtID;
    }

    /**
     * Sets the value of the contractRateShtID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setContractRateShtID(String value) {
        this.contractRateShtID = value;
    }

}
