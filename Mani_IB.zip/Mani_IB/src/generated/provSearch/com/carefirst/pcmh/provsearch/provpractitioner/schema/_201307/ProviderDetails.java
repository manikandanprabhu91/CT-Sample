
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}PANR_ID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}TAX_ID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}NPI" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}tenantID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerLastName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}facilityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}typeSearch" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}nameValueReq" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "panrid",
    "taxid",
    "npi",
    "tenantID",
    "providerName",
    "practitionerLastName",
    "facilityName",
    "typeSearch",
    "nameValueReq"
})
@XmlRootElement(name = "providerDetails")
public class ProviderDetails {

    @XmlElement(name = "PANR_ID")
    protected String panrid;
    @XmlElement(name = "TAX_ID")
    protected String taxid;
    @XmlElement(name = "NPI")
    protected String npi;
    protected String tenantID;
    protected String providerName;
    protected String practitionerLastName;
    protected String facilityName;
    protected String typeSearch;
    protected List<NameValueReq> nameValueReq;

    /**
     * Gets the value of the panrid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPANRID() {
        return panrid;
    }

    /**
     * Sets the value of the panrid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPANRID(String value) {
        this.panrid = value;
    }

    /**
     * Gets the value of the taxid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTAXID() {
        return taxid;
    }

    /**
     * Sets the value of the taxid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTAXID(String value) {
        this.taxid = value;
    }

    /**
     * Gets the value of the npi property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNPI() {
        return npi;
    }

    /**
     * Sets the value of the npi property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNPI(String value) {
        this.npi = value;
    }

    /**
     * Gets the value of the tenantID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenantID() {
        return tenantID;
    }

    /**
     * Sets the value of the tenantID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenantID(String value) {
        this.tenantID = value;
    }

    /**
     * Gets the value of the providerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * Sets the value of the providerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderName(String value) {
        this.providerName = value;
    }

    /**
     * Gets the value of the practitionerLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerLastName() {
        return practitionerLastName;
    }

    /**
     * Sets the value of the practitionerLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerLastName(String value) {
        this.practitionerLastName = value;
    }

    /**
     * Gets the value of the facilityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFacilityName() {
        return facilityName;
    }

    /**
     * Sets the value of the facilityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFacilityName(String value) {
        this.facilityName = value;
    }

    /**
     * Gets the value of the typeSearch property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeSearch() {
        return typeSearch;
    }

    /**
     * Sets the value of the typeSearch property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeSearch(String value) {
        this.typeSearch = value;
    }

    /**
     * Gets the value of the nameValueReq property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the nameValueReq property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNameValueReq().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NameValueReq }
     * 
     * 
     */
    public List<NameValueReq> getNameValueReq() {
        if (nameValueReq == null) {
            nameValueReq = new ArrayList<NameValueReq>();
        }
        return this.nameValueReq;
    }

}
