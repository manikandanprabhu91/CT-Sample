
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}requesteeDetails" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}sort" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}pagination" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "providerDetails",
    "requesteeDetails",
    "sort",
    "pagination"
})
@XmlRootElement(name = "CFProviderRequest")
public class CFProviderRequest {

    protected List<ProviderDetails> providerDetails;
    protected RequesteeDetails requesteeDetails;
    protected List<Sort> sort;
    protected Pagination pagination;

    /**
     * Gets the value of the providerDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the providerDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProviderDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProviderDetails }
     * 
     * 
     */
    public List<ProviderDetails> getProviderDetails() {
        if (providerDetails == null) {
            providerDetails = new ArrayList<ProviderDetails>();
        }
        return this.providerDetails;
    }

    /**
     * Gets the value of the requesteeDetails property.
     * 
     * @return
     *     possible object is
     *     {@link RequesteeDetails }
     *     
     */
    public RequesteeDetails getRequesteeDetails() {
        return requesteeDetails;
    }

    /**
     * Sets the value of the requesteeDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link RequesteeDetails }
     *     
     */
    public void setRequesteeDetails(RequesteeDetails value) {
        this.requesteeDetails = value;
    }

    /**
     * Gets the value of the sort property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the sort property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getSort().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Sort }
     * 
     * 
     */
    public List<Sort> getSort() {
        if (sort == null) {
            sort = new ArrayList<Sort>();
        }
        return this.sort;
    }

    /**
     * Gets the value of the pagination property.
     * 
     * @return
     *     possible object is
     *     {@link Pagination }
     *     
     */
    public Pagination getPagination() {
        return pagination;
    }

    /**
     * Sets the value of the pagination property.
     * 
     * @param value
     *     allowed object is
     *     {@link Pagination }
     *     
     */
    public void setPagination(Pagination value) {
        this.pagination = value;
    }

}
