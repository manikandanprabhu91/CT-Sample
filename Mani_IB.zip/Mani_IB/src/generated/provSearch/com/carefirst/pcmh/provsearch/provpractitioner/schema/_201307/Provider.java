
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerPANR_ID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerTaxID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerTypeCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerSubTypeCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}provIDTypeCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panel_IDIndc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}medlPanelEfftDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}medlPanelTermDt" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelTermReason" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerPrimarySpecialtyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerPrimarySpecialtyDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerSecondarySpecialtyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerSecondarySpecialtyDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerPhoneNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerFaxNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerAddressLine1" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerAddressLine2" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerAddressLine3" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerCity" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerState" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerZip" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerCountyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerCountyName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerNPI" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerNPIEfftDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}providerNPITermDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}taxIDEfftDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}taxIDEndDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}networkDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}recordNum" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}Practitioner" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "providerPANRID",
    "providerTaxID",
    "providerName",
    "providerTypeCd",
    "providerSubTypeCd",
    "provIDTypeCd",
    "panelID",
    "panelIDIndc",
    "medlPanelEfftDt",
    "medlPanelTermDt",
    "panelTermReason",
    "providerPrimarySpecialtyCd",
    "providerPrimarySpecialtyDesc",
    "providerSecondarySpecialtyCd",
    "providerSecondarySpecialtyDesc",
    "providerPhoneNumber",
    "providerFaxNumber",
    "providerAddressLine1",
    "providerAddressLine2",
    "providerAddressLine3",
    "providerCity",
    "providerState",
    "providerZip",
    "providerCountyCd",
    "providerCountyName",
    "providerNPI",
    "providerNPIEfftDate",
    "providerNPITermDate",
    "taxIDEfftDate",
    "taxIDEndDate",
    "networkDetails",
    "recordNum",
    "practitioner"
})
@XmlRootElement(name = "Provider")
public class Provider {

    @XmlElement(name = "providerPANR_ID")
    protected String providerPANRID;
    protected String providerTaxID;
    protected String providerName;
    protected String providerTypeCd;
    protected String providerSubTypeCd;
    protected String provIDTypeCd;
    protected String panelID;
    @XmlElement(name = "panel_IDIndc")
    protected String panelIDIndc;
    protected String medlPanelEfftDt;
    protected String medlPanelTermDt;
    protected String panelTermReason;
    protected String providerPrimarySpecialtyCd;
    protected String providerPrimarySpecialtyDesc;
    protected String providerSecondarySpecialtyCd;
    protected String providerSecondarySpecialtyDesc;
    protected String providerPhoneNumber;
    protected String providerFaxNumber;
    protected String providerAddressLine1;
    protected String providerAddressLine2;
    protected String providerAddressLine3;
    protected String providerCity;
    protected String providerState;
    protected String providerZip;
    protected String providerCountyCd;
    protected String providerCountyName;
    protected String providerNPI;
    protected String providerNPIEfftDate;
    protected String providerNPITermDate;
    protected String taxIDEfftDate;
    protected String taxIDEndDate;
    protected List<NetworkDetails> networkDetails;
    protected String recordNum;
    @XmlElement(name = "Practitioner")
    protected List<Practitioner> practitioner;

    /**
     * Gets the value of the providerPANRID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderPANRID() {
        return providerPANRID;
    }

    /**
     * Sets the value of the providerPANRID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderPANRID(String value) {
        this.providerPANRID = value;
    }

    /**
     * Gets the value of the providerTaxID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderTaxID() {
        return providerTaxID;
    }

    /**
     * Sets the value of the providerTaxID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderTaxID(String value) {
        this.providerTaxID = value;
    }

    /**
     * Gets the value of the providerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderName() {
        return providerName;
    }

    /**
     * Sets the value of the providerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderName(String value) {
        this.providerName = value;
    }

    /**
     * Gets the value of the providerTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderTypeCd() {
        return providerTypeCd;
    }

    /**
     * Sets the value of the providerTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderTypeCd(String value) {
        this.providerTypeCd = value;
    }

    /**
     * Gets the value of the providerSubTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderSubTypeCd() {
        return providerSubTypeCd;
    }

    /**
     * Sets the value of the providerSubTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderSubTypeCd(String value) {
        this.providerSubTypeCd = value;
    }

    /**
     * Gets the value of the provIDTypeCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvIDTypeCd() {
        return provIDTypeCd;
    }

    /**
     * Sets the value of the provIDTypeCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvIDTypeCd(String value) {
        this.provIDTypeCd = value;
    }

    /**
     * Gets the value of the panelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelID() {
        return panelID;
    }

    /**
     * Sets the value of the panelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelID(String value) {
        this.panelID = value;
    }

    /**
     * Gets the value of the panelIDIndc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelIDIndc() {
        return panelIDIndc;
    }

    /**
     * Sets the value of the panelIDIndc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelIDIndc(String value) {
        this.panelIDIndc = value;
    }

    /**
     * Gets the value of the medlPanelEfftDt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedlPanelEfftDt() {
        return medlPanelEfftDt;
    }

    /**
     * Sets the value of the medlPanelEfftDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedlPanelEfftDt(String value) {
        this.medlPanelEfftDt = value;
    }

    /**
     * Gets the value of the medlPanelTermDt property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedlPanelTermDt() {
        return medlPanelTermDt;
    }

    /**
     * Sets the value of the medlPanelTermDt property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedlPanelTermDt(String value) {
        this.medlPanelTermDt = value;
    }

    /**
     * Gets the value of the panelTermReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelTermReason() {
        return panelTermReason;
    }

    /**
     * Sets the value of the panelTermReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelTermReason(String value) {
        this.panelTermReason = value;
    }

    /**
     * Gets the value of the providerPrimarySpecialtyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderPrimarySpecialtyCd() {
        return providerPrimarySpecialtyCd;
    }

    /**
     * Sets the value of the providerPrimarySpecialtyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderPrimarySpecialtyCd(String value) {
        this.providerPrimarySpecialtyCd = value;
    }

    /**
     * Gets the value of the providerPrimarySpecialtyDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderPrimarySpecialtyDesc() {
        return providerPrimarySpecialtyDesc;
    }

    /**
     * Sets the value of the providerPrimarySpecialtyDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderPrimarySpecialtyDesc(String value) {
        this.providerPrimarySpecialtyDesc = value;
    }

    /**
     * Gets the value of the providerSecondarySpecialtyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderSecondarySpecialtyCd() {
        return providerSecondarySpecialtyCd;
    }

    /**
     * Sets the value of the providerSecondarySpecialtyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderSecondarySpecialtyCd(String value) {
        this.providerSecondarySpecialtyCd = value;
    }

    /**
     * Gets the value of the providerSecondarySpecialtyDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderSecondarySpecialtyDesc() {
        return providerSecondarySpecialtyDesc;
    }

    /**
     * Sets the value of the providerSecondarySpecialtyDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderSecondarySpecialtyDesc(String value) {
        this.providerSecondarySpecialtyDesc = value;
    }

    /**
     * Gets the value of the providerPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderPhoneNumber() {
        return providerPhoneNumber;
    }

    /**
     * Sets the value of the providerPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderPhoneNumber(String value) {
        this.providerPhoneNumber = value;
    }

    /**
     * Gets the value of the providerFaxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderFaxNumber() {
        return providerFaxNumber;
    }

    /**
     * Sets the value of the providerFaxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderFaxNumber(String value) {
        this.providerFaxNumber = value;
    }

    /**
     * Gets the value of the providerAddressLine1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderAddressLine1() {
        return providerAddressLine1;
    }

    /**
     * Sets the value of the providerAddressLine1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderAddressLine1(String value) {
        this.providerAddressLine1 = value;
    }

    /**
     * Gets the value of the providerAddressLine2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderAddressLine2() {
        return providerAddressLine2;
    }

    /**
     * Sets the value of the providerAddressLine2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderAddressLine2(String value) {
        this.providerAddressLine2 = value;
    }

    /**
     * Gets the value of the providerAddressLine3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderAddressLine3() {
        return providerAddressLine3;
    }

    /**
     * Sets the value of the providerAddressLine3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderAddressLine3(String value) {
        this.providerAddressLine3 = value;
    }

    /**
     * Gets the value of the providerCity property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderCity() {
        return providerCity;
    }

    /**
     * Sets the value of the providerCity property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderCity(String value) {
        this.providerCity = value;
    }

    /**
     * Gets the value of the providerState property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderState() {
        return providerState;
    }

    /**
     * Sets the value of the providerState property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderState(String value) {
        this.providerState = value;
    }

    /**
     * Gets the value of the providerZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderZip() {
        return providerZip;
    }

    /**
     * Sets the value of the providerZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderZip(String value) {
        this.providerZip = value;
    }

    /**
     * Gets the value of the providerCountyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderCountyCd() {
        return providerCountyCd;
    }

    /**
     * Sets the value of the providerCountyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderCountyCd(String value) {
        this.providerCountyCd = value;
    }

    /**
     * Gets the value of the providerCountyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderCountyName() {
        return providerCountyName;
    }

    /**
     * Sets the value of the providerCountyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderCountyName(String value) {
        this.providerCountyName = value;
    }

    /**
     * Gets the value of the providerNPI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNPI() {
        return providerNPI;
    }

    /**
     * Sets the value of the providerNPI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNPI(String value) {
        this.providerNPI = value;
    }

    /**
     * Gets the value of the providerNPIEfftDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNPIEfftDate() {
        return providerNPIEfftDate;
    }

    /**
     * Sets the value of the providerNPIEfftDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNPIEfftDate(String value) {
        this.providerNPIEfftDate = value;
    }

    /**
     * Gets the value of the providerNPITermDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProviderNPITermDate() {
        return providerNPITermDate;
    }

    /**
     * Sets the value of the providerNPITermDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProviderNPITermDate(String value) {
        this.providerNPITermDate = value;
    }

    /**
     * Gets the value of the taxIDEfftDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxIDEfftDate() {
        return taxIDEfftDate;
    }

    /**
     * Sets the value of the taxIDEfftDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxIDEfftDate(String value) {
        this.taxIDEfftDate = value;
    }

    /**
     * Gets the value of the taxIDEndDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTaxIDEndDate() {
        return taxIDEndDate;
    }

    /**
     * Sets the value of the taxIDEndDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTaxIDEndDate(String value) {
        this.taxIDEndDate = value;
    }

    /**
     * Gets the value of the networkDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the networkDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNetworkDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkDetails }
     * 
     * 
     */
    public List<NetworkDetails> getNetworkDetails() {
        if (networkDetails == null) {
            networkDetails = new ArrayList<NetworkDetails>();
        }
        return this.networkDetails;
    }

    /**
     * Gets the value of the recordNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordNum() {
        return recordNum;
    }

    /**
     * Sets the value of the recordNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordNum(String value) {
        this.recordNum = value;
    }

    /**
     * Gets the value of the practitioner property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the practitioner property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPractitioner().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Practitioner }
     * 
     * 
     */
    public List<Practitioner> getPractitioner() {
        if (practitioner == null) {
            practitioner = new ArrayList<Practitioner>();
        }
        return this.practitioner;
    }

}
