
package com.carefirst.pcmh.provsearch.provpractitioner.schema._201307;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerPANRID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practProvID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerFirstName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerLastName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerDegree" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerPrimarySpecialtyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerPrimarySpecialtyDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerSecondarySpecialtyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerSecondarySpecialtyDesc" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelSegmentName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}medlPanlPtnrSeg" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelTermReason" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelID" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelIndicator" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelEffectiveDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}panelTermDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerPhoneNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerFaxNumber" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerAddress1" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerAddress2" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerAddress3" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerCityName" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerStateCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerZip" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitioner4digitZip" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerCountyCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerCountyNm" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerCountryCd" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerCountryNm" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerNPI" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerNPIEfftDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerNPITermDate" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}practitionerTitle" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}networkDetails" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element ref="{http://www.carefirst.com/PCMH/ProvSearch/ProvPractitioner/Schema/201307}recordNum" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "practitionerPANRID",
    "practProvID",
    "practitionerFirstName",
    "practitionerLastName",
    "practitionerDegree",
    "practitionerPrimarySpecialtyCd",
    "practitionerPrimarySpecialtyDesc",
    "practitionerSecondarySpecialtyCd",
    "practitionerSecondarySpecialtyDesc",
    "panelSegmentName",
    "medlPanlPtnrSeg",
    "panelTermReason",
    "panelID",
    "panelIndicator",
    "panelEffectiveDate",
    "panelTermDate",
    "practitionerPhoneNumber",
    "practitionerFaxNumber",
    "practitionerAddress1",
    "practitionerAddress2",
    "practitionerAddress3",
    "practitionerCityName",
    "practitionerStateCd",
    "practitionerZip",
    "practitioner4DigitZip",
    "practitionerCountyCd",
    "practitionerCountyNm",
    "practitionerCountryCd",
    "practitionerCountryNm",
    "practitionerNPI",
    "practitionerNPIEfftDate",
    "practitionerNPITermDate",
    "practitionerTitle",
    "networkDetails",
    "recordNum"
})
@XmlRootElement(name = "Practitioner")
public class Practitioner {

    protected String practitionerPANRID;
    protected String practProvID;
    protected String practitionerFirstName;
    protected String practitionerLastName;
    protected String practitionerDegree;
    protected String practitionerPrimarySpecialtyCd;
    protected String practitionerPrimarySpecialtyDesc;
    protected String practitionerSecondarySpecialtyCd;
    protected String practitionerSecondarySpecialtyDesc;
    protected String panelSegmentName;
    protected String medlPanlPtnrSeg;
    protected String panelTermReason;
    protected String panelID;
    protected String panelIndicator;
    protected String panelEffectiveDate;
    protected String panelTermDate;
    protected String practitionerPhoneNumber;
    protected String practitionerFaxNumber;
    protected String practitionerAddress1;
    protected String practitionerAddress2;
    protected String practitionerAddress3;
    protected String practitionerCityName;
    protected String practitionerStateCd;
    protected String practitionerZip;
    @XmlElement(name = "practitioner4digitZip")
    protected String practitioner4DigitZip;
    protected String practitionerCountyCd;
    protected String practitionerCountyNm;
    protected String practitionerCountryCd;
    protected String practitionerCountryNm;
    protected String practitionerNPI;
    protected String practitionerNPIEfftDate;
    protected String practitionerNPITermDate;
    protected String practitionerTitle;
    protected List<NetworkDetails> networkDetails;
    protected String recordNum;

    /**
     * Gets the value of the practitionerPANRID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerPANRID() {
        return practitionerPANRID;
    }

    /**
     * Sets the value of the practitionerPANRID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerPANRID(String value) {
        this.practitionerPANRID = value;
    }

    /**
     * Gets the value of the practProvID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractProvID() {
        return practProvID;
    }

    /**
     * Sets the value of the practProvID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractProvID(String value) {
        this.practProvID = value;
    }

    /**
     * Gets the value of the practitionerFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerFirstName() {
        return practitionerFirstName;
    }

    /**
     * Sets the value of the practitionerFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerFirstName(String value) {
        this.practitionerFirstName = value;
    }

    /**
     * Gets the value of the practitionerLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerLastName() {
        return practitionerLastName;
    }

    /**
     * Sets the value of the practitionerLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerLastName(String value) {
        this.practitionerLastName = value;
    }

    /**
     * Gets the value of the practitionerDegree property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerDegree() {
        return practitionerDegree;
    }

    /**
     * Sets the value of the practitionerDegree property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerDegree(String value) {
        this.practitionerDegree = value;
    }

    /**
     * Gets the value of the practitionerPrimarySpecialtyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerPrimarySpecialtyCd() {
        return practitionerPrimarySpecialtyCd;
    }

    /**
     * Sets the value of the practitionerPrimarySpecialtyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerPrimarySpecialtyCd(String value) {
        this.practitionerPrimarySpecialtyCd = value;
    }

    /**
     * Gets the value of the practitionerPrimarySpecialtyDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerPrimarySpecialtyDesc() {
        return practitionerPrimarySpecialtyDesc;
    }

    /**
     * Sets the value of the practitionerPrimarySpecialtyDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerPrimarySpecialtyDesc(String value) {
        this.practitionerPrimarySpecialtyDesc = value;
    }

    /**
     * Gets the value of the practitionerSecondarySpecialtyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerSecondarySpecialtyCd() {
        return practitionerSecondarySpecialtyCd;
    }

    /**
     * Sets the value of the practitionerSecondarySpecialtyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerSecondarySpecialtyCd(String value) {
        this.practitionerSecondarySpecialtyCd = value;
    }

    /**
     * Gets the value of the practitionerSecondarySpecialtyDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerSecondarySpecialtyDesc() {
        return practitionerSecondarySpecialtyDesc;
    }

    /**
     * Sets the value of the practitionerSecondarySpecialtyDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerSecondarySpecialtyDesc(String value) {
        this.practitionerSecondarySpecialtyDesc = value;
    }

    /**
     * Gets the value of the panelSegmentName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelSegmentName() {
        return panelSegmentName;
    }

    /**
     * Sets the value of the panelSegmentName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelSegmentName(String value) {
        this.panelSegmentName = value;
    }

    /**
     * Gets the value of the medlPanlPtnrSeg property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMedlPanlPtnrSeg() {
        return medlPanlPtnrSeg;
    }

    /**
     * Sets the value of the medlPanlPtnrSeg property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMedlPanlPtnrSeg(String value) {
        this.medlPanlPtnrSeg = value;
    }

    /**
     * Gets the value of the panelTermReason property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelTermReason() {
        return panelTermReason;
    }

    /**
     * Sets the value of the panelTermReason property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelTermReason(String value) {
        this.panelTermReason = value;
    }

    /**
     * Gets the value of the panelID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelID() {
        return panelID;
    }

    /**
     * Sets the value of the panelID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelID(String value) {
        this.panelID = value;
    }

    /**
     * Gets the value of the panelIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelIndicator() {
        return panelIndicator;
    }

    /**
     * Sets the value of the panelIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelIndicator(String value) {
        this.panelIndicator = value;
    }

    /**
     * Gets the value of the panelEffectiveDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelEffectiveDate() {
        return panelEffectiveDate;
    }

    /**
     * Sets the value of the panelEffectiveDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelEffectiveDate(String value) {
        this.panelEffectiveDate = value;
    }

    /**
     * Gets the value of the panelTermDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPanelTermDate() {
        return panelTermDate;
    }

    /**
     * Sets the value of the panelTermDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPanelTermDate(String value) {
        this.panelTermDate = value;
    }

    /**
     * Gets the value of the practitionerPhoneNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerPhoneNumber() {
        return practitionerPhoneNumber;
    }

    /**
     * Sets the value of the practitionerPhoneNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerPhoneNumber(String value) {
        this.practitionerPhoneNumber = value;
    }

    /**
     * Gets the value of the practitionerFaxNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerFaxNumber() {
        return practitionerFaxNumber;
    }

    /**
     * Sets the value of the practitionerFaxNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerFaxNumber(String value) {
        this.practitionerFaxNumber = value;
    }

    /**
     * Gets the value of the practitionerAddress1 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerAddress1() {
        return practitionerAddress1;
    }

    /**
     * Sets the value of the practitionerAddress1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerAddress1(String value) {
        this.practitionerAddress1 = value;
    }

    /**
     * Gets the value of the practitionerAddress2 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerAddress2() {
        return practitionerAddress2;
    }

    /**
     * Sets the value of the practitionerAddress2 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerAddress2(String value) {
        this.practitionerAddress2 = value;
    }

    /**
     * Gets the value of the practitionerAddress3 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerAddress3() {
        return practitionerAddress3;
    }

    /**
     * Sets the value of the practitionerAddress3 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerAddress3(String value) {
        this.practitionerAddress3 = value;
    }

    /**
     * Gets the value of the practitionerCityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerCityName() {
        return practitionerCityName;
    }

    /**
     * Sets the value of the practitionerCityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerCityName(String value) {
        this.practitionerCityName = value;
    }

    /**
     * Gets the value of the practitionerStateCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerStateCd() {
        return practitionerStateCd;
    }

    /**
     * Sets the value of the practitionerStateCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerStateCd(String value) {
        this.practitionerStateCd = value;
    }

    /**
     * Gets the value of the practitionerZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerZip() {
        return practitionerZip;
    }

    /**
     * Sets the value of the practitionerZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerZip(String value) {
        this.practitionerZip = value;
    }

    /**
     * Gets the value of the practitioner4DigitZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitioner4DigitZip() {
        return practitioner4DigitZip;
    }

    /**
     * Sets the value of the practitioner4DigitZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitioner4DigitZip(String value) {
        this.practitioner4DigitZip = value;
    }

    /**
     * Gets the value of the practitionerCountyCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerCountyCd() {
        return practitionerCountyCd;
    }

    /**
     * Sets the value of the practitionerCountyCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerCountyCd(String value) {
        this.practitionerCountyCd = value;
    }

    /**
     * Gets the value of the practitionerCountyNm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerCountyNm() {
        return practitionerCountyNm;
    }

    /**
     * Sets the value of the practitionerCountyNm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerCountyNm(String value) {
        this.practitionerCountyNm = value;
    }

    /**
     * Gets the value of the practitionerCountryCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerCountryCd() {
        return practitionerCountryCd;
    }

    /**
     * Sets the value of the practitionerCountryCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerCountryCd(String value) {
        this.practitionerCountryCd = value;
    }

    /**
     * Gets the value of the practitionerCountryNm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerCountryNm() {
        return practitionerCountryNm;
    }

    /**
     * Sets the value of the practitionerCountryNm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerCountryNm(String value) {
        this.practitionerCountryNm = value;
    }

    /**
     * Gets the value of the practitionerNPI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerNPI() {
        return practitionerNPI;
    }

    /**
     * Sets the value of the practitionerNPI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerNPI(String value) {
        this.practitionerNPI = value;
    }

    /**
     * Gets the value of the practitionerNPIEfftDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerNPIEfftDate() {
        return practitionerNPIEfftDate;
    }

    /**
     * Sets the value of the practitionerNPIEfftDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerNPIEfftDate(String value) {
        this.practitionerNPIEfftDate = value;
    }

    /**
     * Gets the value of the practitionerNPITermDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerNPITermDate() {
        return practitionerNPITermDate;
    }

    /**
     * Sets the value of the practitionerNPITermDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerNPITermDate(String value) {
        this.practitionerNPITermDate = value;
    }

    /**
     * Gets the value of the practitionerTitle property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPractitionerTitle() {
        return practitionerTitle;
    }

    /**
     * Sets the value of the practitionerTitle property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPractitionerTitle(String value) {
        this.practitionerTitle = value;
    }

    /**
     * Gets the value of the networkDetails property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the networkDetails property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getNetworkDetails().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link NetworkDetails }
     * 
     * 
     */
    public List<NetworkDetails> getNetworkDetails() {
        if (networkDetails == null) {
            networkDetails = new ArrayList<NetworkDetails>();
        }
        return this.networkDetails;
    }

    /**
     * Gets the value of the recordNum property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRecordNum() {
        return recordNum;
    }

    /**
     * Sets the value of the recordNum property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRecordNum(String value) {
        this.recordNum = value;
    }

}
