
var commonWeb = angular.module('commonWebModule', []);

commonWeb.controller('sharecareController', function ($scope, $timeout, $rootScope, $location, $window) {
	var options = {};

	$scope.loader = true;


	var query = window.location.href.split('?')[1];
	console.log(query)
	if (!query) {
		alert('Query Parameters are missing');
	}
	else {
		var vars = query.split('&');
		var finalquery = '';
		$scope.data = {};
		console.log("data is:" + $scope.data);
		for (var i = 0; i < vars.length; i++) {
			var equalIndex = vars[i].indexOf('=');
			var key = encodeURIComponent(decodeURIComponent(vars[i].substring(0, equalIndex)));
			var value = vars[i].substring(equalIndex + 1);

			if (key === 'returnUrl') {
				$scope.returnSCUrl = value;
				$scope.returnurl = decodeURIComponent(value);
				/*if(!($scope.returnurl.indexOf('//www.sharecare.com')>-1)){
					if($scope.returnurl.indexOf('//sharecare.com')>-1){
						$scope.returnurl.replace('//sharecare.com','//www.sharecare.com/')
					}
				}*/

			}
			/*
			if(key === 'NetworkIdentifierCode'){
				$scope.NetworkIdentifierCode = value;
			}*/
			if (key === 'sType') {
				$scope.mode = value;
			}
			if (key === 'isNational') {
				$scope.isNational = ((value === 'Y') || (value == null) || (value === ''));
			}
			if (key === 'secretKey') {
				$scope.SecretKey = value;
			}
			if (key === 'pcpid') {
				alert('inside sharecare pcp');
				$scope.pcpid = value;

			}
			if (key === 'providerType') {
				$scope.ProviderType = value;
			}
			if (key === 'incentivePcpType') {
				$scope.incentivePCPType = decodeURIComponent(value);
			}
			if (key === 'planName') {
				$scope.PlanName = decodeURIComponent(value).replace(/\+/g, ' ');
				if (($scope.PlanName === null) || ($scope.PlanName === "")) {
					$scope.PlanName = "PPO";
				}
			}
			if (key === 'planCode') {
				$scope.PlanCode = decodeURIComponent(value);
				if (($scope.PlanCode === null) || ($scope.PlanCode === "")) {
					$scope.PlanCode = "DC_SP1";
				}
			}
			if (key === 'zipcode') {
				$scope.zipcode = value;
			}
			if (key === 'jurisdiction')
				$scope.Jurisdiction = value;
			if (($scope.Jurisdiction === null) || ($scope.Jurisdiction === "")) {
				$scope.Jurisdiction = "900";
			}
			if (key === 'riskGroup')
				$scope.riskGroup = value;
			if (($scope.riskGroup === null) || ($scope.riskGroup === "")) {
				$scope.riskGroup = "N";
			}
			//sd changes
			if (key === 'providerName') {
				$scope.providerName = value;
			}
			if (key === 'providerID') {
				$scope.providerID = value;

			}
			if (key === 'addressLine1') {
				$scope.addressLine1 = value;
			}
			if (key === 'city') {
				$scope.city = value;
			}
			if (key === 'state') {
				$scope.state = value;
			}
			if (key === 'zip') {
				$scope.zip = value;
			}
			if (key === 'phone') {
				$scope.phone = value;
			}
			if (key === 'specialityName') {
				$scope.specialityName = value;
			}
			if (key === 'pcpOOAInd') {
				$scope.pcpOOAInd = value;
			}
			if (key === 'pcmhpcptype') {
				$scope.pcmhpcptype = value;
			}
			if (key === 'npi') {
				$scope.npi = value;
			}
			/////////////////////
			if (key === 'cdGroup')
				$scope.CDGroup = value;
			if (($scope.CDGroup === null) || ($scope.CDGroup === "")) {
				$scope.CDGroup = "03";
			}
			if (key === 'parameters.mpID') {
				$scope.parametersMpID = value;
			}
			if (key === 'reference.collection') {
				$scope.referenceCollection = value;
			}
			if (key === 'reference.id') {
				$scope.referenceId = value;
			}
			if (key === 'parameters.methods') {
				$scope.parametersMethods = value;
			}
			if (key === 'ava.abortURL') {
				$scope.avaAbortURL = value;
			}
			if (key === 'ava.completeURL') {
				$scope.avaCompleteURL = value;
			}
			$scope.maxResultSize = '25';

		}
	}

	//New SD implementation

	if ($scope.providerID) {
		$scope.loader = false;
		if ($scope.ProviderType === 'PCP') {

			//code is currently commented as we are not receiving pcmh indicators from SD

			// if(($scope.incentivePCPType ==='PCMH' || $scope.incentivePCPType ==='PCMHPlus') && (data.provider.pcmhPlusIndicator === 'N' && data.provider.pcmhIndicator ==='N')) {
			// 	$('#incentivePCP').modal('show');									
			// }
			// /*else if(options.incentivePCPType ==='PCMH' && data.provider.pcmhPlusIndicator === 'Y'){
			// 	$('#incentivePCMH').modal('show');									
			// } */
			// else if($scope.incentivePCPType ==='PCMHPlus' && data.provider.pcmhIndicator === 'Y' &&  data.provider.pcmhPlusIndicator === 'N' ){
			// 	$('#incentivePCMHPlus').modal('show');				
			// } else{
			// 	$scope.redirectToShareCareSD(); 
			// }	
			//$scope.redirectToShareCareSD();

			// var data=$scope.data
			if ($scope.returnurl) {
				//var indVal = $scope.isNational ?'Y':'N';
				var address2 = "";
				// if(data.provider.addressDetail["0"].addressLine2 && data.provider.addressDetail["0"].addressLine2 !== null){			
				// 	 address2 ="findings.selectedProviderAddressLine2= "+ encodeURIComponent(data.provider.addressDetail["0"].addressLine2)+"&";				
				// }
				// var PCP_Type = data.provider.pcmhPlusIndicator == 'Y' ? 'P' : data.provider.pcmhIndicator == 'Y' ? 'Y' : data.provider.nationalProviderIndicator == 'Y' ? 'O' : data.provider.specialityType == 'PCP' ? 'N' : '';
				// if((data.provider.providerName).split(',').length === 3 && (data.provider.providerName).split(',')[2].split(' ').length === 2)
				// 	var PCPDesignation=(((data.provider.providerName).split(','))[2].split(' '))[1]; // Doctor designation
				// else
				// 	var PCPDesignation = ''; // if provider is not dr, provider is group with no designation

				var postbackURL = "findings.selectedProviderFullName=" + encodeURIComponent($scope.providerName).replace(/\(/g, '%28').replace(/\)/g, '%29') + "&" +
					//var postbackURL = "name=" + data.provider.providerName + "&"+
					// "findings.pcpType=" + PCP_Type + "&"+ //some parameters are commented because we are not receiving those parameters from SD
					"findings.selectedProviderId=" + $scope.providerID + "&" +
					"findings.secretKey=" + $scope.SecretKey + "&" +
					// "findings.pcpDesignation=" + PCPDesignation + "&"+
					"findings.selectedProviderAddressLine1=" + $scope.addressLine1 + "&" +

					//"findings.selectedProviderAddressLine2=" + encodeURIComponent(data.provider.addressDetail["0"].addressLine2) + "&"+
					//"pcpaddressLine2=" + data.provider.addressDetail["0"].addressLine2 + "&"+
					"findings.selectedProviderCity=" + $scope.city + "&" +
					"findings.selectedProviderState=" + $scope.state + "&" +
					"findings.selectedProviderZip=" + $scope.zip + "&" +
					"findings.pcpPrimarySpecialty=" + $scope.specialityName + "&" +  //some parameters are commented because we are not receiving those parameters from SD
					// "findings.pcpSecondarySpecialty=" +encodeURIComponent(data.provider.specialities["0"].name) + "&"+
					//"PCPOOAInd=" + encodeURIComponent(data.provider.networkIdentifier)+ "&"+
					"findings.pcpOOAInd=" + $scope.pcpOOAInd + "&" +


					//				"panelId =" + data.provider. + "&"+
					// "findings.npi=" + encodeURIComponent(data.provider.npi) + "&"+
					//"npi=" + data.provider.npi + "&"+
					// "findings.panelId=" + data.provider.medicalPanelID + "&"+
					"findings.timestamp=" + new Date().getTime();
				if (!($scope.returnurl.indexOf('//www.sharecare.com') > -1)) {
					if ($scope.returnurl.indexOf('//sharecare.com') > -1) {
						$scope.returnurl = $scope.returnurl.replace('//sharecare.com', '//www.sharecare.com/')
					}
				}
				var finalURL = '';
				if ($scope.returnurl.indexOf('?') > 0) {
					finalURL = $scope.returnurl + "&" + postbackURL;
				}
				else {
					finalURL = $scope.returnurl + "?" + postbackURL;
				}
				console.log(finalURL);
				//var newURL=decodeURIComponent(finalURL);
				//	window.location.replace(newURL);
				window.location.replace(finalURL);
			}
		}

		if ($scope.ProviderType === 'CCC') {


			if ($scope.returnurl) {
				var country = "";
				// if(data.provider.addressDetail["0"].country && data.provider.addressDetail["0"].country!==null){
				// 	country="findings.country= " + data.provider.addressDetail["0"].country + "&";
				// }
				var address2 = "";
				// if(data.provider.addressDetail["0"].addressLine2 && data.provider.addressDetail["0"].addressLine2 !== null){			
				// 	 address2 ="findings.selectedProviderAddressLine2= "+ encodeURIComponent(data.provider.addressDetail["0"].addressLine2)+"&";				
				// 	}
				var postbackURL = //"name=" + data.provider.providerName + "&"+
					//"PCP_Type=" + data.provider.specialityType + "&"+
					"parameters.methods=" + $scope.parametersMethods + "&" +
					"parameters.mpID=" + $scope.parametersMpID + "&" +
					"reference.collection=" + $scope.referenceCollection + "&" +
					"reference.id=" + $scope.referenceId + "&" +
					"findings.secretKey=" + $scope.SecretKey + "&" +
					"findings.cvsAddressLine1=" + $scope.addressLine1 + "&" +
					"findings.city=" + $scope.city + "&" +
					//"findings.country=" + data.provider.addressDetail["0"].country+"&"+
					"findings.cvsStateCode=" + $scope.state + "&" +
					"findings.cvsZipCode=" + $scope.zip + "&" +
					"findings.phone=" + encodeURIComponent($scope.phone).replace(/\(/g, '%28').replace(/\)/g, '%29') + "&" +
					"findings.nationalProviderIndicator=" + $scope.pcpOOAInd + "&" +  //some parameters are commented because we are not receivng those from SD now.
					"findings.providerId=" + $scope.providerID + "&" +
					"findings.npi=" + encodeURIComponent($scope.npi) + "&" +
					// "findings.npi=" + encodeURIComponent(data.provider.npi) + "&"+ //some parameters are commented because we are not receiving those parameters from SD
					"findings.timestamp=" + new Date().getTime();
				if (!($scope.returnurl.indexOf('//www.sharecare.com') > -1)) {
					if ($scope.returnurl.indexOf('//sharecare.com') > -1) {
						$scope.returnurl = $scope.returnurl.replace('//sharecare.com', '//www.sharecare.com/')
					}
				}
				var finalURL = '';
				if ($scope.returnurl.indexOf('?') > 0) {
					finalURL = $scope.returnurl + "&" + postbackURL;
				}
				else {
					finalURL = $scope.returnurl + "?" + postbackURL;
				}
				console.log("CVS return URL is: ", finalURL);
				$rootScope.cvsReturnURL = finalURL;

				//window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/bluerewards/hawef/cvsinstructions' 
				//window.location.replace(finalURL);
				$scope.showCVSMinute = true;
				var cvsProviderName = "Minuteclinic The Medical Clinic in CVS/Pharmacy";
				var cvsProviderFullDetails = "";
				console.log("$scope.providerID value is", $scope.providerID);
				if ($scope.providerName === null || $scope.providerName === '') {
					cvsProviderFullDetails = cvsProviderName;
				} else {
					if ($scope.providerID === "undefined") {
						cvsProviderFullDetails = decodeURIComponent($scope.providerName);
					} else {
						cvsProviderFullDetails = decodeURIComponent($scope.providerName) + " (" + $scope.providerID + ")";
					}
				}
				console.log("cvs location name: ", cvsProviderFullDetails);
				$scope.CVSObject = {
					providerName: cvsProviderFullDetails,
					addressLine1: decodeURIComponent($scope.addressLine1),
					city: decodeURIComponent($scope.city),
					stateCode: $scope.state,
					zipCode: $scope.zip,
					phone: $scope.phone,
					nationalProviderIndicator: $scope.pcpOOAInd
				};

				//$scope.$apply();

				//old sharecare
				// $scope.showCVSMinute = true;
				// $scope.CVSObject = $scope.data.provider;
				// $scope.$apply()
			}


		}
	}
	function initialize() {
		options.onPageLoad = function () {
			$scope.loader = false;
			$scope.$apply();
		};
		options.onPcpSelected = function (data) {
			$scope.data = data;
			if ($scope.ProviderType === 'PCP') {

				if ((options.incentivePCPType === 'PCMH' || options.incentivePCPType === 'PCMHPlus') && (data.provider.pcmhPlusIndicator === 'N' && data.provider.pcmhIndicator === 'N')) {
					$('#incentivePCP').modal('show');
				}
				/*else if(options.incentivePCPType ==='PCMH' && data.provider.pcmhPlusIndicator === 'Y'){
					$('#incentivePCMH').modal('show');									
				} */
				else if (options.incentivePCPType === 'PCMHPlus' && data.provider.pcmhIndicator === 'Y' && data.provider.pcmhPlusIndicator === 'N') {
					$('#incentivePCMHPlus').modal('show');
				} else {
					$scope.redirectToShareCare();
				}

			}

			if ($scope.ProviderType === 'CCC') {
				if ($scope.returnurl) {
					$scope.returnurl = decodeURIComponent($scope.returnSCUrl);
					var country = "";
					if (data.provider.addressDetail["0"].country && data.provider.addressDetail["0"].country !== null) {
						country = "findings.country= " + data.provider.addressDetail["0"].country + "&";
					}
					var address2 = "";
					if (data.provider.addressDetail["0"].addressLine2 && data.provider.addressDetail["0"].addressLine2 !== null) {
						address2 = "findings.selectedProviderAddressLine2= " + encodeURIComponent(data.provider.addressDetail["0"].addressLine2) + "&";
					}
					var postbackURL = //"name=" + data.provider.providerName + "&"+
						//"PCP_Type=" + data.provider.specialityType + "&"+
						"findings.secretKey=" + $scope.SecretKey + "&" +
						"findings.cvsAddressLine1=" + data.provider.addressDetail["0"].addressLine1 + "&" +
						address2 +
						"findings.city=" + data.provider.addressDetail["0"].city + "&" + country +
						//"findings.country=" + data.provider.addressDetail["0"].country+"&"+
						"findings.cvsStateCode=" + data.provider.addressDetail["0"].stateCode + "&" +
						"findings.cvsZipCode=" + data.provider.addressDetail["0"].zipCode + "&" +
						"findings.phone=" + encodeURIComponent(data.provider.phone).replace(/\(/g, '%28').replace(/\)/g, '%29') + "&" +
						"findings.nationalProviderIndicator=" + data.provider.nationalProviderIndicator + "&" +
						"findings.providerId=" + data.provider.providerID + "&" +
						"findings.npi=" + encodeURIComponent(data.provider.npi) + "&" +
						"findings.timestamp=" + new Date().getTime();

					if (!($scope.returnurl.indexOf('//www.sharecare.com') > -1)) {
						if ($scope.returnurl.indexOf('//sharecare.com') > -1) {
							$scope.returnurl = $scope.returnurl.replace('//sharecare.com', '//www.sharecare.com/')
						}
					}

					var finalURL = '';
					if ($scope.returnurl.indexOf('?') > 0) {
						finalURL = $scope.returnurl + "&" + postbackURL;
					}
					else {
						finalURL = $scope.returnurl + "?" + postbackURL;
					}
					$rootScope.cvsReturnURL = finalURL;

					//window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/bluerewards/hawef/cvsinstructions' 
					//window.location.replace(finalURL);
					$scope.showCVSMinute = true;
					$scope.CVSObject = $scope.data.provider;
					$scope.$apply()
				}
			}
		};
		if (fap) {
			fap.init('sharecareWrapper', options);
		}
		else {
			$scope.loader = false;
			$scope.alert('fap.error.general', 'fap.error.title');
		}
	}
	$scope.goCVSMinuteClinicSearch = function () {
		//$scope.showCVSMinute = false;
		window.history.back();

	}
	$scope.cvsToSharecare = function () {
		if((navigator.userAgent.indexOf('AndroidPortalApp') > -1) || navigator.userAgent.indexOf('iOSPortalApp') > -1){
			var cvsReturnURLNative = $rootScope.cvsReturnURL
			// window.location.href = "https://msita.carefirst.com/mos/index.html#/fadsdpublic/search/sharecare?cvsReturnURLNative="+encodeURIComponent(cvsReturnURLNative);
			window.location.href = "https://member.carefirst.com/mos/index.html#/fadsdpublic/search/sharecare?cvsReturnURLNative="+encodeURIComponent(cvsReturnURLNative);

		}else {
			window.location.href = $rootScope.cvsReturnURL;
		}
	}
	$scope.clinicLocator = function () {
		var link = 'https://www.cvs.com/minuteclinic/clinic-locator';
		$window.open(link);
	};
	$scope.openCVSHawefPDF = function () {
		var pathname = '#/pageindexfull/';
		//var key ="resource.br.actionplan.form";
		var key;
		if ($scope.pcpOOAInd === 'Y') { //pcpooaind added in place of national provider indicator for sapphire digital
			key = "resource.br.public.cvsoutofarea.form";
		} else {
			key = "resource.br.public.cvsinarea.form";
		}
		var link = "/mos/" + pathname + key;
		window.open(link, '_blank');
	}
	$scope.redirectToShareCare = function () {
		var data = $scope.data
		if ($scope.returnurl) {
			$scope.returnurl = decodeURIComponent($scope.returnSCUrl);
			//var indVal = $scope.isNational ?'Y':'N';
			var address2 = "";
			if (data.provider.addressDetail["0"].addressLine2 && data.provider.addressDetail["0"].addressLine2 !== null) {
				address2 = "findings.selectedProviderAddressLine2= " + encodeURIComponent(data.provider.addressDetail["0"].addressLine2) + "&";
			}
			var PCP_Type = data.provider.pcmhPlusIndicator == 'Y' ? 'P' : data.provider.pcmhIndicator == 'Y' ? 'Y' : data.provider.nationalProviderIndicator == 'Y' ? 'O' : data.provider.specialityType == 'PCP' ? 'N' : '';
			if ((data.provider.providerName).split(',').length === 3 && (data.provider.providerName).split(',')[2].split(' ').length === 2)
				var PCPDesignation = (((data.provider.providerName).split(','))[2].split(' '))[1]; // Doctor designation
			else
				var PCPDesignation = ''; // if provider is not dr, provider is group with no designation

			var postbackURL = "findings.selectedProviderFullName=" + encodeURIComponent(data.provider.providerName).replace(/\(/g, '%28').replace(/\)/g, '%29') + "&" +
				//var postbackURL = "name=" + data.provider.providerName + "&"+
				"findings.pcpType=" + PCP_Type + "&" +
				"findings.selectedProviderId=" + data.provider.providerID + "&" +
				"findings.secretKey=" + $scope.SecretKey + "&" +
				"findings.pcpDesignation=" + PCPDesignation + "&" +
				"findings.selectedProviderAddressLine1=" + data.provider.addressDetail["0"].addressLine1 + "&" +
				address2 +
				//"findings.selectedProviderAddressLine2=" + encodeURIComponent(data.provider.addressDetail["0"].addressLine2) + "&"+
				//"pcpaddressLine2=" + data.provider.addressDetail["0"].addressLine2 + "&"+
				"findings.selectedProviderCity=" + data.provider.addressDetail["0"].city + "&" +
				"findings.selectedProviderState=" + data.provider.addressDetail["0"].stateCode + "&" +
				"findings.selectedProviderZip=" + data.provider.addressDetail["0"].zipCode + "&" +
				"findings.pcpPrimarySpecialty=" + encodeURIComponent(data.provider.specialityType) + "&" +
				"findings.pcpSecondarySpecialty=" + encodeURIComponent(data.provider.specialities["0"].name) + "&" +
				//"PCPOOAInd=" + encodeURIComponent(data.provider.networkIdentifier)+ "&"+
				"findings.pcpOOAInd=" + data.provider.nationalProviderIndicator + "&" +
				//"PCPprimaryspecialty=" + data.provider.specialityType+ "&"+
				//"PCPsecondaryspecialty=" +data.provider.specialities["0"].name + "&"+
				//"PCPOOAInd=" +data.provider.networkIdentifier+ "&"+

				//				"panelId =" + data.provider. + "&"+
				"findings.npi=" + encodeURIComponent(data.provider.npi) + "&" +
				//"npi=" + data.provider.npi + "&"+
				"findings.panelId=" + data.provider.medicalPanelID + "&" +
				"findings.timestamp=" + new Date().getTime();
			if (!($scope.returnurl.indexOf('//www.sharecare.com') > -1)) {
				if ($scope.returnurl.indexOf('//sharecare.com') > -1) {
					$scope.returnurl = $scope.returnurl.replace('//sharecare.com', '//www.sharecare.com/')
				}
			}
			var finalURL = '';
			if ($scope.returnurl.indexOf('?') > 0) {
				finalURL = $scope.returnurl + "&" + postbackURL;
			}
			else {
				finalURL = $scope.returnurl + "?" + postbackURL;
			}
			console.log(finalURL);
			//var newURL=decodeURIComponent(finalURL);
			//	window.location.replace(newURL);
			window.location.replace(finalURL);
		}
	}
	//options.initialPlanName = 'CareFirst Network';
	/*if($scope.indicatorFlag ==='PP'){
	options.shareCareShowBRPCMHPlus= true;
	}*/

	options.brPCMHPlusApplicable = false;
	options.shareCareShowBRPCMHPlus = true;
	$scope.jurisdictionForPCMHPlus = false;
	$scope.riskGroupFlag = false;
	$scope.cdgrpFlag = false;

	var jurisdictionArr = ["1999", "1997", "1990", "1510", "1047", "1045", "1043", "1041", "1039", "1037", "1035", "1033", "1031", "1029", "1027", "1025", "1023", "1021", "1019", "1017", "1015", "1013", "1011", "1009", "1005", "1003", "1001"];

	var isAvailable = jurisdictionArr.indexOf($scope.Jurisdiction);
	if (isAvailable != -1)
		$scope.jurisdictionForPCMHPlus = true;

	if ($scope.riskGroup === 'R' || $scope.riskGroup == null)
		$scope.riskGroupFlag = true;

	if ($scope.CDGroup === '02')
		$scope.cdgrpFlag = true;

	if (($scope.jurisdictionForPCMHPlus && $scope.riskGroupFlag) || $scope.cdgrpFlag) {
		options.shareCareShowBRPCMHPlus = false;
	}


	//break;
	/*if ( $scope.mode && $scope.mode === 'D' ){
		options.mode = 'dentalpcp';
		options.initialPlanCode = 'DENT_PP';
		if ( $scope.NetworkIdentifierCode === "1" ){
			options.initialPlanCode = 'PCVA';
			options.initialPlanName = 'DHMO Provider Choice Network';
		}
		else if ( $scope.NetworkIdentifierCode === "2" ){
			options.initialPlanCode = 'TDN';
			options.initialPlanName = 'DHMO 5000s Network';
		}
		else if ( $scope.NetworkIdentifierCode === "3" ){
			options.initialPlanCode = 'CFX';
			options.initialPlanName = 'DHMO 1i Network';
		}

	}*/
	//else {
	if ($scope.ProviderType === 'PCP') {
		options.mode = 'pcp';
	}
	if ($scope.ProviderType === 'CCC') {
		options.mode = 'cvsminuteclinic';
		if (!$scope.isNational) {
			options.noooa = true;
		}
	}
	options.initialPlanCode = $scope.PlanCode;
	options.initialPlanName = $scope.PlanName;
	options.zipCode = $scope.zipcode;
	options.incentivePCPType = $scope.incentivePCPType;
	if ($scope.isNational) {
		options.initialAllowOOAOONPCP = true;
	}
	/*if ( $scope.NetworkIdentifierCode === "1" ){
		options.initialPlanCode = 'DC_CC3';
		options.initialPlanName = 'BlueChoice Network';
	}
	else if ( $scope.NetworkIdentifierCode === "2" ){
		options.initialPlanCode = 'POS11';
		options.initialPlanName = 'Point of Service Network';
	}
	else if ( $scope.NetworkIdentifierCode === "3" ){
		options.initialPlanCode = 'DC_CC5';
		options.initialPlanName = 'BlueChoice Network';
	}*/
	//}


	if ($scope.isNational) {
		options.initialNational = $scope.isNational;
	}


	//New Sapphire Digital Implementation
	// onSuccess($scope.zipcode);

	// function onSuccess(zipcode) {
	// 	getLatLngByZipcode(zipcode, function (locationData) {
	// 		console.log(locationData);
	// 		$scope.redirectToSapphire();

	// 	});
	// }

	redirectToSapphire();

	//Using Google API for converting the zipcode to geolocation parameters
	// function getLatLngByZipcode(zipcode, callback) {
	// 	var geocoder = new google.maps.Geocoder();
	// 	var address = zipcode;

	// 	if (geocoder) {
	// 		geocoder.geocode({
	// 			'address': address
	// 		}, function (results, status) {
	// 			if (status == google.maps.GeocoderStatus.OK) {
	// 				var data = {};
	// 				$scope.latitude = results[0].geometry.location.lat();
	// 				$scope.longitude = results[0].geometry.location.lng();
	// 				data.latitude = results[0].geometry.location.lat();
	// 				data.longitude = results[0].geometry.location.lng();
	// 				callback(data);
	// 			}
	// 			else {
	// 				console.log("google service is unavailable");
	// 				$scope.redirectToSapphire();
	// 			}
	// 		});
	// 	}

	// }

	function redirectToSapphire () {

		if ($scope.ProviderType === 'PCP') {
			// if ($scope.latitude && $scope.longitude) {
			// 	window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/sharecare' + "?"
			// 		+ "providerType=" + $scope.ProviderType
			// 		+ "&" + "secretKey=" + $scope.SecretKey
			// 		+ "&" + "planName=" + $scope.PlanName + "&" + "incentivePcpType=" + $scope.incentivePCPType + "&" + "latitude=" + $scope.latitude + "&" + "longitude=" + $scope.longitude + "&" + "returnSCUrl=" + $scope.returnSCUrl;
			// }
			 //{
				window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/sharecare' + "?"
					+ "providerType=" + $scope.ProviderType
					+ "&" + "secretKey=" + $scope.SecretKey
					+ "&" + "planName=" + $scope.PlanName + "&" + "incentivePcpType=" + $scope.incentivePCPType + "&" + "returnSCUrl=" + $scope.returnSCUrl;
			//}
		}

		else if ($scope.ProviderType === 'CCC') {
			if (!$scope.showCVSMinute) {
				// if ($scope.latitude && $scope.longitude) {
				// 	window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/cvsminuteclinic' + "?"
				// 		+ "providerType=" + $scope.ProviderType
				// 		+ "&" + "secretKey=" + $scope.SecretKey
				// 		+ "&" + "planName=" + $scope.PlanName + "&" + "latitude=" + $scope.latitude + "&" + "longitude=" + $scope.longitude + "&" + "returnSCUrl=" + $scope.returnSCUrl;
				// }
				 //{
					window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/cvsminuteclinic' + "?"
						+ "providerType=" + $scope.ProviderType
						+ "&" + "secretKey=" + $scope.SecretKey
						+ "&" + "planName=" + $scope.PlanName + "&" + "returnSCUrl=" + $scope.returnSCUrl;
				//}
			}
		}
	}

	//Earlier FAD functionality
	/*var fapjsLoc = window.location.origin+'/fds/public/fap.js';
	
	$.getScript(fapjsLoc).done(function( script, textStatus ) {
		initialize ();
	})
	.fail(function( jqxhr, settings, exception ) {
		$scope.alert('fap.error.general','fap.error.title');
		$scope.loader = false;
	});*/

	//New SD Implementation
	$scope.openExternalLink = function (url) {
		window.open(url, '_blank');
	};

	$scope.backButton = function () {
		window.history.go(-1);
	};

	$scope.print = function () {
		window.print();
	};

	$scope.setFontSize = function (size) {
		if (fap) {
			fap.sendEvent('sharecareWrapper', 'textSize', { data: size });
		}
	};
});