import { browser, by, element } from 'protractor';
import { AppPage } from './app.po';
import * as axe from 'axe-core';


describe('core App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect('Welcome to app!').toEqual('Welcome to app!');
  });

   it('should have no accessibility violations', function(done) {
     axe.run(function(err, results) {
       if (err) {
         throw err;
       }
       expect(results.violations.length).toBe(0);
       console.log(results);
     });
    // browser.executeScript(axe.source);
    //  // Run A11Y tests in the browsers event loop.
    //  browser.executeAsyncScript((resolve: any) => {
    //    return new Promise<axe.AxeResults>(res => {
    //      axe.a11yCheck(document, {}, resolve);
    //    });
    //  }).then((results: any) => {
    //   if (results.violations.length > 0) {
    //     console.log(results.violations);
    //   }
    //    expect(results.violations.length).toBe(0);
    //    done();
    //  });
     });

});
