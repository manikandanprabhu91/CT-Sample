import { securedUrls } from './urls/secured-urls';
import { publicUrls } from './urls/public-urls';

export const environment: any = {
  name: 'prod',
  production: false,
  containerId: 'GTM-TL7LXNC',
  propertyID: 'UA-75986060-8',
  applicationRoot: '/selfservice/es',
  serviceSecuredURLs: securedUrls,
  servicePublicURLs: publicUrls,
};
