import { SearchMember } from "./searchmember";

describe('SearchMember', ()=> {
    it('should create an instance', ()=> {
        expect(new SearchMember()).toBeTruthy();
    });
});