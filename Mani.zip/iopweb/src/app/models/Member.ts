export class Member {
    memberId: string;
    firstname: string;
    lastname: string;
    // email: string;
    // subject: string;
    lob: string;
    dob: string;
}