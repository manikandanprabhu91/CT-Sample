export class SearchMember {
    
    firstname: string;
    lastname: string;
    email: string;
    
    public constructor(init?: Partial<SearchMember>) {
        Object.assign(this, init);
    }
}