import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {SearchMemberComponent} from './search-personal-repo/search-member/search-member.component';
import {SearchMemberListComponent} from './search-personal-repo/search-member-list/search-member-list.component';
import { SearchPersonalRepoComponent } from './search-personal-repo/search-personal-repo.component';
import { ViewLinkMemberComponent } from './search-personal-repo/view-link-member/view-link-member.component';
import { SearchAddMemberComponent } from './search-personal-repo/search-add-member/search-add-member.component';



const routes: Routes = [
  { path: '',   redirectTo: 'landing', pathMatch: 'full' },
  { path: 'landing',   component: SearchPersonalRepoComponent},
  { path: 'linkmember',   component: ViewLinkMemberComponent},
  { path: 'searchmember',   component: SearchAddMemberComponent},
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
