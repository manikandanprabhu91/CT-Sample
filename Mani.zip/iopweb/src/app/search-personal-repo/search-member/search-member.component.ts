import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Member } from 'app/models/Member';
import { SearchMember } from 'app/models/searchmember';
import { SearchPersonalServiceService } from 'app/search-personal-service.service';

@Component({
  selector: 'app-search-member',
  templateUrl: './search-member.component.html',
  styleUrls: ['./search-member.component.scss']
})
export class SearchMemberComponent implements OnInit {

  private searchmember: SearchMember ;

  member: Member[];

 
  @Output() searchmemberObject = new EventEmitter();


  searchForm = new FormGroup({
    firstname: new FormControl(''),
    lastname: new FormControl(''),
    email: new FormControl('')
  })



  constructor(private personalRepoService: SearchPersonalServiceService) { }

  ngOnInit() {

  }

  searchFormSubmit(): void {
    this.searchmemberObject.emit(this.searchForm.value);
  }

}
