import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchPersonalRepoComponent } from './search-personal-repo.component';

describe('SearchPersonalRepoComponent', () => {
  let component: SearchPersonalRepoComponent;
  let fixture: ComponentFixture<SearchPersonalRepoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchPersonalRepoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPersonalRepoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
