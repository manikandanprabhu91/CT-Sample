import { Component, Input, OnInit } from '@angular/core';
import { Member } from 'app/models/Member';


@Component({
  selector: 'app-search-member-list',
  templateUrl: './search-member-list.component.html',
  styleUrls: ['./search-member-list.component.scss']
})
export class SearchMemberListComponent implements OnInit {

  @Input() memberList: Member[];


  

  
  constructor() { }

  ngOnInit() {
  }

}
