import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMemberListComponent } from './search-member-list.component';

describe('SearchMemberListComponent', () => {
  let component: SearchMemberListComponent;
  let fixture: ComponentFixture<SearchMemberListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchMemberListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchMemberListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
