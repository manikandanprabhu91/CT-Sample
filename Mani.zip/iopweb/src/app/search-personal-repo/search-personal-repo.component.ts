import { Component, Input, OnInit } from '@angular/core';
import { Member } from 'app/models/Member';
import { SearchMember } from 'app/models/searchmember';
import { SearchPersonalServiceService } from 'app/search-personal-service.service';
import { UserSessionService } from 'app/user-session.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-search-personal-repo',
  templateUrl: './search-personal-repo.component.html',
  styleUrls: ['./search-personal-repo.component.scss']
})
export class SearchPersonalRepoComponent implements OnInit {

  verifyForm: FormGroup;
  member: Member[];
  contactType: any;
  contactValue: any;
  token: any;
  tokenError: boolean = false;

  constructor(private personalRepoService: SearchPersonalServiceService,
    private route: ActivatedRoute,
    private session: UserSessionService,
    private fb: FormBuilder) { }

  createFormData() {
    this.verifyForm = this.fb.group({
      token: ['',
        [
          Validators.required,
          Validators.minLength(6)
        ]]
    }
    );
  }

  ngOnInit() {

    this.route.queryParams
      .subscribe(params => {
        let zenv = 'pit';

        if (params.type) {
          this.contactType = params.type;
        }

        if (params.value) {
          this.contactValue = params.value;
        }

        if (params.zenv) {
          zenv = params.zenv;
        }
        this.session.setLocalStorageItem('zenv', zenv);
        this.session.setSession('zenv', zenv);
      });

    //southbound token generation
    // this.personalRepoService.getToken().subscribe((res: any) => {
    //   this.token = res.access_token;
    //   this.sendCode(); //send security code on load of iframe
    // });
  }

  getSearchMemberList(searchMemberReqObj) {
    console.log(searchMemberReqObj);


  }

  //To get the latest token if it is expired
  refreshToken() {
    // this.personalRepoService.getToken().subscribe((res: any) => {
    //   this.token = res.access_token;
    // });
  }

  sendCode() {
    this.tokenError = false;
    if (this.contactType !== undefined || this.contactValue !== undefined) {
      let reqBody = {
        action: 'SEND',
        contactType: this.contactType,
        contactValue: this.contactValue,
        selfServiceFlow: "REGISTRATION"
      };
      if (this.token) {
        // this.personalRepoService.sendAndVerifyToken(reqBody, this.token).subscribe((data: any) => {
        //   console.log(data, 'send security code to email');
        //   if (data.success === false) {
        //   }
        // }, (error) => {
        // })
      }
    } else {
      console.log("Contact details not received from Zipari");
    }
  }

}
