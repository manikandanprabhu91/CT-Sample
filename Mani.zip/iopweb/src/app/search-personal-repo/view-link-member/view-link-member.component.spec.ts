import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewLinkMemberComponent } from './view-link-member.component';

describe('ViewLinkMemberComponent', () => {
  let component: ViewLinkMemberComponent;
  let fixture: ComponentFixture<ViewLinkMemberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewLinkMemberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewLinkMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
