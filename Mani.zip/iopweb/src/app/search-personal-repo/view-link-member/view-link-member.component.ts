import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Member } from 'app/models/Member';
import { SearchPersonalServiceService } from 'app/search-personal-service.service';
// import {MatPaginator} from '@angular/material/paginator';
// import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-view-link-member',
  templateUrl: './view-link-member.component.html',
  styleUrls: ['./view-link-member.component.scss']
})
export class ViewLinkMemberComponent implements OnInit {

  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  // dataSource = new MatTableDataSource<Member[]>();

  
  totalMember: any;
  members: any;
  token: any;
  memberdata:any=Member;
  lobs = ['VA Exchane', 'UMMS', 'DSNP', 'MADP', 'DC Medicated'];
  isEnrollment: boolean=false;
  isDiagCd: boolean=false;
  isProcedureCd: boolean=false;
  isMentalHealth: boolean=false;
  isBenefitInfo: boolean=false;
  isHivStatus: boolean=false;
  isHClinicalMgnt: boolean=false;
  isClaimSvc: boolean=false;
  isSubstanceInfo: boolean=false;


  constructor(private searchService:SearchPersonalServiceService) { }

  viweLinkForm = new FormGroup({
    subscriperId: new FormControl(''),
    firstname: new FormControl(''),
    lastname: new FormControl(''),
    dob: new FormControl(''),
    lob: new FormControl('')
  })



  ngOnInit() {
    this.getLinkedMember();
  }

  
  public getLinkedMember() {
    this.token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ6V3ZuZzNIWTVnUlV5WkplMzhFMSIsImF1ZCI6InN5c3RlbSIsImp0byI6IkFDWkxpYnlQdnJNWnJUYk5qMTVvNVZOT1NSZW4iLCJwcm9maWxlVHlwZSI6InN5c3RlbSIsInByb2ZpbGVJZCI6Ijc3ZjZkMTEyLTljMjQtNDQ3Mi05ZDk1LWY1ZGI2MDY0MmRkNyIsImlzcyI6ImFwaS1kZXZhLmNhcmVmaXJzdC5jb20iLCJjZmFwaWtleSI6InpXdm5nM0hZNWdSVXlaSmUzOEUxIiwiZXhwIjoxNjIwNzUwMTkyLCJpYXQiOjE2MjA3NDI5OTIsImp0aSI6ImQ3OTU3YjU5LWUxYWMtNDNiMS1iNGNmLTQ3ZTRiZDFkZWIzNyJ9.PxR19c5QcdUdYX_e_BitCwm5xFZ_NDMW7P_dn6VWvuRhTxhSixknHawbx9FBebmwyuuRm39aPz705snle23buWcBjGWsfkAX0bCC00L3WR-dhGy1U00-EboWpu2e-HhbY0aS0fsuUaWUGcgnP5kve_zlBjU7ESivjrkTcw109g5aB81Kd_v2kikRDsb_bB1uK71KnDvDcdXTG3Vcbng77XjE6GFQb4LNxbJLzganLhpQtPyX8I-sY7ofROIDpZzkH8Q0GDnj1Wxw1F5BzMvLEnw1c0hQPQEYmx_SGDYstSaElGCVkwjxE7ZmCJRYQJA4f40oIVuduSwIZXKCKgueEg';
    // this.searchService.getLinkedMembers(this.token, ).subscribe((res: any) => {
    //   this.totalMember = res.count;
    //   this.members = res.member;
    //   console.log("Member Search Response :::::::::: " +this.totalMember);
    // }
      
    // )
  }

  // public viewLinkFormSubmit(): void {
  //   console.log("Test:::::::::::::")
  // }

}
