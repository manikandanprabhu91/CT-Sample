import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Member } from 'app/models/Member';
import { SearchPersonalServiceService } from 'app/search-personal-service.service';



@Component({
  selector: 'app-search-add-member',
  templateUrl: './search-add-member.component.html',
  styleUrls: ['./search-add-member.component.scss']
})
export class SearchAddMemberComponent implements OnInit {

  totalMember: any;
  members: any;
  token: any;
  memberdata:any=Member;
  lobs = [{id:'060', name:'VA Exchane'}, {id:'060', name:'UMMS'}, {id:'060', name:'DSNP'}, 
  {id:'060', name:'MADP'}, {id:'060', name:'DC Medicated'}];
  memberSearchUrl: string;
 
  constructor(private searchService:SearchPersonalServiceService) { }

  viweLinkForm = new FormGroup({
    subscriperId: new FormControl(''),
    firstname: new FormControl(''),
    lastname: new FormControl(''),
    dob: new FormControl(''),
    lobName: new FormControl('')
  })
 
  ngOnInit() {

    this.searchService.getToken().subscribe((res: any) => {
      this.token = res.access_token;
     });

  }

  public getLinkedMembers() {
    console.log("=>>>>>>>>>>>>>>  Dropdown Value =>>>>>>>>>>>>>>>> "+this.viweLinkForm.get('lobName').value);
    if(this.viweLinkForm.value.subscriperId != null || this.viweLinkForm.value.subscriperId != "" || this.viweLinkForm.value.subscriperId != 'undefined')
      this.memberSearchUrl = "?subscriberId="+this.viweLinkForm.value.subscriperId;
    if(this.viweLinkForm.value.firstname != "")
      this.memberSearchUrl += "&firstName="+this.viweLinkForm.value.firstname;
    if(this.viweLinkForm.value.lastname != "")
      this.memberSearchUrl += "&lastName="+this.viweLinkForm.value.lastname;
    if(this.viweLinkForm.value.dob != "")
      this.memberSearchUrl += "&dateofBirth="+this.viweLinkForm.value.dob;
    if(this.viweLinkForm.value.lobName != "")
      this.memberSearchUrl += "&enrollmentSystemCodes="+this.viweLinkForm.value.lobName;
    this.searchService.getLinkedMembers(this.token, this.memberSearchUrl).subscribe((res: any) => {
      this.totalMember = res.count;
      this.members = res.member;
      console.log("Member Search Response :::::::::: " +this.totalMember);
    }
      
    )
  }

 

  public viewLinkFormSubmit(): void {
    console.log("Test:::::::::::::")
  }

  

}
