import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchAddMemberComponent } from './search-add-member.component';

describe('SearchAddMemberComponent', () => {
  let component: SearchAddMemberComponent;
  let fixture: ComponentFixture<SearchAddMemberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchAddMemberComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAddMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
