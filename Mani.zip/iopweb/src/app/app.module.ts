import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SearchPersonalRepoComponent } from './search-personal-repo/search-personal-repo.component';
import { SearchMemberComponent } from './search-personal-repo/search-member/search-member.component';
import { SearchMemberListComponent } from './search-personal-repo/search-member-list/search-member-list.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SearchPersonalServiceService } from './search-personal-service.service';
import { HttpClientModule } from '@angular/common/http';
import { UserSessionService } from './user-session.service';
import { CookieService } from 'ngx-cookie-service';
import { ViewLinkMemberComponent } from './search-personal-repo/view-link-member/view-link-member.component';

import { MatTableModule } from '@angular/material/table'
import { SearchAddMemberComponent } from './search-personal-repo/search-add-member/search-add-member.component';

export function getLocalStorage() {
  return typeof window !== 'undefined' ? window.localStorage : null;
}

@NgModule({
  declarations: [
    AppComponent,
    SearchPersonalRepoComponent,
    SearchMemberComponent,
    SearchMemberListComponent,
    ViewLinkMemberComponent,
    SearchAddMemberComponent
    ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule
  ],
  providers: [SearchPersonalServiceService, UserSessionService, CookieService,
    { provide: 'LOCALSTORAGE', useFactory: getLocalStorage }],
  bootstrap: [AppComponent]
})
export class AppModule { }
