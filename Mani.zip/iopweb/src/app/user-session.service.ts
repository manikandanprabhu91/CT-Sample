import { Injectable } from '@angular/core';
import { Router, Event } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Injectable()
export class UserSessionService {


  private cookieNames = new Set<string>(); // used for tracking deletion purpose only
  private localStorageItemNames = new Set<string>(); // used for tracking deletion purpose only
  private sessionData = new Map<string, any>();

  // the 3rd parameter gives an easy way for unit testing
  constructor(
    private cookieService: CookieService
    // @Inject('LOCALSTORAGE') private localStorage: any
  ) {}


  clearData() {
    this.cookieNames.forEach((value, key) => {
      this.cookieService.delete(key);
    });
    this.localStorageItemNames.forEach((value, key) => {
      // this.localStorage.removeItem(key);
    });

    // reset
    this.localStorageItemNames = new Set<string>();
    this.cookieNames = new Set<string>();
    this.sessionData = new Map<string, any>();
  }

  setCookie(name: string, value: string) {
    if (name && value) {
      this.cookieNames.add(name);
      this.cookieService.set(name, value);
    }
  }

  getCookie(name): string {
    return this.cookieService.get(name);
  }

  deleteCookie(key:string) {
    if (key) {
      this.cookieService.delete(key);
    }
  }

  setLocalStorageItem(key: string, value, options?) {
    // option to persist so that the item
    // will not be removed even on clearData()
    if (!(options && options.persist)) {
      this.localStorageItemNames.add(key);
    }
    // this.localStorage.setItem(key, value);
  }

  getLocalStorageItem(key) {
    // return this.localStorage.getItem(key);
  }

  removeLocalStorageItem(key) {
    // this.localStorage.removeItem(key);
    delete this.localStorageItemNames[key];
  }

  setSession(name: string, value: Object) {
    // this.sessionData[name] = value;
  }

  // Save data in memory only, will be disappear if user refresh browser.
  getSession(name: string): Object {
    return this.sessionData[name];
  } 

}
