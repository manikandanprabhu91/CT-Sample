import { TestBed, inject } from '@angular/core/testing';

import { SearchPersonalServiceService } from './search-personal-service.service';

describe('SearchPersonalServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SearchPersonalServiceService]
    });
  });

  it('should be created', inject([SearchPersonalServiceService], (service: SearchPersonalServiceService) => {
    expect(service).toBeTruthy();
  }));
});
