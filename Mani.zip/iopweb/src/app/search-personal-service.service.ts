import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { SearchMember } from './models/searchmember';
import { Member } from './models/Member';
import { UserSessionService } from './user-session.service';

@Injectable()
export class SearchPersonalServiceService {

  private endpointUrl: string;

  private tokenUrl: string;
  private memberUrl: string;

  constructor(private httpClient: HttpClient,private session: UserSessionService) { 
    this.endpointUrl="https://api-deva.carefirst.com/v1/cf-membersearch";
    this.tokenUrl = "https://api-deva.carefirst.com/v1/oauth/token";
  }

  getToken() {
    let headers = new HttpHeaders({
      // 'Content-Type': 'application/x-www-form-urlencoded',
      // 'NAMEOFCAR': 'TESLA3'
    });
    const clienId = this.getClientID();
    const body = new HttpParams()
    .set('grant_type', 'client_credentials')
    .set('client_id', 'zWvng3HY5gRUyZJe38E1')
    .set('client_secret', 'xCJlaOsr1P6fJefD25g4')
    return this.httpClient.post(this.tokenUrl, body.toString(), {headers: new HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')});
   
  }


  public getLinkedMembers(token: any, memberSearchUrl: string): Observable<Object> {
    return this.httpClient.get<Object>(this.endpointUrl+memberSearchUrl, this.getAuthorizationToken(token));
  }

  public getAuthorizationToken(token: any) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
      
    });
    let options = {
      headers: headers
    };

    return options;
  }

  public getClientID() {
    // const env = this.util.getEnvName();
    const env = 'dev';
    // const zenv = this.session.getLocalStorageItem('zenv');
    let client_id;

    if (env === 'dev') {
      client_id = 'XhlvDhSl7MdhEkTaqHJK';
    } else if (env === 'tt') {
      // if (zenv && zenv === 'sit') {
      //   client_id = 'Yq0MjE64lfAxeGz4j7xv';
      // } else {
      //   client_id = 'LBaZEihmkv4JpZeMSDdf';
      // }
    } else if (env === 'uat') {
      client_id = 'LBaZEihmkv4JpZeMSDdf';
    } else {
      client_id = 'LBaZEihmkv4JpZeMSDdf';
    }
    return client_id;
  }

  sendAndVerifyToken(body, token) {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + token
    });
    let options = {
      headers: headers
    };
    return '';
    // return this.httpClient.post(this.getAbsoluteURL('/v1/cf-usrselfhelp/memberSelfHelp/securityTokens/', 'nexus'), body, options);
  }




  public getAbsoluteURL(url: string, portal) {
    let baseUrl;
    let targetURL;
    if (portal == 'nexus') {
      if (window.location.hostname.toString().indexOf('tt') !== -1) {
        baseUrl = 'https://api-pit.carefirst.com';
      }
      else if (window.location.hostname.toString().indexOf('uat') !== -1) {
        baseUrl = 'https://api-uat.carefirst.com';
      }
      else {
        baseUrl = 'https://api.carefirst.com'; //prod endpoint url
        // baseUrl = 'https://api-pit.carefirst.com'; //to test in local
      }
    } else {
      if (window.location.hostname.toString().indexOf('tt') !== -1) {
        baseUrl = 'https://membertt.carefirst.com';
      }
      else if (window.location.hostname.toString().indexOf('uat') !== -1) {
        baseUrl = 'https://memberuat.carefirst.com';
      }
      else {
        baseUrl = 'https://member.carefirst.com'; //prod endpoint url
        // baseUrl = 'https://membertt.carefirst.com'; //to test in local
      }
    }

    targetURL = baseUrl;


    // if the url is already absolute just return it
    if (url.includes('http')) {
      return url;
    } else {
      return targetURL + url;
    }
  }
  
}
