var fap = {};

String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
};
String.prototype.startsWith = function (prefix){
    return this.slice(0, prefix.length) === prefix;
};
fap.sendEvent = function(div, event, data){
	if ( div && typeof event === 'string' && data ){
		var iframeid = div+'_iframe';
		var elem = document.getElementById(iframeid);
		if ( elem ){
			elem.contentWindow.postMessage("[fapEvent]"+JSON.stringify({event:event,data:data}),window.location.origin); // in sit env
			// elem.contentWindow.postMessage("[fapEvent]"+JSON.stringify({event:event,data:data}),'http://localhost:1337'); // in dev env
			
		}
	}
};

fap.event = false;

fap.receiveMessageJ = function(e){
	var data = e.originalEvent;
	return fap.receiveMessage(data);
};


fap.receiveMessage = function(event)
{
	var origin = event.origin || event.originalEvent.origin;
	if ( event.data.startsWith('[fapEvent]') ){
		// Parsing Broadcast
		var data = JSON.parse(event.data.substring(10));
		if ( data.event === 'handShake' && !fap.newiframe._init ){
			fap.newiframe._init = true;
			fap.sendMessage({event:'init',
				div:fap.div,
				data:{
					options:fap.options
				}
			});
		}
		if ( data.event === 'internalScrollTop'){
			fap.scrollTop = window.scrollY;
			window.scroll(0,0);
			
		}
		if ( data.event === 'internalScrollReturn'){
			if ( fap.scrollTop !== null ){
				window.scroll(0,fap.scrollTop);
				fap.scrollTop = null;
			}
		}
		
		if ( data.event === 'internalMobileToolbar'){
			
			var setIndex = function( index, providers ){
				
				$('#mobilePrevious').css('opacity','1');
				$('#mobileNext').css('opacity','1');
				
				if ( index <= 0 ){
					$('#mobilePrevious').css('opacity','0.3');
				}
				
				if ( index >= providers - 1 ){
					$('#mobileNext').css('opacity','0.3');
				}
			};
			
			var setScrollTopIcon = function(){
				 var offset = 500;
				 var scroll_top_duration = 700;
				 var offset_opacity;
				 $back_to_top = $('.cd-top');
				//hide or show the "back to top" link
				$(window).scroll(function(){
					( $(this).scrollTop() > offset ) ? $back_to_top.addClass('cd-is-visible') : $back_to_top.removeClass('cd-is-visible cd-fade-out');
					if( $(this).scrollTop() > offset_opacity ) { 
						$back_to_top.addClass('cd-fade-out');
					}
				});

				//smooth scroll to top
				$back_to_top.on('click', function(event){
					event.preventDefault();
					$('body,html').animate({
						scrollTop: 0 ,
					 	}, scroll_top_duration
					);
				});	
				};
			
			if ( data.data.page === 'result' ){
				$("#"+fap.divid).show();
				$('.mobile-toolbar-bottom .detailPage').hide();
				$('.mobile-toolbar-bottom .resultPage').show();
				if(data.data.hideFilter){
					$('.mobile-toolbar-bottom #mobileFilter').hide();
				}
				else if(data.data.filterTextDisplay){
					$("#mobileFilterText").text("Filter");
				}else if(data.data.sortTextDisplay){
					$("#mobileFilterText").text("Sort");
					$('.mobile-toolbar-bottom #mobileFilter').hide();
				}
				else {
					$("#mobileFilterText").text("Filter / Sort");
				}
				setScrollTopIcon();
			}
			else if ( data.data.page === 'detail' ){
				$("#"+fap.divid).show();
				$('.mobile-toolbar-bottom .resultPage').hide();
				$('.mobile-toolbar-bottom .detailPage').show();
				fap.detailPageProviders = data.data.providers;
				setIndex( data.data.info, fap.detailPageProviders );
			}
			else if(data.data.page === 'viewOnline'){
				if(data.data.hideFilter){
					$('.mobile-toolbar-bottom #mobileFilter').hide();
				}
			}
			else if ( data.data.page === 'else' ){
				$("#"+fap.divid).hide();
			}
			if ( data.data.action === 'index' ){
				setIndex( data.data.info, fap.detailPageProviders );
			}
		}
		
		
		if ( typeof data.event === 'string' && data.div === fap.div ){
			// Event Handling
			var onEvent = 'on'+data.event.capitalize();
			if ( typeof fap.options[onEvent] === 'function' ){
				fap.options[onEvent](data.data);
			}
		}
	}
};
fap.sendMessage = function(event){
	var retryi = 0;
	var retry = setInterval(function(){
		if ( fap.elem && fap.elem.contentWindow ){
			fap.elem.contentWindow.postMessage("[fapEvent]"+JSON.stringify(event),window.location.origin);
			if ( retry ){
				clearInterval( retry );
			}
		}
		else {
			retryi ++;
			if ( retryi > 5 ){
				clearInterval( retry );
			}
		}
	},100);
};

fap.toolbar = function(url){
	$("#"+fap.divid).load(url,function(){
		$("#"+fap.divid).hide();
		
		var send = function(action){
			fap.sendMessage({event:'internalMobileToolbar',
				div:fap.div,
				data:{
					action:action
				}});
		};
		
		$('.mobile-toolbar-bottom #mobileFilter').click(function(){
			send('filter');
		});
		$('.mobile-toolbar-bottom #mobileMap').click(function(){
			send('map');
		});
		$('.mobile-toolbar-bottom #mobilePrevious').click(function(){
			send('previous');
		});
		$('.mobile-toolbar-bottom #mobileNext').click(function(){
			send('next');
		});
		$('.mobile-toolbar-bottom #mobileStartover').click(function(){
			send('startover');
		});
		/*$('.mobile-toolbar-bottom #mobileBacktoresult').click(function(){
			send('back');
		});*/
	});
};

fap.getUrlVars = function()
{
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
    }
    return vars;
}

fap.destroy = function(div){
	var iframe = document.getElementById(div+'_iframe');
	iframe.src = 'about:blank';	
	iframe.contentWindow.document.innerHTML = '';
	
	var myNode = document.getElementById(div);
	while (myNode.firstChild) {
	    myNode.removeChild(myNode.firstChild);
	}
}
fap.init = function(div, options){
	fap.div = div;
	fap.scrollTop = null;
	fap.options = options;
	var elem;
	var purehash = window.location.hash.split('?')[0];

	options.referer = [window.location.protocol, '//', window.location.host, window.location.pathname, purehash].join('');

	console.log("options.referer value is "+ options.referer);
	console.log(window.location.protocol+"---"+window.location.host+"---"+window.location.pathname+"---"+purehash);
	//options.referer = [window.location.protocol, '//', window.location.host, window.location.pathname, purehash].join('');
	options.providerid = fap.getUrlVars()['providerid'];
	options.query = fap.getUrlVars()['query'];
	options.pdf = fap.getUrlVars()['pdf'];
	
	// console.log("Hems in fap js");
	setTimeout(function(){
		elem = document.getElementById(div);
		// console.log(elem);
		while (elem.firstChild) {
			elem.removeChild(elem.firstChild);
		}
		
		if ( elem.tagName.toLowerCase() === 'iframe'){
			
		}
		else if ( elem.tagName.toLowerCase() !== 'iframe'){
			var newiframe = document.createElement("IFRAME");
			elem.appendChild(newiframe);
			fap.iframeid = fap.div+'_iframe';
			fap.newiframe = newiframe;
			fap.newiframe._init = false;
			newiframe.setAttribute("id",fap.iframeid);
			newiframe.style.width="100%";
			newiframe.style.border="none";
			
			var newdiv = document.createElement("DIV");
			elem.appendChild(newdiv);
			fap.divid =  fap.div+'_div';
			newdiv.setAttribute("id", fap.divid);
			
			
			elem = newiframe;
			
		}
		
		fap.elem = elem;
		if ( elem ){
			//if ( elem.contentWindow ){
			//	elem.contentWindow.location.reload();
			//}
			var path = '/fds/';
			
			if ( options.path ){
				path = options.path;
			}
			elem.src = path + 'index.html';	
			fap.toolbar(path+'/public/mobile-toolbar.html');
			setAutoHeight();
		}
	//	console.log("Options by Sheetal "+ json.stringify(options));
		
	},50);
	
	/**
	 * Get Document Height
	 */
	function getDocHeight(doc) {
	    var D = doc;
	    if ( D.body ){ 
	    	return Math.max( D.body.clientHeight );
	    }
	    return 0;
	}
	var autoHeight = function(){	
		if ( elem && elem.contentWindow && elem.contentWindow.document ){
			var canvas = elem.contentWindow.document;
			if ( canvas ){ 
				var height = getDocHeight(canvas);
				elem.style.height = height+'px';
				elem.style.background = '#FFFFFF';
				if ( canvas.body ){   
					canvas.body.style.overflow = 'hidden';
				}
			}
		}
	};
	var interval = null;
	var setAutoHeight = function(){
		var retryi = 0;
		var retry = setInterval(function(){
			if ( elem && elem.contentWindow ){
				if ( elem && elem.contentWindow && elem.contentWindow.document ){
					var canvas = elem.contentWindow.document.getElementById('fapApplicationBody');
					if ( canvas ){ 
						elem.style.overflow = 'hidden';
					}
				}
				if ( retry ){
					clearInterval( retry );
				}
			}
			else {
				retryi ++;
				if ( retryi > 5 ){
					clearInterval( retry );
				}
			}
		},1000);		
		if ( interval ){
			clearInterval( interval );
		}
		interval = setInterval( autoHeight, 100 );
	};
	
	//if ( !fap.event ){
	
	$(window).off("message.fap");
	$(window).on("message.fap", fap.receiveMessageJ);
	
	//window.removeEventListener("message", fap.receiveMessage);
	//window.addEventListener("message", fap.receiveMessage, false);
		//fap.event = true;
	//}
};


