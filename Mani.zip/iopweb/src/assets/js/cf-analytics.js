window.dataLayer = window.dataLayer || [{
    'SBU': 'default',    	// can be business type small or medium
    'ACA': 'default',    	// user flag type value
    'userType': 'default',   // can be pre active or active
    'planType': 'default',   // product type
    'application': 'default',		//web, iOS, Android
    'isMemberInsured': 'default',	// If a user is has Medical coverage or not
    'loggedIn': 'false',     	// can be true or false
    'insuranceType': 'default',      // e.g. HMO, PPO etc.
    'relationshipCode': 'default', 	// Subscriber/Spouse/Dependent
    'ageRange': 'default',			// age range
    'accountID': 'default',     		// Single employer group id
    'enrollmentSystem': 'default',	// 123
    'riskGroupIndicator': 'default', // TRUE for risk groups false for non groups
    'jurisdiction': 'default',		// e.g. MD
    'gender': 'default',        		// Male/Female
    'GUID': 'default',		// sessionID
    'channel': 'none',
    'channelType': 'direct',
    'campaignID': 'none',
    'subscriberID': 'default',
    'personID': 'default',
    'impersonation': 'default',
    'GroupID': 'default',
    'SourceApplication': 'MemberWebPostLogin',
    'timeStamp': 'default',
    'blueRewardsMember': 'default', // If the member is blue rewards member - Y, else N
    'blueRewardMemberStatus': 'default', // can be NOT_STARTED/PENDING/COMPLETED
    'accountName': 'default',   // account name
    'groupName': 'default'      // group name
}];

var propertyID = 'UA-75986060-8'; 	//non Prod
var containerID = 'GTM-TL7LXNC';//Default test code
var host = window.location.hostname;
if (location.protocol === "http:" || location.protocol === "https:") {		// Browser environment
    if (host.indexOf("member.carefirst.com") !== -1) {
        containerID = 'GTM-WV6QZNR';
    } else if (host.indexOf("memberdev.carefirst.com") !== -1) {
        containerID = 'GTM-WV6QZNR';
    }
    else if (host.indexOf("sita.carefirst.com") !== -1 || host.indexOf("sitb.carefirst.com") !== -1 || host.indexOf("memberprodsupport.") !== -1) {
        containerID = 'GTM-TL7LXNC';
    }
    (function (w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(), event: 'gtm.js'				//GTM tag
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            '//www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', containerID);
}

/*For native application*/
if (location.protocol === "file:") {
   
    // Mobile App environment
    (function (i, s, o, g, r, a, m) {         // GA tag
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

    ga('create', containerID, {
        name: 'myTracker',
        cookieDomain: 'none',
        storage: 'none',
        clientId: dataLayer[0].GUID,
        siteSpeedSampleRate: 100
    });

    ga('myTracker.set', 'checkProtocolTask', null);
    ga('myTracker.set', 'dimension1', dataLayer[0].SBU);
    ga('myTracker.set', 'dimension2', dataLayer[0].ACA);
    ga('myTracker.set', 'dimension3', dataLayer[0].userType);
    ga('myTracker.set', 'dimension4', dataLayer[0].planType);
    ga('myTracker.set', 'dimension5', dataLayer[0].application);
    ga('myTracker.set', 'dimension6', dataLayer[0].isMemberInsured);
    ga('myTracker.set', 'dimension7', dataLayer[0].loggedIn);
    ga('myTracker.set', 'dimension8', dataLayer[0].insuranceType);
    ga('myTracker.set', 'dimension9', dataLayer[0].relationshipCode);
    ga('myTracker.set', 'dimension10', dataLayer[0].ageRange);
    ga('myTracker.set', 'dimension11', dataLayer[0].accountId);
    ga('myTracker.set', 'dimension12', dataLayer[0].enrollmentSystem);
    ga('myTracker.set', 'dimension13', dataLayer[0].riskGroupIndicator);
    ga('myTracker.set', 'dimension14', dataLayer[0].jurisdiction);
    ga('myTracker.set', 'dimension15', dataLayer[0].gender);
    ga('myTracker.set', 'dimension16', dataLayer[0].GUID);
    ga('myTracker.set', 'dimension17', dataLayer[0].channel);
    ga('myTracker.set', 'dimension18', dataLayer[0].channelType);
    ga('myTracker.set', 'dimension19', dataLayer[0].campaignID);
    ga('myTracker.set', 'dimension20', dataLayer[0].subscriberID);
    ga('myTracker.set', 'dimension21', dataLayer[0].personID);
    ga('myTracker.set', 'dimension22', dataLayer[0].impersonation);
    ga('myTracker.set', 'dimension23', dataLayer[0].GroupID);
    ga('myTracker.set', 'dimension26', dataLayer[0].SourceApplication);
    ga('myTracker.set', 'dimension24', dataLayer[0].timeStamp);
    ga('myTracker.set', 'dimension34', dataLayer[0].blueRewardsMember);
    ga('myTracker.set', 'dimension35', dataLayer[0].blueRewardMemberStatus);
    ga('myTracker.set', 'dimension36', dataLayer[0].accountName);
    ga('myTracker.set', 'dimension37', dataLayer[0].groupName);
}


