//https://membersita.carefirst.com/server/server/resources/js/build/GPE.min.js
//http://sv-cdcgchat-t4.carefirst.com:9081/server/resources/js/build/GPE.min.js

var serverDefault = window.location.origin;
//var serverDefault = 'http://sv-cdcgchat-t4.carefirst.com:9081';

if(serverDefault.indexOf("file:/") !== -1)
serverDefault = localStorage.getItem('baseUrl');

var serverSecure = document.location.origin;

//var serverSecure = 'https://sv-cdcgchat-t4.carefirst.com:9443';
parent.postMessage("ChatBoxOpened","*");//send message to member portal and get param values.

function getChatServerUrl(url){
	//return ('https:' == document.location.protocol ? serverSecure : window.parent.origin) + url;
	return ('https:' == document.location.protocol ? serverSecure : serverDefault) + url;
}


//http://plnkr.co/edit/oz3CL7?p=preview
var isMobileCurrentDevice = false;
var _gt = window._gt || [];
_gt.push(['config', {
				    dslResource : getChatServerUrl('/server/resources/dsl/domain-model.xml'),
				    httpEndpoint : getChatServerUrl(''),
				    httpsEndpoint : getChatServerUrl(''),
				    debug: true,
				    cometdConfig: {
				        logLevel: 'debug'
				    }
				  }]);
var _gwc = {
			debug: true,
			widgetUrl:  getChatServerUrl( '/server/resources/chatWidget.html'),
			serverUrl:  getChatServerUrl('/server/cometd'),
			templates:  getChatServerUrl('/server/resources/chatTemplatesModified.html'),
			embedded:true,
			autoRestore: false,
			registration: false,
			onReady: [function (chatAPI) {
						chatAPI.onSession(function(session) {
											parent.postMessage("sessionStatus_1","*");
											//we know here that chat session started successfully.
											//fix for mobile devices only.
											if(isMobileCurrentDevice)
											{
												$(parent.window.document).on('click touchstart',function(e){
													closeKeyboard();
												}); 
												
												
												$('div.gwc-chat-embedded-window').on('click touchstart',function(e){
													if (e.target.className != "gwc-chat-input gwc-chat-message-input") {
														closeKeyboard();
													}
												});
												
												function closeKeyboard(){
													var $input = $('textarea.gwc-chat-input');
													var isMobile = {
														    iOS: function() {
														        return /iPhone|iPad|iPod/i.test(navigator.userAgent);
														    },
														    any: function() {
														        return (isMobile.Android() || isMobile.iOS());
														    }
														};
													 if (isMobile.iOS()){
													    var url = "objc::closeKeybaord()";
														var iframe = document.createElement("IFRAME");
														iframe.setAttribute("src", url);
														document.documentElement.appendChild(iframe);
														iframe.parentNode.removeChild(iframe);
														iframe = null;}
														 
												}
												
											}
											
											var timeout = 10 * 60 * 1000, // 10 minutes
								    		sessionTimeout;
								    		function startCountdown() {
									    		sessionTimeout = setTimeout(function() {
									    			session.leave();
									    		}, timeout);
								    		}
								        	session.onMessageReceived(function(event) {
									    		 if (document.hidden) {
													var time = new Date();
													var currenttime = time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds();
													    var oldTitle = document.title;
													    var msg = "New!";
													    var timeoutId;
													    var blink = function() { document.title = document.title == msg ? ' ' : msg; };
													    var clear = function() {
													        clearInterval(timeoutId);
													        document.title = oldTitle;
													        $window.onmousemove = null;
													        timeoutId = null;
													    };
													   
												        if (!timeoutId) {
												            timeoutId = setInterval(blink, 1000);
												            $window.onmousemove = clear;
												        }
													//document.title = document.title + " - new message at " + currenttime;
												} 
									    		
									    		var a = $('.gwc-chat-message-author').length;
												if($('.gwc-chat-message-author')[a-1].innerHTML == "system"){
													/*$($("div.gwc-chat-message-author").parent()[a-1]).addClass("gwc-chat-agentMessage");*/
													$($("div.gwc-chat-message-author").parent()[a-1]).addClass("gwc-chat-systemMessage");
												}else {}
									    		clearTimeout(sessionTimeout);
									    		startCountdown();
									    		parent.postMessage("resetTimer","*");
								    		});
								    		session.onError(function(event) {
									    		// event.error.code
									    		// event.error.description
									    		parent.postMessage("auditChatFailure","*");
								    		});
									    	session.onContinued(function(event) {
									    		// event.error.code
									    		// event.error.description
									    		parent.postMessage("sessionStatus_0","*");
								    		});
									    	session.onInterrupted(function(event) {
									    		// event.error.code
									    		// event.error.description
									    		parent.postMessage("sessionStatus_0","*");
								    		});
									    	session.onSessionEnded(function(event) {
									    		//event.reason.error
										    	//event.reason.agent
									    		parent.postMessage("sessionStatus_0","*");
									    	});
				    					});
					}]
};


function closeChatBox(){

	//send end session cal
	_gwc.onReady.push(function (chatAPI) { 
        chatAPI.close(); //starting a chat here
    });
	parent.postMessage("session_close","*");
};

function CapitalizeName(input) {
    return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
  }


function reactiveChat(params,isMobile) {
	//_gt.push(['event', 'UserInfo', {data:params}]);	//sending params to chat system
	_gt.push(['getIDs', function(IDs) {
		_gwc.onReady.push(function (chatAPI) { 
			console.log('IDs: ', IDs);
	        chatAPI.startChat({userData: {
					        	visitID: IDs.visitID, 
					        	pageID: IDs.pageID,
					        	FirstName: CapitalizeName(params.firstName), 
					        	LastName: CapitalizeName(params.lastName), 
					        	SEGID: 	params.SEGID, 
					        	memberID: params.memberID, 
					        	Dob: params.Dob, 
					        	groupNumber: params.groupNumber, 
					        	agentGroup: params.agentGroup,
					        	virtualQueue: params.virtualQueue,
					        	intent: params.intent, 
					        	claimNumber: params.claimNumber, 
					        	claimStatus: params.claimStatus,
					        	userID:params.userID,
					        	GUID:params.GUID,
					        	//GUID:'2980637493',
					        	EmailAddress:params.EmailAddress
					        	}
	        		});
	  });
	}]);
	 parent.postMessage("sessionStatus_2","*");
	 isMobileCurrentDevice =isMobile;
}
(function(gpe) {
if (document.getElementById(gpe)) return;
var s = document.createElement('script'); s.id = gpe;
s.src= getChatServerUrl( '/server/resources/js/build/GPE.min.js');
(document.getElementsByTagName('head')[0] || document.body).appendChild(s);
})('_gt');
