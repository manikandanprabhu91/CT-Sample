// elements
var timer;
var extendSessionBtn;
var logoutBtn;
var legalBtn;
var legal;

// timer time (in seconds)
var time = 60;

// for legal toggle
var legalShown = false;

window.onload = function () {
  getElements();
  setClickListeners();
  startTimer();
};

function getElements() {
  timer = document.getElementById('timer');
  extendSessionBtn = document.getElementById('extend-session-btn');
  logoutBtn = document.getElementById('logout-btn');
  legalBtn = document.getElementById('legal-btn');
  legal = document.getElementById('legal');
  timerS = document.getElementById('timer-s');
}

function setClickListeners() {
  extendSessionBtn.addEventListener('click', extendSessionClick);
  logoutBtn.addEventListener('click', logoutClick);
  legalBtn.addEventListener('click', legalClick);
}

function startTimer() {
  timer.innerHTML = time--;
  setInterval(function () {
    if (time === 1) {
      timerS.style.display = 'none';
    } else {
      timerS.style.display = 'inline';
    }
    if (time >= 0) {
      timer.innerHTML = time--;
    } else {
      window.opener.logout();
      window.close();
    }
  }, 1000);
}

function extendSessionClick() {
  window.opener.extendSession();
}

function logoutClick() {
  window.opener.logout();
}

function legalClick() {
  if (legalShown) {
    legal.style.display = 'none';
    window.resizeTo(500, 550);
  } else {
    window.resizeTo(500, 780);
    legal.style.display = 'block';
  }
  legalShown = !legalShown;
}