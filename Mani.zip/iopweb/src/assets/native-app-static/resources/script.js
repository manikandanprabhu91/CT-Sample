/* placeholder plugin starts here  */

/*! http://mths.be/placeholder v2.0.8 by @mathias */

(function(window, document, $) {



	// Opera Mini v7 doesn’t support placeholder although its DOM seems to indicate so

	var isOperaMini = Object.prototype.toString.call(window.operamini) == '[object OperaMini]';

	var isInputSupported = 'placeholder' in document.createElement('input') && !isOperaMini;

	var isTextareaSupported = 'placeholder' in document.createElement('textarea') && !isOperaMini;

	var prototype = $.fn;

	var valHooks = $.valHooks;

	var propHooks = $.propHooks;

	var hooks;

	var placeholder;



	if (isInputSupported && isTextareaSupported) {



		placeholder = prototype.placeholder = function() {

			return this;

		};



		placeholder.input = placeholder.textarea = true;



	} else {



		placeholder = prototype.placeholder = function() {

			var $this = this;

			$this

				.filter((isInputSupported ? 'textarea' : ':input') + '[placeholder]')

				.not('.placeholder')

				.bind({

					'focus.placeholder': clearPlaceholder,

					'blur.placeholder': setPlaceholder

				})

				.data('placeholder-enabled', true)

				.trigger('blur.placeholder');

			return $this;

		};



		placeholder.input = isInputSupported;

		placeholder.textarea = isTextareaSupported;



		hooks = {

			'get': function(element) {

				var $element = $(element);



				var $passwordInput = $element.data('placeholder-password');

				if ($passwordInput) {

					return $passwordInput[0].value;

				}



				return $element.data('placeholder-enabled') && $element.hasClass('placeholder') ? '' : element.value;

			},

			'set': function(element, value) {

				var $element = $(element);



				var $passwordInput = $element.data('placeholder-password');

				if ($passwordInput) {

					return $passwordInput[0].value = value;

				}



				if (!$element.data('placeholder-enabled')) {

					return element.value = value;

				}

				if (value == '') {

					element.value = value;

					// Issue #56: Setting the placeholder causes problems if the element continues to have focus.

					if (element != safeActiveElement()) {

						// We can't use `triggerHandler` here because of dummy text/password inputs :(

						setPlaceholder.call(element);

					}

				} else if ($element.hasClass('placeholder')) {

					clearPlaceholder.call(element, true, value) || (element.value = value);

				} else {

					element.value = value;

				}

				// `set` can not return `undefined`; see http://jsapi.info/jquery/1.7.1/val#L2363

				return $element;

			}

		};



		if (!isInputSupported) {

			valHooks.input = hooks;

			propHooks.value = hooks;

		}

		if (!isTextareaSupported) {

			valHooks.textarea = hooks;

			propHooks.value = hooks;

		}



		$(function() {

			// Look for forms

			$(document).delegate('form', 'submit.placeholder', function() {

				// Clear the placeholder values so they don't get submitted

				var $inputs = $('.placeholder', this).each(clearPlaceholder);

				setTimeout(function() {

					$inputs.each(setPlaceholder);

				}, 10);

			});

		});



		// Clear placeholder values upon page reload

		$(window).bind('beforeunload.placeholder', function() {

			$('.placeholder').each(function() {

				this.value = '';

			});

		});



	}



	function args(elem) {

		// Return an object of element attributes

		var newAttrs = {};

		var rinlinejQuery = /^jQuery\d+$/;

		$.each(elem.attributes, function(i, attr) {

			if (attr.specified && !rinlinejQuery.test(attr.name)) {

				newAttrs[attr.name] = attr.value;

			}

		});

		return newAttrs;

	}



	function clearPlaceholder(event, value) {

		var input = this;

		var $input = $(input);

		if (input.value == $input.attr('placeholder') && $input.hasClass('placeholder')) {

			if ($input.data('placeholder-password')) {

				$input = $input.hide().next().show().attr('id', $input.removeAttr('id').data('placeholder-id'));

				// If `clearPlaceholder` was called from `$.valHooks.input.set`

				if (event === true) {

					return $input[0].value = value;

				}

				$input.focus();

			} else {

				input.value = '';

				$input.removeClass('placeholder');

				input == safeActiveElement() && input.select();

			}

		}

	}



	function setPlaceholder() {

		var $replacement;

		var input = this;

		var $input = $(input);

		var id = this.id;

		if (input.value == '') {

			if (input.type == 'password') {

				if (!$input.data('placeholder-textinput')) {

					try {

						$replacement = $input.clone().attr({ 'type': 'text' });

					} catch(e) {

						$replacement = $('<input>').attr($.extend(args(this), { 'type': 'text' }));

					}

					$replacement

						.removeAttr('name')

						.data({

							'placeholder-password': $input,

							'placeholder-id': id

						})

						.bind('focus.placeholder', clearPlaceholder);

					$input

						.data({

							'placeholder-textinput': $replacement,

							'placeholder-id': id

						})

						.before($replacement);

				}

				$input = $input.removeAttr('id').hide().prev().attr('id', id).show();

				// Note: `$input[0] != input` now!

			}

			$input.addClass('placeholder');

			$input[0].value = $input.attr('placeholder');

		} else {

			$input.removeClass('placeholder');

		}

	}



	function safeActiveElement() {

		// Avoid IE9 `document.activeElement` of death

		// https://github.com/mathiasbynens/jquery-placeholder/pull/99

		try {

			return document.activeElement;

		} catch (exception) {}

	}



}(this, document, jQuery));





/* placeholder plugin ends here  */

$(document).ready(function() {

 	$('input, textarea').placeholder();

	$('.slide-container .slide h4').on("click", function(e){

		e.preventDefault();

			var scontent = $(this).parent().find(".slide-content");

			var _this = this;

		scontent.slideToggle(function(){

		  if($(this).is(":visible")){

			$("span.image", _this).addClass("glyphicon-round-minus").removeClass("glyphicon-round-plus")

		  }else{

			$("span.image", _this).addClass("glyphicon-round-plus").removeClass("glyphicon-round-minus")

		  }

		});

	});



	$('.cf-footer').click(function(){

        $('#Quick-link-content').toggleClass('hidden')



        if($('#Quick-link-content ').hasClass('hidden'))

        {

         $(this).removeClass('withoutArrow')

       }

       else

       {



        $('.cf-main-container').click(function(){

         if(($('#Quick-link-content').hasClass('hidden')==false))

         {

          $('.cf-footer').removeClass('withoutArrow');

          $('#Quick-link-content ').addClass('hidden');



        }

      });

        $(this).addClass('withoutArrow')

      }

      

    });

	

	/* Whos covered - Adoption date change */

	

	$('.relationship').live('change', function (e) { 

		if( $(this).val() == "Child Adopted") {

			$(this).parent().parent().find('.adoption').show();

			$(this).parent().find('#adopt-note').show();

		}

		else{

			$(this).parent().parent().find('.adoption').hide();

			$(this).parent().find('#adopt-note').hide();

		}         

	});

	

	

	/* Whos covered - Remove change */

	

	$('.relationship').live('change', function (e) { 

		if( $(this).val() == "Child Adopted") {

			$(this).parent().parent().find('.adoption').show();

			$(this).parent().find('#adopt-note').show();

		}

		else{

			$(this).parent().parent().find('.adoption').hide();

			$(this).parent().find('#adopt-note').hide();

		}         

	});

	

	/* My Profile - Other Reason change */

	

	$('#reason').live('change', function (e) { 

		if( $(this).val() == "death") {

			$('#reason-death').show();

		}

		else{

			$('#reason-death').hide();

		}   

		if( $(this).val() == "divorce") {

			$('#reason-divorce').show();

		}

		else{

			$('#reason-divorce').hide();

		}      

		if( $(this).val() == "military") {

			$('#reason-deploy').show();

		}

		else{

			$('#reason-deploy').hide();

		}         

		

	});

	

	$('#reason').live('change', function (e) { 

		if( $(this).val() == "otherReason") {

			$('.other-reason').show();

		}

		else{

			$('.other-reason').hide();

		}         

	});

	

	/* My Profile - Documentation Required change */

	

	$('#reason').live('change', function (e) { 

		if( $(this).val() == "marriage") {

			$('#docRequired').show();

		}

		else{

			$('#docRequired').hide();

		}

		       

	});

	



	/* My DatePicker */

/*

	$('.myDatepicker').each(function() {

		var minDate = new Date();

		minDate.setHours(0);

		minDate.setMinutes(0);

		minDate.setSeconds(0,0);



		var $picker = $(this);

		$picker.datepicker();



		var pickerObject = $picker.data('datepicker');



		$picker.live('changeDate', function(ev){

			$picker.datepicker('hide');

		});

	}); */

	$(document).on("click", ".myDatepicker span.add-on", function(){

		//$(this).closest(".myDatepicker").find("input.datepicker").focus();

	});

	$(document).on("focus", "input.datepicker", function(){

		var $picker = $(this);

		if($picker.hasClass("monthonly")){

			$picker.datepicker({

				format: "mm/yyyy",

				viewMode: "months", 

				minViewMode: "months"

			});			

		}

		else{

			$picker.datepicker();

		}

		$picker.live('changeDate', function(ev){

			$picker.datepicker('hide');

		});

	});

	

	/* my doc - toggle class */

	$("#findDocument").on("click", function(){

		$( ".container-find-doc" ).hide();

		$( "#xs_expand" ).show();

	});

	

	$("#ModifyDocument").on("click", function(){

		$( "#xs_expand" ).hide();

		$( ".container-find-doc" ).show();

	});

	

	/* Add Member */

	

	var memberBlockCount = 1;

    $('#addAnotherMem').click(function(){

		memberBlockCount++;

		var clone = $('#memberBlock').clone();

		clone.find("input").removeAttr("value");

		clone.find("input:radio").each(function(){

			$(this).attr("name" , $(this).attr("data-name")+memberBlockCount).removeAttr("checked");

		});

        clone.addClass('cloned').appendTo(".newMemberHolder");

		clone.find(".memCount").html(memberBlockCount);



    });

	

	/* Remove Member */

	

	$(".removeMember").click(function(e) {

		$(".newMemBlock.cloned:last-child").remove();

	});

	

	/* mega menu  

	var current_width = $(window).width();

  	if(current_width < 939){



	  // nav - full height

	  $('#navbar-collapse-1').css({'min-height':(($(window).height()))+'px'});

	  

	  // nav - slide from left		

	  $( '.navbar-toggle').click(function() {

	  	$( "#navbar-collapse-1" ).toggle( 300 );

	  });

	  

	}   */

  

	/* plus minus icon change */

	$('tr.accordion-toggle').click(function(){

		

		if($(this).find('td').hasClass('plusIcon'))	{

		 $(this).find('td.plusIcon').removeClass("plusIcon").addClass("minusIcon");

		}

		 else {

			 $(this).find('td.minusIcon').removeClass("minusIcon").addClass("plusIcon");

		 }

	});

	

	/* mydoc - Custom date */

	$('#dates-of-service').bind('change', function (e) { 

		if( $('#dates-of-service').val() == "Custom Range") {

			$('.customRange').show();

			$('#beginend').show();

		}

		else{

			$('.customRange').hide();

			$('#beginend').hide();

		}         

	});



	$('.myDatepicker').each(function() {

		var minDate = new Date();

		minDate.setHours(0);

		minDate.setMinutes(0);

		minDate.setSeconds(0,0);



		var $picker = $(this);

		$picker.datepicker();



		var pickerObject = $picker.data('datepicker');



		$picker.on('changeDate', function(ev){

			$picker.datepicker('hide');

		});

	});  



	/*$('#custom_start_date').datepicker({

		format: 'mm/dd/yyyy'

	});  



	$('#custom_end_date').datepicker({

		format: 'mm/dd/yyyy'

	}); 

	

		

	/* select new PCP */

	

	$(".selectBtn").on("click", function(){

		$( ".selectedPcp" ).show();

	});

	

	

	

	/*$('.cfmegamenu-content li a').unbind('click').bind('click', function(e) {

		var $el = $(this).parents('.dropdown').first();

		$el.dropdown('toggle');

	});*/

	

	// Only for Illustrative purposes in Demo.. WOULD USE ANGULAR $scope IN REAL LIFE

	var _new_claim_search_requested = true;

	var resize_fn = function() {

		var width = $(window).width();

		if (width<750) {

			if (_new_claim_search_requested) {

				$("#cf-table-results").show();

				$(".cf-criteria-container").hide();

				$(".cf-criteria-summary-container").show();

			} else {

				$("#cf-table-results").hide();

				console.log("jere");

				$(".cf-criteria-container").show();

				$(".cf-criteria-summary-container").hide();

			}

		} else {

			$(".cf-criteria-container").show();

			$("#cf-table-results").show();

			$(".cf-criteria-summary-container").show();

		}

	}

	$(window).bind("resize", function (e) {

		resize_fn();

	});

	$('#cf-search-claims-btn').click(function(e) {

		_new_claim_search_requested = true;

		resize_fn();

	});

	$("#cf-edit-claim-criteria-btn").click(function(e) {

		_new_claim_search_requested = false;

		resize_fn();

	});

	resize_fn();

		

});





/* MEGA MENU SLIDE FROM LEFT  */

	

(function($){

  //detect the width on page load

  $(document).ready(function(){

	  

	  adjustCollapsedNavbarHeight();

	  $( '.navbar-toggle').click(function() {

		  applyToggleNavbar();

		});

  });

  

  //update the width value when the browser is resized (useful for devices which switch from portrait to landscape)

  $(window).resize(function(){

	 adjustCollapsedNavbarHeight();

  });

  

  function adjustCollapsedNavbarHeight() {

	var current_width = $(window).width();

//	console.log("current_width:" + current_width); 

  }

  

  // Mega Menu Vertical Scroll and slide

  function applyToggleNavbar() {

	var current_width = $(window).width();

	

    if(current_width < 939){

		 $( "#navbar-collapse-1" ).toggle( 700 );

		 $( "#navbar-collapse-1" ).css('overflow','scroll');

		   

	}

  }

})(jQuery);	



	$('li.dropdown').hover(

       function(){ $(this).find('.mm-arrow').addClass('hover') },

       function(){ $(this).find('.mm-arrow').removeClass('hover') 

	});

	



//







	$('.checkbox-group').on('click', function(e){

		if(!$(e.target).is(":checkbox")) {

			$(this).find(':checkbox').click();

			console.log("clicked");

		}

	});

	

	$('.radio-group').on('click', function(e){

		if(!$(e.target).is(":radio")) {

			$(this).find(':radio').click();

			console.log("clicked");

		}



});

//$('input, textarea').placeholder();
/*online claims functionality section starts here */
// JavaScript Document
$('.ClaimDataHead').click(function(e) {
	$(this).next('.claimDataBody').toggle();
	$(this).toggleClass('selected');
});


$('input[type="radio"]').click(function(){
	if($(this).attr("value")=="flu-yes"){
		$(".dropanddate").show();
	}
	if($(this).attr("value")=="flu-no"){
		$(".dropanddate").hide();

	}

});


$("select").change(function(){
	$( "select option:selected").each(function(){
		if($(this).attr("value")=="Auto Accident"){
			$(".dropchecked").show();

		}
		if($(this).attr("value")=="Accidental Injury"){
			$(".dropchecked").hide();

		}
		if($(this).attr("value")=="Work Related Accident"){
			$(".dropchecked").hide();

		}


	});
});



function copyclaim(){
	$(document).on('click', '.copyclaim', function(){
	//$('.claimline-info .claimoutertable .copyclaim').click(function(e) {
		if(!$(this).find('img').hasClass('disablecopy')){
			var rowcount =$('.claimline-info').find('.claimtable').length;
			var claimtable = $(this).parents('.claimoutertable').clone()

					//claimtable.find("input").val('');
					
					claimtable.find(".myDatepicker").each(function(index){
						var dateid = $(this).find("input.datepicker").attr("id") + index+(new Date().getTime());
						$(this).find("input.datepicker").attr("id", dateid);
						$(this).find("label.add-on").attr("for", dateid);
						
					});
					$(this).closest(".claimline-info").find(".claimoutertable").eq(-1).after(claimtable);
					rowcount++;
					var i=1;
					if(i<=rowcount)
					{		
						$('span.linenumber').each(function(index, element) {
							$(this).html('00'+i);
							$(this).parents('.claimoutertable').find('div.modifyclaims label').html('Claim line #00'+i);
							i++;
						});
					}
					$('.delete-table').each(function(index, element) {
            $('.deleteimage').attr('src','content/img/delete_ico.svg');
            $('span.deleteimage').addClass("copyimagetext");
        });
				}
				 totalamt();
			});

}

function addclaim(){
//	$(document).on('click','.newaddclaim .addclaimdiv',function(){
	$('.newaddclaim .addclaimdiv').click(function(e) {
		var rowcount =$('.claimline-info').find('.claimtable').length;
		var claimtable = $(this).parents('.newaddclaim').prev('.claimoutertable').clone()
		//claimtable.find('.copyclaim .cloneMe').attr('src','content/img/copy_disable_ico.svg');
		//claimtable.find('.cloneMe').addClass('disablecopy');
		
		claimtable.find("input").val('');
		claimtable.find('img.cloneMe').attr('src','content/img/copy_disable_ico.svg');
		//claimtable.find('img.deleteimage').attr('src','content/img/delete_ico.svg');
		claimtable.find(".myDatepicker").each(function(index){
			var dateid = $(this).find("input.datepicker").attr("id") + index+(new Date().getTime());
			$(this).find("input.datepicker").attr("id", dateid);
			$(this).find("label.add-on").attr("for", dateid);
			
		});
		$(this).closest(".claimline-info").find(".claimoutertable").eq(-1).after(claimtable);
		rowcount++;
		var i=1;
		if(i<=rowcount)
		{		
			$('span.linenumber').each(function(index, element) {
				$(this).html('00'+i);
				$(this).parents('.claimoutertable').find('div.modifyclaims label').html('Claim line #00'+i);
				i++;
			});
			
		}
		$('.delete-table').each(function(index, element) {
            $('.deleteimage').attr('src','content/img/delete_ico.svg');
             $('span.deleteimage').addClass("copyimagetext");
        });

	});

}

function accordionfunction(){
	$(document).on('click','.modifyclaims',function(e){
		if($('.claimoutertable').length>1)
		{
			$(this).parent().next('.tbl-content').toggle();

			if($(this).parent().next('.tbl-content').is(":visible")){
				$(this).parents('.claimtable').addClass('accordionOpen')
				$(this).find("span.image").addClass("glyphicon-round-black-minus ").removeClass("glyphicon-round-black-plus")
			}else{
				$(this).parents('.claimtable').removeClass('accordionOpen')
				$(this).find("span.image").addClass("glyphicon-round-black-plus").removeClass("glyphicon-round-black-minus ")
			}
		}


	});
}

/*deleterow for desktop*/
function deleterow(){
	
	$(document).on('click',".deleteclaim", function(e){ 
		var rowcount =$('.claimline-info').find('.claimoutertable').length;
		if(rowcount>1){
			$(this).parents('.claimoutertable').remove();
			rowcount--;
			if(rowcount==1){
					$('.claimline-info .claimoutertable').find('img.deleteimage').attr('src','content/img/delete_disable_ico.svg');
					$('.claimline-info .claimoutertable').find('span.deleteimage').removeClass("copyimagetext");
			}
		}
		
		var i=1;
		if(i<=rowcount)
		{	
			$('span.linenumber').each(function(index, element) {
				$(this).html('00'+i);
				$(this).parents('.claimoutertable').find('div.modifyclaims label').html('Claim line #00'+i);
				i++;

			});
		}
	});
	
}

function enableCopy(){
	//$(document).on('each', '.claimline-info .claimoutertable', function (index, element) {
	//$(document).on('each', '.claimline-info .claimoutertable', function (index, element) {
	$('.claimline-info .claimoutertable').each(function(index, element) {
		var flag=0;
		$(this).find('input').each(function(index, element) {
			if( $(this).val()!='')
			{
				flag=1;
			}
		});
		if(flag==1)
		{
			$(this).find('.copyclaim .cloneMe').attr('src','content/img/copy_ico.svg');
			$(this).find('.cloneMe').removeClass('disablecopy');
			$(this).find(".clone-table > span").addClass("copyimagetext");
			//copyclaim();
			
		}
		else
		{
			$(this).find('.copyclaim .cloneMe').attr('src','content/img/copy_disable_ico.svg');
			$(this).find('.cloneMe').addClass('disablecopy');
			$(this).find(".clone-table > span").removeClass("copyimagetext");
		}
		flag=0;
	});
}
/*deleterow ends here*/
/*calculate total amt for step2*/
         function totalamt(){


          var amount_sum = 0;
 $('input.totalprice').each(function()
 {

  amount_sum += Number($(this).val().substring(1));
});
 $('.totalBill-amt').text('$'+amount_sum);
  }

/*online claims functionality section ends here */


