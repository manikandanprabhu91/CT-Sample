(function(angular) {
  'use strict';
angular.module('fad', ['ngAnimate', 'ngTouch'])
  .controller('fadController', ['$scope', function($scope) {
  }])
  .directive('fadToolbar', function() {
    return {
      templateUrl: '../_global-templates/search-toolbar.tpl.html' 
    };
  })
  .directive('cfDraggable', ['$swipe', function($swipe) {
	  return {
		restrict: 'A',
		link: function(scope, elem, attrs) {
			elem.draggable({
				axis: 'x',
				//containment: 'parent',
				drag: function(event, ui) {
					//console.log(ui.position.left);
					//console.log(elm[0].clientWidth);
					$(".slider").addClass('active');
					if (ui.position.left > elem[0].clientWidth) {
						
					} else if (ui.position.left >= -40) {
						console.log('greater than 30');
						ui.position.left = 0;
						return false;
					}
				},
				stop: function(event, ui) {
					console.log(ui.position.left);
					if (ui.position.left < -40) {
						$(".slider").removeClass('active');
						$(this).animate({
							left: '-100%'
						})
					}
				}
			});
		}
	  };
  }])
  .animation('.cf-animate-slide', ['$animateCss', function($animateCss) {
    return {
        addClass: function(element, className, doneFn) {
            var animator = $animateCss(element, {
				event: 'addClass',
				structural: true,
				//from: { height: element[0].offsetHeight },
				to: { height: 0, padding: 0 }
		    });
			
			return animator.start().finally(function() {
				element[0].style.height = '';
				doneFn();
			});
        },
		removeClass: function(element, className, doneFn) {
			console.log(element[0].offsetHeight);
			console.log(element);
            var animator = $animateCss(element, {
				event: 'addClass',
				structural: true,
				from: { height: 0, padding: 0 },
				to: { height: element[0].offsetHeight }
		    });
			
			return animator.start().finally(doneFn);
        }
    };
  }]);
})(window.angular);