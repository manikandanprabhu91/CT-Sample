
var commonWeb = angular.module('commonWebModule', []);

commonWeb.controller('landingController', function($scope,$timeout){

	$scope.page = 'landing';
	$scope.goPage = function( page ){
		$(window).scrollTop(0);
		$scope.page = page;
	};
	
	$scope.checkPathForFAD = function(url){
		return $location.path().indexOf("/" + url) > -1;
    }
	
	$scope.languages = [
                "Ɓǎsɔ́ɔ̀-wùɖù","বাংলা", "한국어", "Deutsch", "አማርኛ",
                "Igbo", "للغة العربية", "中文繁体", "فارسی اردو","English", 
                "Èdè", "Yorùbá", "हिन्दी", "Русский", "Español",
                "Français", "Tagalog", "Tiếng Việt"
	                 ];
	 
	$scope.openLanguageContent = function(){
		
		window.location.href = "https://member.carefirst.com/members/pop-up/language-assistance.page?#english";

	};
	$scope.goHome = function(){
		$(window).scrollTop(0);
		$scope.page = 'landing';
	};
	$scope.goFAP = function(){
		
		if ( whichFap === 'fap' ){

			$scope.loader = true;
			
			setTimeout(function(){
				window.location.href = '../../index.html#/fadsdpublic/search/standard';
			},200);
		}
		
		else if ( whichFap === 'fad' ){
			$('#findadoctor').modal('show');
		}
	};
	$scope.goNurseLine = function(){
		$('#nurseline').modal('show');
	};
	$scope.dialEmergency = function(){
		$('#emergencynumber').modal('show');
	};

	$scope.goUC = function(){
		
		if ( whichFap === 'fap' ){
			$scope.loader = true;
			
			setTimeout(function(){
				window.location.href = '../../index.html#/fadsdpublic/search/nativeurgentcare';
			},200);
		}
		
		else if ( whichFap === 'fad' ){
			$scope.loader = true;
			
			setTimeout(function(){
				window.location.href = '../../index.html#/fadsdpublic/search/nativeurgentcare';
			},200);
		}
	};
	//Emergency Care
	$scope.goEmergency = function(){
		
		if ( whichFap === 'fap' ){
			$scope.loader = true;
			
			setTimeout(function(){
				window.location.href = '../../index.html#/fadsdpublic/search/emergencyMedicine';
			},200);
		}
		
		else if ( whichFap === 'fad' ){
			$scope.loader = true;
			
			setTimeout(function(){
				window.location.href = '../../index.html#/fadsdpublic/search/emergencyMedicine';
			},200);
		}
	};

	$scope.goCare = function(){
		
		$scope.loader = true;
		
		setTimeout(function(){
			window.location.href = '../../index.html#/fadsdpublic/search/standard';
		},200);
	};
              
	
	$scope.goRegister = function(){
		
		$scope.loader = true;
		
		setTimeout(function(){
			window.location.href = '../../index.html#/registration/home';
		},200);
	};
                     
     $scope.finishLoadingFooter = function(){
     
         var monthNames = [ "January", "February", "March", "April", "May",
                           "June", "July", "August", "September", "October", "November",
                           "December" ];
         
         var d = new Date();
         var n = d.getDate();
         var y = d.getFullYear();
 
         $("#demo").text(monthNames[d.getMonth()] + " " + n + "," + " " + y);
         $("#appVersion").text("App Version : " + appVersion);
     
		 };
		 

		 /**
			* Scroll to top of page.
			* Used on the privacy policy for link at bottom of page.
			*/
		 $scope.scrollToTop = function(){
			window.scrollTo(0,0);
		};
                     
});
