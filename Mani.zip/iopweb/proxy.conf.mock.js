
/**
 * Glob and non glob patterns don't seem to work
 * https://github.com/chimurai/http-proxy-middleware/issues/103
 */
const PROXY_CONFIG = [
    {
        context: [
            '/mas/',
            '/EAI5/',
            '/pkmslogout', // needed for logout
            '/members/admin/', // needed for outage
            '/enrl/',
            '/memb/',
            '/fps/',
            '/mbps/',
            '/members/find-providers/provider-directory/do-i-need-a-referral.page' // for page content
        ],
        target: "http://localhost:4201",
        secure: false
    }
];

module.exports = PROXY_CONFIG;