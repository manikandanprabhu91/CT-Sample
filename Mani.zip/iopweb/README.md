# SelfService Portal Angular Project (Angular 5+)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.6.3.

## Ignoring Files
For files that should be ignored by SVN:
1. add them to the `.svnignore` file
2. run `svn propset svn:ignore -F .svnignore .`

## Creating .npmrc
This file is used to get packages from the internal carefirst npm repository

First, create a file called `.npmrc` in the root project directory. Then, paste the following code in that file and replace the 'youremail' text with your carefirst email address.

```javascript
registry = http://svl-jbuild-p1:8081/repository/npm-group/

email= youremail
always-auth=true
_auth=anNkZXZlbG9wZXI6cGFzc3dvcmQxMjM=
```

## Getting Started
1. create `.npmrc` file in the root. (see above)
2. run `npm install`
3. run `ng serve --open`

````


## How Breadcrumb works
The original implementation is cloned from this open source https://github.com/Centroida/ng2-breadcrumbs

However, there are quite a lot of customization we will need but it currently not supported.
In order not to make it over complicated, we just include the source code (only 4 files, 2 has logics),

With our customization, we got below additional benefits:

* Styling is just right (we fixed the template to compiant with our style guide)
* Support integrating with our i18n translation architecture
* Work out of box for most simple scenarios

For most modules, you will not need to know breadcrumb because it is included on top level. only thing you will do is to provide a breadcrumb KEY in data section of our router config.

In case you have requirement to provide some dynamic or special breadcrumb, please refer to below link for more information, we did not change these features.
https://github.com/Centroida/ng2-breadcrumbs/blob/master/README.md#adding-dynamic-routes


### Breadcrumb i18n support
Recommend to add a new entry under BREADCRUMB, then use this key in routing configuration.

Of course, you can still use any available KEY in your translation json file.
```
  "BREADCRUMB" : {
      "DOCUMENTS" : "Documents",
      "DEDUCTIBLE" : "Deductible",
      "CONTRACTS" : "Contracts",
      "DAVIS" : "Vision resources",
      "CLAIMS" : "Claims"
  }
```

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.
To create an SVN tag for ubuild:
```
svn copy https://svn.carefirst.com/svn/CFAPPS/JSWeb/MOSWeb/branches/Release_APR_2020/  https://svn.carefirst.com/svn/CFAPPS/JSWeb/MOSWeb/tags/MOSWeb_<date>_<time>_<branch_Month> -m "tag from branch apr"
```
replace date, time and branch month with the current, for example:
```
svn copy https://svn.carefirst.com/svn/CFAPPS/JSWeb/MOSWeb/branches/Release_JUN_2020/  https://svn.carefirst.com/svn/CFAPPS/JSWeb/MOSWeb/tags/MOSWeb_0529_0909_JUN -m "tag from branch jun"

```

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).
