
var commonWeb = angular.module('commonWebModule', []);

commonWeb.controller('benefitController', function($scope,$timeout){
	var options = {};

	$scope.loader = true; 
	// alert('inside benefit focus');

	var query = window.location.href.split('?')[1];
	if ( !query ){
		alert('Query Parameters are missing');
	}
	else {
		var vars = query.split('&');
		var finalquery = '';
		for (var i = 0; i < vars.length; i++) {
			var equalIndex = vars[i].indexOf('=');
			var key = encodeURIComponent( decodeURIComponent ( vars[i].substring(0,equalIndex) ) );
			var value =  vars[i].substring(equalIndex+1);

			if(key === 'returnurl'){
				$scope.returnurl = decodeURIComponent(value);
			}
			if(key === 'CallerIdentifierCode'){
				$scope.CallerIdentifierCode = value;
			}
			if(key === 'NetworkIdentifierCode'){
				$scope.NetworkIdentifierCode = value;
			}
			if(key === 'sType'){
				$scope.mode = value;
			}
			if(key === 'isNational'){
				$scope.isNational = ( value === 'Y' );
			}
			if(key === 'planName'){
				$scope.planName = value;
			}
			if(key === 'providerName'){
				$scope.providerName = value;
			}
			if(key === 'providerID'){
				$scope.providerID = value;
				//$scope.redirectToBenefitFocus();
				
			}
			//sd params for select/change pcp
			if (key === 'firstname') {
				$scope.firstname = value;
			}
			if (key === 'lastname') {
				$scope.lastname = value;



			}
			if (key === 'middleinitial') {
				$scope.middleinitial = value;
			}
			if (key === 'pcpid') {
				
				$scope.pcpid = value;
				
				
			}
			if (key === 'sapphire_provider_id') {
				
				$scope.sapphire_provider_id = value;
			}
			if (key === 'sapphire_location_id') {
				$scope.sapphire_location_id = value;
			}
			if (key === 'phoneNumber') {

				$scope.phoneNumber = value;
				
			}
			if (key === 'address1') {
				$scope.address1 = value;
				
			}
			if (key === 'city') {
				$scope.city = value;


			}
			if (key === 'state'){
				$scope.state = value;
			}
			


			if (key === 'zip'){
				$scope.zip = value;
			}

		}
	} 
	function initialize (){
		options.onPageLoad = function(){
			$scope.loader = false;
			$scope.$apply();
		};
		options.onPcpSelected = function(data){
			if ( $scope.returnurl ){


				var postbackURL = "name=" + data.provider.providerName + "&"+
				"npi=" + encodeURIComponent(data.provider.providerID) + "&"+
				"timestamp=" + new Date().getTime();
				console.log("$scope.returnurl", $scope.returnurl);
				var finalURL = '';
				if ($scope.returnurl.indexOf('?') > 0){
					finalURL = $scope.returnurl + "&" + postbackURL;
				}
				else {
					finalURL = $scope.returnurl + "?" + postbackURL;
				}
				window.location.replace(finalURL);
			}
		};
		if ( fap ){
			fap.init('benefitFocusWrapper',options);
		}
		else {
			$scope.loader = false;
			// $scope.alert('fap.error.general','fap.error.title');
		}
	}

	options.initialPlanName = 'CareFirst Network';
	if ( $scope.mode && $scope.mode === 'D' ){
		options.mode = 'dentalpcp';
		options.initialPlanCode = 'DENT_PP';
		if ( $scope.NetworkIdentifierCode === "1" ){
			options.initialPlanCode = 'PCVA';
			options.initialPlanName = 'DHMO Provider Choice Network';
		}
		else if ( $scope.NetworkIdentifierCode === "2" ){
			options.initialPlanCode = 'TDN';
			options.initialPlanName = 'DHMO 5000s Network';
		}
		else if ( $scope.NetworkIdentifierCode === "3" ){
			options.initialPlanCode = 'CFX';
			options.initialPlanName = 'DHMO 1i Network';
		}

	}
	else {
		options.mode = 'pcp';
		options.initialPlanCode = 'DC_CC3';
		if ( $scope.NetworkIdentifierCode === "1" ){
			options.initialPlanCode = 'DC_CC3';
			options.initialPlanName = 'BlueChoice Network';
		}
		else if ( $scope.NetworkIdentifierCode === "2" ){
			options.initialPlanCode = 'POS11';
			options.initialPlanName = 'Point of Service Network';
		}
		else if ( $scope.NetworkIdentifierCode === "3" ){
			options.initialPlanCode = 'DC_CC5';
			options.initialPlanName = 'BlueChoice Network';
		}
	}

	if ( $scope.isNational ){
		options.initialNational = $scope.isNational;
	}
	
	

	if($scope.providerID){
		if ( $scope.returnurl ){
			
			
							var postbackURL = "name=" + $scope.providerName + "&"+
							"npi=" + encodeURIComponent($scope.providerID) + "&"+
							"timestamp=" + new Date().getTime();
							console.log("$scope.returnurl", $scope.returnurl);
							var finalURL = '';
							if ($scope.returnurl.indexOf('?') > 0){
								finalURL = $scope.returnurl + "&" + postbackURL;
							}
							else {
								finalURL = $scope.returnurl + "?" + postbackURL;
							}
							window.location.replace(finalURL);
						}

					}
	//Adding changes for sapphire digital based on the url which we receive.
	//If we receive plan name then we direct to sapphire else to arvato.
	if($scope.planName){
		// var saveFinalUrl= $scope.returnurl;
		// var strategyParamKey = "strategy";
		// var strategyParam = saveFinalUrl.substring(saveFinalUrl.indexOf(strategyParamKey)+strategyParamKey.length+1);
		var query1 =  $scope.returnurl.split('?')[1];
		if ( !query1 ){
			//alert('Query Parameters are missing');
		}
		else {
			var vars1 = query1.split('&');
			var finalquery1 = '';
			for (var i = 0; i < vars1.length; i++) {
				var equalIndex = vars1[i].indexOf('=');
				var key = encodeURIComponent( decodeURIComponent ( vars1[i].substring(0,equalIndex) ) );
				var value =  vars1[i].substring(equalIndex+1);
	
				if(key === 'strategy'){
					$scope.strategy = decodeURIComponent(value);
				}
				if(key === 'id'){
					$scope.id = decodeURIComponent(value);
				}
			}
		}
		/////////////////////
		window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/benefitfocus' + "?" 
		 + "strategy=" + $scope.strategy + "&" + "id=" + $scope.id + "&" + "planName=" + $scope.planName + "&" + "returnurl=" + $scope.returnurl ;
	}
	//redirecting to sd wrapper module
	else if($scope.sapphire_provider_id){
		window.location.href = window.location.protocol + "//" + window.location.hostname + '/mos/index.html#/fadsdpublic/search/selectPCP' + "?"
		+ "zip=" +  $scope.zip + "&" +"state=" + $scope.state +  "&" + "city=" + $scope.city + "&" + "address1=" + $scope.address1 +  "&" + "phoneNumber=" + $scope.phoneNumber +
		"&" + "sapphire_location_id=" + $scope.sapphire_location_id + "&" + "sapphire_provider_id=" + $scope.sapphire_provider_id + "&" + "pcpid=" + $scope.pcpid +
		"&" +"middleinitial=" + $scope.middleinitial + "&" + "lastname=" + $scope.lastname + "&" + "firstname=" + $scope.firstname;
	}
	else{
		var fapjsLoc = window.location.origin+'/fds/public/fap.js';
		$.getScript(fapjsLoc).done(function( script, textStatus ) {
			initialize ();
		})
		.fail(function( jqxhr, settings, exception ) {
			// $scope.alert('fap.error.general','fap.error.title');
			$scope.loader = false;
		});
	}

	


	
	
	
	$scope.openExternalLink = function (url){
		window.open(url,'_blank');
	};
	
	$scope.backButton = function(){
		window.history.go(-1);
	};
	
	$scope.print = function(){
		window.print();
	};
	
	$scope.setFontSize = function(size){
		if ( fap ){
    		fap.sendEvent('benefitFocusWrapper','textSize',{data:size});
    	}
	};
});
