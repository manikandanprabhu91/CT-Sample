// pending implementation. placing here temporarily until implmented in global-error

// for these two scenarios we just use that general message (also below)
{
  "memberKey": {
    "subscriberId": "903126546",
    "dateOfBirth": "12/27/1969",
    "firstName": "CONSTONTINO",
    "lastName": "VERDAGUER",
    "relationship": "18",
    "gender": "M"
  },
  "accountSearchFailures": [
    {
      "groupId": "0QV4",
      "searchDate": "05/30/2016"
    }
  ],
  "totalRecords": 0,
  "responseContext": {
    "success": false,
    "guid": 19813488,
    "responseTime": 14398
  }
}

{"error":{"code":"002.001","msg":"Unexpected error"},"responseContext":{"success":false,"guid":19816296,"responseTime":-1}}

Message:
My Account is having issues gathering your member information.
Please try again later or contact Technical Support at 877-526-8390, Mon - Fri; 8 am - 6 pm (Eastern Time).


maintenance:
<?xml version="1.0" encoding="UTF-8"?><root>
<!--ls:begin[component-1422978692657]--><ContentSelect>1</ContentSelect><AlternateContent><Headline> Maintenance</Headline><Content>&lt;p&gt;Due to website upgrades, access to secure&lt;b&gt; My Account&lt;/b&gt; will be temporarily unavailable.&lt;br /&gt;&lt;br /&gt;We apologize in advance for any inconvenience.&lt;/p&gt;</Content></AlternateContent><!--ls:end[component-1422978692657]--></root>
