/**
 * 
 */
package com.carefirst.icentric.batch.service;

import java.io.ByteArrayInputStream;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.carefirst.eapmca.controller.PMConnector;
import com.carefirst.icentric.batch.config.FileTransferConfiguration;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

/**
 * @author aab0490
 *
 */
@Service
public class FileTransferServiceImpl implements FileTransferService{
	
	private static final Logger logger = LogManager.getLogger(FileTransferServiceImpl.class);
	
	@Autowired
	FileTransferConfiguration fileTransferConfiguration;
	
	public Session ftpServerConnection() throws Exception {
		String sftpHost = fileTransferConfiguration.getHost();
		int sftpPort = fileTransferConfiguration.getPort();
		String sftpUser = PMConnector.getConnector().getUserName(fileTransferConfiguration.getVaultQuery());
		String sftpPass = PMConnector.getConnector().getContent(fileTransferConfiguration.getVaultQuery());
		
		logger.info("UserName : "+sftpUser+"\t:\t"+sftpPass.length());
		if (StringUtils.isEmpty(sftpPass)) {
			logger.info("SFTP connection Password is null from Vault");
		}

		Session session = null;
		logger.info("preparing the host information for sftp.");
		try {
			JSch jsch = new JSch();
			session = jsch.getSession(sftpUser, sftpHost, sftpPort);
			session.setPassword(sftpPass);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect();
			logger.info("Host connected.");
		} catch (Exception ex) {
			logger.error("Exception found while transfer the response:: " +ex.getMessage());
			logger.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		} 
		return session;
	}
	
	public boolean transferFile(byte[] byteStream, String sftpWorkingDir, String fileName, Channel channel, ChannelSftp channelSftp) throws Exception {
		boolean isTransferFile = false;

		logger.info("sftpWorkingDir : "+sftpWorkingDir);

		try {
			logger.info("sftp channel opened and connected.");
//			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(sftpWorkingDir);
			ByteArrayInputStream bis = new ByteArrayInputStream(byteStream);
			channelSftp.put(bis, fileName);
			logger.info("File transfered successfully to host.");
			isTransferFile = true;
		} catch (Exception ex) {
			logger.error("Exception found while transfer the response:: " +ex.getMessage());
			logger.error(ExceptionUtils.getStackTrace(ex));
			isTransferFile = false;
			throw ex;
		} 
		return isTransferFile;
	}
	
}
