/**
 * 
 */
package com.carefirst.icentric.batch.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.riskAdjustment.tasklet.RAJobCompletionListener;
import com.carefirst.icentric.batch.riskAdjustment.tasklet.RiskAdjustmentItemWriterTasklet;

/**
 * @author aab0490
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class RiskAdjustmentJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(RiskAdjustmentJobConfig.class);
	@Autowired
	private JobBuilderFactory raJobBuilderfactory;

	@Autowired
	private StepBuilderFactory raStepBuilderfactory;

	@Bean
	public Job raBatchJob() throws ApplicationException {
		return raJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB RiskAdjustment").incrementer(new RunIdIncrementer())
				.start(riskAdjGapWriter()).listener(raJobcompletionListener()).build();
	}

	@Bean
	public JobExecutionListener raJobcompletionListener() {
		return new RAJobCompletionListener();
	}
	
	@Bean
	public Step riskAdjGapWriter() {
		LOGGER.info("readData - step1() start/end");
		return raStepBuilderfactory.get("step1").tasklet(riskAdjGapTasklet()).build();
	}
	
	@Bean
	public RiskAdjustmentItemWriterTasklet riskAdjGapTasklet() {
		RiskAdjustmentItemWriterTasklet tasklet = new RiskAdjustmentItemWriterTasklet();
		return tasklet;
	}

}
