package com.carefirst.icentric.batch.starcare.tasklet;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocResponse;
import com.carefirst.icentric.batch.constant.ApplicationConstants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.FileAtchDtl;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.service.EDMSService;
import com.carefirst.icentric.batch.starcare.model.LastMedRecReqServRangeDts;
import com.carefirst.icentric.batch.starcare.model.MemberPCP5PartKey;
import com.carefirst.icentric.batch.starcare.model.StarCareGap;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapReq;
import com.carefirst.icentric.batch.starcare.model.StarsCareGapResponseObj;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 * This class is used to generate starcare json file
 * @author aad7740
 *
 */
public class StarCareItemWriterTasklet implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(StarCareItemWriterTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;
	
	@Autowired
	FileAtchDtlDAO fileAttchDao;

	@Autowired
	EDMSService edmsService;
	
	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtldao;
	
	@Autowired
	FileUtils fileUtils;
	
	
	@Override
	public void beforeStep(StepExecution stepExecution) {
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info(":::StarCareItemWriterTasklet -> execute method -> start ::::::::::");
		try {
			List<PexReqtMembQueue> membQueues = pexReqtMembQueueDAO.getPexReqtMembQueueRecordsBasedonStatus(ApplicationConstants.SC, ApplicationConstants.CLOSED_STATUS);
			StarsCareGapResponseObj scGapResponseObj = new StarsCareGapResponseObj();
			List<StarsCareGapReq> scGapReqList = new ArrayList<>();
			if(!membQueues.isEmpty()) {
				for (PexReqtMembQueue item : membQueues) {
					StarsCareGapReq scGapReq = new StarsCareGapReq();
					scGapReq.setProvEngmntReqId(fileUtils.getValue(item.getProvEngmtReqtId()));
					scGapReq.setCapabilityInd(fileUtils.getValue(item.getCpbltyIndcCd()));
					scGapReq.setHomePlanId(fileUtils.getValue(item.getHmPlanId()));
					scGapReq.setMemberHostPlanId(fileUtils.getValue(item.getMembHstPlnId()));
					scGapReq.setRoutetoHostPlanId(fileUtils.getValue(item.getRoutHstPlnId()));
					scGapReq.setFirstTimeSenttoHostPlanDt(fileUtils.getValue(item.getIntlHstPlnDt()));
					scGapReq.setLastMRRProvEngmntReqID(fileUtils.getValue(item.getLastMrrProvEngmtRetId()));
					scGapReq.setLastMedRecReqRcptDt(fileUtils.getValue(item.getLastMedRecReqtDt()));

					LastMedRecReqServRangeDts lastMedRecReqServRangeDts = new LastMedRecReqServRangeDts();
					lastMedRecReqServRangeDts.setLastMedRecReqServBeginDt(fileUtils.getValue(item.getLastMedRecReqtBegDt()));
					lastMedRecReqServRangeDts.setLastMedRecReqServEndDt(fileUtils.getValue(item.getLastMedRecReqtEndDt()));
					scGapReq.setLastMedRecReqServRangeDts(lastMedRecReqServRangeDts);

					scGapReq.setITSSubscriberId(fileUtils.getValue(item.getItsSubscrId()));
					scGapReq.setMemberDOB(fileUtils.getValue(item.getMembDob()));
					scGapReq.setMMIId(fileUtils.getValue(item.getMmiId()));
					scGapReq.setMemberFullName(fileUtils.getValue(item.getMembFullNm()));
					scGapReq.setMemberGender(fileUtils.getValue(item.getMembGndr()));
					scGapReq.setNumofGapClosures(item.getCloseGapCnt() != null ? item.getCloseGapCnt().intValue() : 0);
					scGapReq.setBillProvProprietaryId(fileUtils.getValue(item.getBillProvId()));
					scGapReq.setRndrngProvProprietaryId(fileUtils.getValue(item.getRndrProvId()));
					scGapReq.setBillProvNPI(fileUtils.getValue(item.getBillProvNpi()));
					scGapReq.setRndrngProvNPI(fileUtils.getValue(item.getRndrProvNpi()));
					scGapReq.setRndrngProvHostPlanId(fileUtils.getValue(item.getRndrProvHstPlnId()));
					scGapReq.setBillProvZipCode(fileUtils.getValue(item.getBillProvZipCd()));
					scGapReq.setRndrngProvZipCode(fileUtils.getValue(item.getRndrProvZipCd()));
					scGapReq.setRndrngProvTxnmyCd(fileUtils.getValue(item.getRndrProvTnxmyCd()));
					scGapReq.setSCCFIds(fileUtils.getValue(item.getSccfId()));
					scGapReq.setGapPrevouslyClosedByThisProv(fileUtils.getValue(item.getPrevGapClsProv()));
					scGapReq.setRndrngProvTaxId(fileUtils.getValue(item.getRndrProvTaxId()));
					scGapReq.setRndrngProvAddlInfo(fileUtils.getValue(item.getAddnlInfo()));

					MemberPCP5PartKey memberPCP5PartKey = new MemberPCP5PartKey();
					memberPCP5PartKey.setProvPlanCd(fileUtils.getValue(item.getProvPlnCd()));
					memberPCP5PartKey.setProductCd(fileUtils.getValue(item.getProvProdCd()));
					memberPCP5PartKey.setProvNum(fileUtils.getValue(item.getProvNum()));
					memberPCP5PartKey.setProvNumSuffix(fileUtils.getValue(item.getProvSufx()));
					memberPCP5PartKey.setProvNetwrkLocSeqNum(fileUtils.getValue(item.getProvNtwrkLoc()));
					scGapReq.setMemberPCP5PartKey(memberPCP5PartKey);

					
					scGapReq.setProvEngagementInd(fileUtils.getValue(item.getProvEngmtIndc()));
					scGapReq.setProvCntrctingSts(fileUtils.getValue(item.getProvPartStus()));
					
					List<StarCareGap> scGapsList = new ArrayList<>();
					for (PexMembGapsDtl membGap : item.getPexMembGapsDtls()) {
						StarCareGap scGap = new StarCareGap();

						scGap.setGapId(membGap.getGapId()!=null ? membGap.getGapId().intValue(): 0);
						scGap.setGapMeasure(fileUtils.getValue(membGap.getGapMeasCd()));
						scGap.setGapIdentificationRationale(fileUtils.getValue(membGap.getGapIdtfnRtnl()));
						scGap.setRequestedAction(fileUtils.getValue(membGap.getReqtdActn()));
						scGap.setAddlInfotoHostPlan(fileUtils.getValue(membGap.getAddlInfoHostPln()));
						scGap.setHomePlanGaplvlClsrInd(fileUtils.getValue(membGap.getHmPlnGapClsIndc()));
						scGap.setInfoRcvdtocloseGap(fileUtils.getValue(membGap.getClsGapInfoRcvd()));
						scGap.setGapClsrSCCFId(fileUtils.getValue(membGap.getSccfId()));
						scGap.setClsrSFReceiptDt(fileUtils.getValue(membGap.getClsSfDt()));
						scGap.setProspRetrospId(fileUtils.getValue(membGap.getProsRetIdntCd()));
						scGap.setHostPlanGaplvlClsrInd(fileUtils.getValue(membGap.getHstPlnGapClsIndc()));
						downloadFiles(item.getPexReqtMembQueueSkey(),item.getProvEngmtReqtId());
						scGapsList.add(scGap);
					}
					scGapsList.sort((StarCareGap s1, StarCareGap s2)->s1.getGapId()-s2.getGapId());
					scGapReq.setStarCareGaps(scGapsList);
					scGapReqList.add(scGapReq);
				}
				
				scGapResponseObj.setStarsCareGapReq(scGapReqList);
				ObjectMapper mapper = new ObjectMapper();
				String scJsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(scGapResponseObj);
				LOGGER.info("sc response JSON object: "+scJsonString);
				// Write the response JSON into file.
		        StringBuilder buffer = new StringBuilder();
				buffer.append(scJsonString);
				fileUtils.writeToDatafile(buffer, ApplicationConstants.SC);
			} else {
				fileUtils.writeToZeroByteFile(ApplicationConstants.SC);
			}
		
		}catch (Exception e) {
			LOGGER.error("Error Occuring StarCareItemWriterTasklet --> execute method "+e.getMessage());
		}
		LOGGER.info(":::StarCareItemWriterTasklet -> execute method -> end ::::::::::");
		return RepeatStatus.FINISHED;
	}

	private void downloadFiles(long pexReqtMembQueueSkey, String getProvEngmtReqtId ) {
		List<String> downloadedfiles = new ArrayList<>();
		List<FileAtchDtl> filesToDownload = fileAttchDao.findFilesToDownload(pexReqtMembQueueSkey);

		if(!filesToDownload.isEmpty()){
			for(FileAtchDtl fileDtl:filesToDownload){
				try {
					if(filesToDownload.size()>1){
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}else{
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(getProvEngmtReqtId+"_"+fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}
				} catch (ApplicationException e) {
					LOGGER.error(ExceptionUtils.getStackTrace(e));
				}
			}

			fileUtils.compressFiles(downloadedfiles, getProvEngmtReqtId);
			fileUtils.deleteFiles(downloadedfiles);
		}
	}
}
