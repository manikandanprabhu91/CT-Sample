package com.carefirst.icentric.batch.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the PEX_REQT_ATCH_DTLS database table.
 * 
 */
@Entity
@Table(name="PEX_REQT_ATCH_DTLS")
@NamedQuery(name="PexReqtAtchDtl.findAll", query="SELECT p FROM PexReqtAtchDtl p")
public class PexReqtAtchDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PEX_REQT_ATCH_DTLS_PEXREQTATCHDTLSSKEY_GENERATOR", sequenceName="PEX_REQT_ATCH_DTLS_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PEX_REQT_ATCH_DTLS_PEXREQTATCHDTLSSKEY_GENERATOR")
	@Column(name="PEX_REQT_ATCH_DTLS_SKEY")
	private long pexReqtAtchDtlsSkey;

	@Column(name="ATCH_FILE_TYP")
	private String atchFileTyp;

	@Column(name="ATCH_FILENET_ID")
	private String atchFilenetId;

	@Column(name="ATCH_NM")
	private String atchNm;

	@Column(name="ATCH_SEQ_NBR")
	private BigDecimal atchSeqNbr;

	@Column(name="ATCH_SIZE")
	private BigDecimal atchSize;

	@Column(name="ATCH_UPLDED_BY_FULL_NM")
	private String atchUpldedByFullNm;

	@Column(name="ATCH_UPLDED_BY_ID")
	private String atchUpldedById;

	@Column(name="ATCH_UPLDED_BY_ROLE")
	private String atchUpldedByRole;

	@Column(name="ATCH_UPLDED_TMSTP")
	private Timestamp atchUpldedTmstp;

	@Column(name="ATCH_USER_CMT")
	private String atchUserCmt;

	@Column(name="AUD_INSRT_ID")
	private String audInsrtId;

	@Column(name="AUD_INSRT_TMSTP")
	private Timestamp audInsrtTmstp;

	@Column(name="AUD_UPDT_ID")
	private String audUpdtId;

	@Column(name="AUD_UPDT_TMSTP")
	private Timestamp audUpdtTmstp;

	@Column(name="FILE_PATH")
	private String filePath;

	@Column(name="REFNC_ATCH_STUS_CD")
	private String refncAtchStusCd;

	@Column(name="REFNC_ATCH_STUS_TYP")
	private String refncAtchStusTyp;

	@Column(name="REFNC_FILE_TYP")
	private String refncFileTyp;

	@Column(name="REFNC_FILE_TYP_CD")
	private String refncFileTypCd;

	//bi-directional many-to-one association to PexReqtMembQueue
	@ManyToOne
	@JoinColumn(name="PEX_REQT_MEMB_QUEUE_SKEY")
	private PexReqtMembQueue pexReqtMembQueue;

	public PexReqtAtchDtl() {
	}

	public long getPexReqtAtchDtlsSkey() {
		return this.pexReqtAtchDtlsSkey;
	}

	public void setPexReqtAtchDtlsSkey(long pexReqtAtchDtlsSkey) {
		this.pexReqtAtchDtlsSkey = pexReqtAtchDtlsSkey;
	}

	public String getAtchFileTyp() {
		return this.atchFileTyp;
	}

	public void setAtchFileTyp(String atchFileTyp) {
		this.atchFileTyp = atchFileTyp;
	}

	public String getAtchFilenetId() {
		return this.atchFilenetId;
	}

	public void setAtchFilenetId(String atchFilenetId) {
		this.atchFilenetId = atchFilenetId;
	}

	public String getAtchNm() {
		return this.atchNm;
	}

	public void setAtchNm(String atchNm) {
		this.atchNm = atchNm;
	}

	public BigDecimal getAtchSeqNbr() {
		return this.atchSeqNbr;
	}

	public void setAtchSeqNbr(BigDecimal atchSeqNbr) {
		this.atchSeqNbr = atchSeqNbr;
	}

	public BigDecimal getAtchSize() {
		return this.atchSize;
	}

	public void setAtchSize(BigDecimal atchSize) {
		this.atchSize = atchSize;
	}

	public String getAtchUpldedByFullNm() {
		return this.atchUpldedByFullNm;
	}

	public void setAtchUpldedByFullNm(String atchUpldedByFullNm) {
		this.atchUpldedByFullNm = atchUpldedByFullNm;
	}

	public String getAtchUpldedById() {
		return this.atchUpldedById;
	}

	public void setAtchUpldedById(String atchUpldedById) {
		this.atchUpldedById = atchUpldedById;
	}

	public String getAtchUpldedByRole() {
		return this.atchUpldedByRole;
	}

	public void setAtchUpldedByRole(String atchUpldedByRole) {
		this.atchUpldedByRole = atchUpldedByRole;
	}

	public Timestamp getAtchUpldedTmstp() {
		return this.atchUpldedTmstp;
	}

	public void setAtchUpldedTmstp(Timestamp atchUpldedTmstp) {
		this.atchUpldedTmstp = atchUpldedTmstp;
	}

	public String getAtchUserCmt() {
		return this.atchUserCmt;
	}

	public void setAtchUserCmt(String atchUserCmt) {
		this.atchUserCmt = atchUserCmt;
	}

	public String getAudInsrtId() {
		return this.audInsrtId;
	}

	public void setAudInsrtId(String audInsrtId) {
		this.audInsrtId = audInsrtId;
	}

	public Timestamp getAudInsrtTmstp() {
		return this.audInsrtTmstp;
	}

	public void setAudInsrtTmstp(Timestamp audInsrtTmstp) {
		this.audInsrtTmstp = audInsrtTmstp;
	}

	public String getAudUpdtId() {
		return this.audUpdtId;
	}

	public void setAudUpdtId(String audUpdtId) {
		this.audUpdtId = audUpdtId;
	}

	public Timestamp getAudUpdtTmstp() {
		return this.audUpdtTmstp;
	}

	public void setAudUpdtTmstp(Timestamp audUpdtTmstp) {
		this.audUpdtTmstp = audUpdtTmstp;
	}

	public String getFilePath() {
		return this.filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public String getRefncAtchStusCd() {
		return this.refncAtchStusCd;
	}

	public void setRefncAtchStusCd(String refncAtchStusCd) {
		this.refncAtchStusCd = refncAtchStusCd;
	}

	public String getRefncAtchStusTyp() {
		return this.refncAtchStusTyp;
	}

	public void setRefncAtchStusTyp(String refncAtchStusTyp) {
		this.refncAtchStusTyp = refncAtchStusTyp;
	}

	public String getRefncFileTyp() {
		return this.refncFileTyp;
	}

	public void setRefncFileTyp(String refncFileTyp) {
		this.refncFileTyp = refncFileTyp;
	}

	public String getRefncFileTypCd() {
		return this.refncFileTypCd;
	}

	public void setRefncFileTypCd(String refncFileTypCd) {
		this.refncFileTypCd = refncFileTypCd;
	}

	public PexReqtMembQueue getPexReqtMembQueue() {
		return this.pexReqtMembQueue;
	}

	public void setPexReqtMembQueue(PexReqtMembQueue pexReqtMembQueue) {
		this.pexReqtMembQueue = pexReqtMembQueue;
	}

}