
package com.carefirst.icentric.batch.starcare.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
    "GapId",
    "GapMeasure",
    "GapIdentificationRationale",
    "RequestedAction",
    "AddlInfotoHostPlan",
    "HomePlanGaplvlClsrInd",
    "InfoRcvdtocloseGap",
    "GapClsrSCCFId",
    "ClsrSFReceiptDt",
    "ProspRetrospId",
    "HostPlanGaplvlClsrInd"
})
public class StarCareGap {

    @JsonProperty("GapId")
    private int gapId;
    @JsonProperty("GapMeasure")
    private String gapMeasure;
    @JsonProperty("GapIdentificationRationale")
    private String gapIdentificationRationale;
    @JsonProperty("RequestedAction")
    private String requestedAction;
    @JsonProperty("AddlInfotoHostPlan")
    private String addlInfotoHostPlan;
    @JsonProperty("HomePlanGaplvlClsrInd")
    private String homePlanGaplvlClsrInd;
    @JsonProperty("InfoRcvdtocloseGap")
    private String infoRcvdtocloseGap;
    @JsonProperty("GapClsrSCCFId")
    private String gapClsrSCCFId;
    @JsonProperty("ClsrSFReceiptDt")
    private String clsrSFReceiptDt;
    @JsonProperty("ProspRetrospId")
    private String prospRetrospId;
    @JsonProperty("HostPlanGaplvlClsrInd")
    private String hostPlanGaplvlClsrInd;

    /**
     * No args constructor for use in serialization
     * 
     */
    public StarCareGap() {
    }

    /**
     * 
     * @param gapClsrSCCFId
     * @param gapIdentificationRationale
     * @param clsrSFReceiptDt
     * @param requestedAction
     * @param gapId
     * @param prospRetrospId
     * @param hostPlanGaplvlClsrInd
     * @param homePlanGaplvlClsrInd
     * @param gapMeasure
     * @param addlInfotoHostPlan
     * @param infoRcvdtocloseGap
     */
    public StarCareGap(int gapId, String gapMeasure, String gapIdentificationRationale, String requestedAction, String addlInfotoHostPlan, String homePlanGaplvlClsrInd, String infoRcvdtocloseGap, String gapClsrSCCFId, String clsrSFReceiptDt, String prospRetrospId, String hostPlanGaplvlClsrInd) {
        super();
        this.gapId = gapId;
        this.gapMeasure = gapMeasure;
        this.gapIdentificationRationale = gapIdentificationRationale;
        this.requestedAction = requestedAction;
        this.addlInfotoHostPlan = addlInfotoHostPlan;
        this.homePlanGaplvlClsrInd = homePlanGaplvlClsrInd;
        this.infoRcvdtocloseGap = infoRcvdtocloseGap;
        this.gapClsrSCCFId = gapClsrSCCFId;
        this.clsrSFReceiptDt = clsrSFReceiptDt;
        this.prospRetrospId = prospRetrospId;
        this.hostPlanGaplvlClsrInd = hostPlanGaplvlClsrInd;
    }

    @JsonProperty("GapId")
    public int getGapId() {
        return gapId;
    }

    @JsonProperty("GapId")
    public void setGapId(int gapId) {
        this.gapId = gapId;
    }

    @JsonProperty("GapMeasure")
    public String getGapMeasure() {
        return gapMeasure;
    }

    @JsonProperty("GapMeasure")
    public void setGapMeasure(String gapMeasure) {
        this.gapMeasure = gapMeasure;
    }

    @JsonProperty("GapIdentificationRationale")
    public String getGapIdentificationRationale() {
        return gapIdentificationRationale;
    }

    @JsonProperty("GapIdentificationRationale")
    public void setGapIdentificationRationale(String gapIdentificationRationale) {
        this.gapIdentificationRationale = gapIdentificationRationale;
    }

    @JsonProperty("RequestedAction")
    public String getRequestedAction() {
        return requestedAction;
    }

    @JsonProperty("RequestedAction")
    public void setRequestedAction(String requestedAction) {
        this.requestedAction = requestedAction;
    }

    @JsonProperty("AddlInfotoHostPlan")
    public String getAddlInfotoHostPlan() {
        return addlInfotoHostPlan;
    }

    @JsonProperty("AddlInfotoHostPlan")
    public void setAddlInfotoHostPlan(String addlInfotoHostPlan) {
        this.addlInfotoHostPlan = addlInfotoHostPlan;
    }

    @JsonProperty("HomePlanGaplvlClsrInd")
    public String getHomePlanGaplvlClsrInd() {
        return homePlanGaplvlClsrInd;
    }

    @JsonProperty("HomePlanGaplvlClsrInd")
    public void setHomePlanGaplvlClsrInd(String homePlanGaplvlClsrInd) {
        this.homePlanGaplvlClsrInd = homePlanGaplvlClsrInd;
    }

    @JsonProperty("InfoRcvdtocloseGap")
    public String getInfoRcvdtocloseGap() {
        return infoRcvdtocloseGap;
    }

    @JsonProperty("InfoRcvdtocloseGap")
    public void setInfoRcvdtocloseGap(String infoRcvdtocloseGap) {
        this.infoRcvdtocloseGap = infoRcvdtocloseGap;
    }

    @JsonProperty("GapClsrSCCFId")
    public String getGapClsrSCCFId() {
        return gapClsrSCCFId;
    }

    @JsonProperty("GapClsrSCCFId")
    public void setGapClsrSCCFId(String gapClsrSCCFId) {
        this.gapClsrSCCFId = gapClsrSCCFId;
    }

    @JsonProperty("ClsrSFReceiptDt")
    public String getClsrSFReceiptDt() {
        return clsrSFReceiptDt;
    }

    @JsonProperty("ClsrSFReceiptDt")
    public void setClsrSFReceiptDt(String clsrSFReceiptDt) {
        this.clsrSFReceiptDt = clsrSFReceiptDt;
    }

    @JsonProperty("ProspRetrospId")
    public String getProspRetrospId() {
        return prospRetrospId;
    }

    @JsonProperty("ProspRetrospId")
    public void setProspRetrospId(String prospRetrospId) {
        this.prospRetrospId = prospRetrospId;
    }

    @JsonProperty("HostPlanGaplvlClsrInd")
    public String getHostPlanGaplvlClsrInd() {
        return hostPlanGaplvlClsrInd;
    }

    @JsonProperty("HostPlanGaplvlClsrInd")
    public void setHostPlanGaplvlClsrInd(String hostPlanGaplvlClsrInd) {
        this.hostPlanGaplvlClsrInd = hostPlanGaplvlClsrInd;
    }

}
