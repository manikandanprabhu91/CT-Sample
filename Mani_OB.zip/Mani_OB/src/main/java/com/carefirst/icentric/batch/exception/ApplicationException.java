package com.carefirst.icentric.batch.exception;

public class ApplicationException extends Exception {

	private static final long serialVersionUID = 7960665440854167984L;

	private String errorCode;

	public String getErrorCode() {
		return errorCode;
	}

	/**
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public ApplicationException(String message) {
		super(message);
	}

	public ApplicationException(String message, String errorCode) {
		super(message);
		this.setErrorCode(errorCode);
	}

	public ApplicationException(String message, Throwable e, String errorCode) {
		super(message, e);
		this.setErrorCode(errorCode);
	}

}
