package com.carefirst.icentric.batch.service;


import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.ws.BindingProvider;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.carefirst.broker.compensation.edms.gen.DocumentManagementPort;
import com.carefirst.broker.compensation.edms.gen.DocumentManagementServiceServiceagent;
import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocRequest;
import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocResponse;
import com.carefirst.eapmca.controller.PMConnector;
import com.carefirst.icentric.batch.config.EDMSConfig;
import com.carefirst.icentric.batch.exception.ApplicationException;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

@Service
public class EDMSServiceImpl implements EDMSService{

	private static final Logger logger = LoggerFactory.getLogger(EDMSServiceImpl.class);

	private final EDMSConfig properties;

	@Autowired
	public EDMSServiceImpl(EDMSConfig properties) {
		this.properties = properties;
	}	
	
	DocumentManagementPort documentManagementPort = null;

	
public GetDocResponse downloadFile(String filenetId) throws ApplicationException{
	    logger.info("Starting downloadFile");
		URL wsdlurl = null;
		try {
			wsdlurl = new URL(properties.getWsdlUrl());
		} catch (MalformedURLException e) {
			logger.error("Invalid service configuration");
			throw new ApplicationException("Invalid Config. Please contact the support team.", e, "ERROR_INVALID_CONFIG");
		}

		DocumentManagementServiceServiceagent ds = new DocumentManagementServiceServiceagent(wsdlurl);
		documentManagementPort = ds.getDocumentManagementPortEndpoint();

		// Invoking EDMS Service to Update document status
		
		try {
			BindingProvider bp = (BindingProvider) documentManagementPort;
			bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, properties.getEndPoint());

			String username = PMConnector.getConnector().getUserName(properties.getVaultQuery());
			if(logger.isInfoEnabled()){
			logger.info("UserName: " + username);
			}
			String password = PMConnector.getConnector().getContent(properties.getVaultQuery());
			if (StringUtils.isBlank(password)) {
				logger.info("Password not retrieved from vault");
			}
			
			bp.getRequestContext().put(BindingProvider.USERNAME_PROPERTY, username);
			bp.getRequestContext().put(BindingProvider.PASSWORD_PROPERTY, password);

		} catch (Exception e) {
			logger.error("Invalid service configuration");
			throw new ApplicationException("Invalid Config.Please contact the support team.", e, "INVALID_CONFIG");
		}

		GetDocRequest getDocumentRequest = new GetDocRequest();
		
		
		com.carefirst.broker.compensation.edms.gen.getdoc.GetDocRequest.Body body = new com.carefirst.broker.compensation.edms.gen.getdoc.GetDocRequest.Body();
		body.setGuid(filenetId);
		getDocumentRequest.setBody(body);
		XStream xstream = new XStream(new DomDriver());
		if(logger.isInfoEnabled()){
		logger.info("getDocumentRequest ::" + xstream.toXML(getDocumentRequest));
		}
		GetDocResponse getDocResponse = null;
		try {
			
			 getDocResponse = documentManagementPort.getDocument(getDocumentRequest);
		} catch (Exception e) {
			logger.error("EDMS Webservice service Error: " + e.getMessage());
			throw new ApplicationException("WEBSERVICE ERROR", e, "WEBSERVICE_ERROR");
		}
		logger.info("Exiting downloadFile");
		return getDocResponse;
		
	}
	
	

}
