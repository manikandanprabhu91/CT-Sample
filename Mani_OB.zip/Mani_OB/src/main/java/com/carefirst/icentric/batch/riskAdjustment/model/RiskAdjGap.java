
package com.carefirst.icentric.batch.riskAdjustment.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
    "GapId",
    "RiskAdjGapType",
    "MissingDiagCd",
    "MissingDiagCdDesc",
    "MissingHCCCd",
    "MissingHCCCdDesc",
    "HCCClaimType",
    "MissingDiagCdServDt",
    "MissingDiagCdProvNPI",
    "GapIdentificationRationale",
    "ProspRetrospId",
    "RequestedAction",
    "HomePlanGaplvlClsrInd",
    "InfoRcvdtocloseGap",
    "GapClsrSCCFId",
    "ClsrSFReceiptDt",
    "HostPlanGaplvlClsrInd"
})
public class RiskAdjGap {

    @JsonProperty("GapId")
    private int gapId;
    @JsonProperty("RiskAdjGapType")
    private String riskAdjGapType;
    @JsonProperty("MissingDiagCd")
    private String missingDiagCd;
    @JsonProperty("MissingDiagCdDesc")
    private String missingDiagCdDesc;
    @JsonProperty("MissingHCCCd")
    private String missingHCCCd;
    @JsonProperty("MissingHCCCdDesc")
    private String missingHCCCdDesc;
    @JsonProperty("HCCClaimType")
    private String hCCClaimType;
    @JsonProperty("MissingDiagCdServDt")
    private String missingDiagCdServDt;
    @JsonProperty("MissingDiagCdProvNPI")
    private String missingDiagCdProvNPI;
    @JsonProperty("GapIdentificationRationale")
    private String gapIdentificationRationale;
    @JsonProperty("ProspRetrospId")
    private String prospRetrospId;
    @JsonProperty("RequestedAction")
    private String requestedAction;
    @JsonProperty("HomePlanGaplvlClsrInd")
    private String homePlanGaplvlClsrInd;
    @JsonProperty("InfoRcvdtocloseGap")
    private String infoRcvdtocloseGap;
    @JsonProperty("GapClsrSCCFId")
    private String gapClsrSCCFId;
    @JsonProperty("ClsrSFReceiptDt")
    private String clsrSFReceiptDt;
    @JsonProperty("HostPlanGaplvlClsrInd")
    private String hostPlanGaplvlClsrInd;

    /**
     * No args constructor for use in serialization
     * 
     */
    public RiskAdjGap() {
    }

    /**
     * 
     * @param missingDiagCdServDt
     * @param gapClsrSCCFId
     * @param missingDiagCd
     * @param gapId
     * @param missingDiagCdProvNPI
     * @param hostPlanGaplvlClsrInd
     * @param homePlanGaplvlClsrInd
     * @param riskAdjGapType
     * @param missingDiagCdDesc
     * @param missingHCCCd
     * @param gapIdentificationRationale
     * @param clsrSFReceiptDt
     * @param requestedAction
     * @param hCCClaimType
     * @param prospRetrospId
     * @param infoRcvdtocloseGap
     * @param missingHCCCdDesc
     */
    public RiskAdjGap(int gapId, String riskAdjGapType, String missingDiagCd, String missingDiagCdDesc, String missingHCCCd, String missingHCCCdDesc, String hCCClaimType, String missingDiagCdServDt, String missingDiagCdProvNPI, String gapIdentificationRationale, String prospRetrospId, String requestedAction, String homePlanGaplvlClsrInd, String infoRcvdtocloseGap, String gapClsrSCCFId, String clsrSFReceiptDt, String hostPlanGaplvlClsrInd) {
        super();
        this.gapId = gapId;
        this.riskAdjGapType = riskAdjGapType;
        this.missingDiagCd = missingDiagCd;
        this.missingDiagCdDesc = missingDiagCdDesc;
        this.missingHCCCd = missingHCCCd;
        this.missingHCCCdDesc = missingHCCCdDesc;
        this.hCCClaimType = hCCClaimType;
        this.missingDiagCdServDt = missingDiagCdServDt;
        this.missingDiagCdProvNPI = missingDiagCdProvNPI;
        this.gapIdentificationRationale = gapIdentificationRationale;
        this.prospRetrospId = prospRetrospId;
        this.requestedAction = requestedAction;
        this.homePlanGaplvlClsrInd = homePlanGaplvlClsrInd;
        this.infoRcvdtocloseGap = infoRcvdtocloseGap;
        this.gapClsrSCCFId = gapClsrSCCFId;
        this.clsrSFReceiptDt = clsrSFReceiptDt;
        this.hostPlanGaplvlClsrInd = hostPlanGaplvlClsrInd;
    }

    @JsonProperty("GapId")
    public int getGapId() {
        return gapId;
    }

    @JsonProperty("GapId")
    public void setGapId(int gapId) {
        this.gapId = gapId;
    }

    @JsonProperty("RiskAdjGapType")
    public String getRiskAdjGapType() {
        return riskAdjGapType;
    }

    @JsonProperty("RiskAdjGapType")
    public void setRiskAdjGapType(String riskAdjGapType) {
        this.riskAdjGapType = riskAdjGapType;
    }

    @JsonProperty("MissingDiagCd")
    public String getMissingDiagCd() {
        return missingDiagCd;
    }

    @JsonProperty("MissingDiagCd")
    public void setMissingDiagCd(String missingDiagCd) {
        this.missingDiagCd = missingDiagCd;
    }

    @JsonProperty("MissingDiagCdDesc")
    public String getMissingDiagCdDesc() {
        return missingDiagCdDesc;
    }

    @JsonProperty("MissingDiagCdDesc")
    public void setMissingDiagCdDesc(String missingDiagCdDesc) {
        this.missingDiagCdDesc = missingDiagCdDesc;
    }

    @JsonProperty("MissingHCCCd")
    public String getMissingHCCCd() {
        return missingHCCCd;
    }

    @JsonProperty("MissingHCCCd")
    public void setMissingHCCCd(String missingHCCCd) {
        this.missingHCCCd = missingHCCCd;
    }

    @JsonProperty("MissingHCCCdDesc")
    public String getMissingHCCCdDesc() {
        return missingHCCCdDesc;
    }

    @JsonProperty("MissingHCCCdDesc")
    public void setMissingHCCCdDesc(String missingHCCCdDesc) {
        this.missingHCCCdDesc = missingHCCCdDesc;
    }

    @JsonProperty("HCCClaimType")
    public String getHCCClaimType() {
        return hCCClaimType;
    }

    @JsonProperty("HCCClaimType")
    public void setHCCClaimType(String hCCClaimType) {
        this.hCCClaimType = hCCClaimType;
    }

    @JsonProperty("MissingDiagCdServDt")
    public String getMissingDiagCdServDt() {
        return missingDiagCdServDt;
    }

    @JsonProperty("MissingDiagCdServDt")
    public void setMissingDiagCdServDt(String missingDiagCdServDt) {
        this.missingDiagCdServDt = missingDiagCdServDt;
    }

    @JsonProperty("MissingDiagCdProvNPI")
    public String getMissingDiagCdProvNPI() {
        return missingDiagCdProvNPI;
    }

    @JsonProperty("MissingDiagCdProvNPI")
    public void setMissingDiagCdProvNPI(String missingDiagCdProvNPI) {
        this.missingDiagCdProvNPI = missingDiagCdProvNPI;
    }

    @JsonProperty("GapIdentificationRationale")
    public String getGapIdentificationRationale() {
        return gapIdentificationRationale;
    }

    @JsonProperty("GapIdentificationRationale")
    public void setGapIdentificationRationale(String gapIdentificationRationale) {
        this.gapIdentificationRationale = gapIdentificationRationale;
    }

    @JsonProperty("ProspRetrospId")
    public String getProspRetrospId() {
        return prospRetrospId;
    }

    @JsonProperty("ProspRetrospId")
    public void setProspRetrospId(String prospRetrospId) {
        this.prospRetrospId = prospRetrospId;
    }

    @JsonProperty("RequestedAction")
    public String getRequestedAction() {
        return requestedAction;
    }

    @JsonProperty("RequestedAction")
    public void setRequestedAction(String requestedAction) {
        this.requestedAction = requestedAction;
    }

    @JsonProperty("HomePlanGaplvlClsrInd")
    public String getHomePlanGaplvlClsrInd() {
        return homePlanGaplvlClsrInd;
    }

    @JsonProperty("HomePlanGaplvlClsrInd")
    public void setHomePlanGaplvlClsrInd(String homePlanGaplvlClsrInd) {
        this.homePlanGaplvlClsrInd = homePlanGaplvlClsrInd;
    }

    @JsonProperty("InfoRcvdtocloseGap")
    public String getInfoRcvdtocloseGap() {
        return infoRcvdtocloseGap;
    }

    @JsonProperty("InfoRcvdtocloseGap")
    public void setInfoRcvdtocloseGap(String infoRcvdtocloseGap) {
        this.infoRcvdtocloseGap = infoRcvdtocloseGap;
    }

    @JsonProperty("GapClsrSCCFId")
    public String getGapClsrSCCFId() {
        return gapClsrSCCFId;
    }

    @JsonProperty("GapClsrSCCFId")
    public void setGapClsrSCCFId(String gapClsrSCCFId) {
        this.gapClsrSCCFId = gapClsrSCCFId;
    }

    @JsonProperty("ClsrSFReceiptDt")
    public String getClsrSFReceiptDt() {
        return clsrSFReceiptDt;
    }

    @JsonProperty("ClsrSFReceiptDt")
    public void setClsrSFReceiptDt(String clsrSFReceiptDt) {
        this.clsrSFReceiptDt = clsrSFReceiptDt;
    }

    @JsonProperty("HostPlanGaplvlClsrInd")
    public String getHostPlanGaplvlClsrInd() {
        return hostPlanGaplvlClsrInd;
    }

    @JsonProperty("HostPlanGaplvlClsrInd")
    public void setHostPlanGaplvlClsrInd(String hostPlanGaplvlClsrInd) {
        this.hostPlanGaplvlClsrInd = hostPlanGaplvlClsrInd;
    }

}
