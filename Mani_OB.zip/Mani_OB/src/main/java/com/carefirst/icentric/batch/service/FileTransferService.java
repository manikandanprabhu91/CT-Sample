/**
 * 
 */
package com.carefirst.icentric.batch.service;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;

/**
 * @author aab0490
 *
 */
public interface FileTransferService {
	
	public boolean transferFile(byte[] byteStream, String sftpWorkingDir, String fileName, Channel channel, ChannelSftp channelSftp) throws Exception;
	
	public Session ftpServerConnection() throws Exception;

}
