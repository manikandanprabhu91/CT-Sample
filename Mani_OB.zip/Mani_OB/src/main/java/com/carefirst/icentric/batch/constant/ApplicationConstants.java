package com.carefirst.icentric.batch.constant;

public class ApplicationConstants {

	public static final String STRING_PROPERTY_DATA_TYPE = "String";
	public static final String DATE_PROPERTY_DATA_TYPE = "Date";
	public static final String CLASS_NAME = "ClinicalInnovations";
	public static final String DOCUMENT_TITLE = "DocumentTitle";
	public static final String ACTIVITY = "Activity";
	public static final String SUB_PROCESS = "Sub_Process";
	public static final String UNIT = "Unit";
	public static final String PROCESS = "Process";
	public static final String SUB_DEPARTMENT = "Sub_Department";
	public static final String DEPARTMENT = "Department";
	public static final String REPORT_TYPE = "ReportType";
	public static final String REPORT_NAME = "ReportName";
	public static final String REPORT_DATE = "ReportDate";
	public static final String ACTIVITY_NAME = "Uploads";
	public static final String DEPARTMENT_NAME = "Medical Mgmt";
	public static final String SUB_DEPARTMENT_NAME ="Clinical Innovations";
	public static final String PROCESS_NAME = "Plan & Manage Care";
	public static final String REPORT_TYPE_PSF = "";
	public static final String DOCUMENTTITLE = "DocumentTitle";
	public static final String CASEID = "CaseID";
	
	public static final String DOCUMENT_STATUS = "DocumentStatus";
	public static final String DOCUMENT_TYPE = "DocumentType";
	public static final String PROVIDER_NAME = "ProviderName";
	public static final String TAXID = "TaxID";
	public static final String SOURCE = "Source";
	public static final String PROVIDER_PORTAL = "ProviderPortal";
	public static final String MEMBER_PORTAL = "MemberPortal";
	public static final String BROKER_PORTAL = "BrokerPortal";
	public static final String EMPLOYER_PORTAL = "EmployerPortal";
	public static final String ASSOCIATE_PORTAL = "AssociatePortal";
	
	public static final String DOCUMENT_STATUS_NAME = "Pending";
	public static final String SOURCE_NAME = "BCBSA";
	public static final String PROVIDER_PORTAL_NAME = "Show";
	public static final String HIDE = "Hide";
	public static final String REPORTDATE_FORMAT = "MMM dd, yyyy";
	public static final String OPEN = "PEX_REQT_STUS01";
	public static final String IN_PROGRESS = "PEX_REQT_STUS02";
	public static final String PENDING_CLOSURE = "PEX_REQT_STUS03";
	public static final String CLOSED_STATUS = "PEX_REQT_STUS04";
	public static final String MR = "MR";
	public static final String SC = "SC";
	public static final String RA = "RA"; 
}
