package com.carefirst.icentric.batch.medicalRecord.tasklet;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.forwardedUrl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocResponse;
import com.carefirst.icentric.batch.constant.ApplicationConstants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.FileAtchDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.medicalRecord.model.LastMedRecReqServRangeDts;
import com.carefirst.icentric.batch.medicalRecord.model.MedRecReq;
import com.carefirst.icentric.batch.medicalRecord.model.MedRecResponseObj;
import com.carefirst.icentric.batch.medicalRecord.model.MemberPCP5PartKey;
import com.carefirst.icentric.batch.medicalRecord.model.ServRangeDts;
import com.carefirst.icentric.batch.service.EDMSService;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to generate MedicalRecord json
 * @author aad7740
 *
 */
public class MedicalRecordItemWriterTasklet  implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(MedicalRecordItemWriterTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	FileAtchDtlDAO fileAttchDao;

	@Autowired
	EDMSService edmsService;

	@Autowired
	FileUtils fileUtils;

	@Override
	public void beforeStep(StepExecution stepExecution) {
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info(":::MedicalRecordItemWriterTasklet -> execute method -> start ::::::::::");
		try {
			List<PexReqtMembQueue> membQueues = pexReqtMembQueueDAO.getPexReqtMembQueueRecordsBasedonStatus(ApplicationConstants.MR, ApplicationConstants.CLOSED_STATUS);
			MedRecResponseObj medRecResponseObj = new MedRecResponseObj();
			List<MedRecReq> mrReqList = new ArrayList<>();
			if(!membQueues.isEmpty()) {
				for(PexReqtMembQueue item : membQueues) {
					MedRecReq mrReq = new MedRecReq();
					mrReq.setProvEngmntReqId(fileUtils.getValue(item.getProvEngmtReqtId()));
					mrReq.setCapabilityInd(fileUtils.getValue(item.getCpbltyIndcCd()));
					mrReq.setMedRecReqType(fileUtils.getValue(item.getMedRecTypCd()));
					mrReq.setHomePlanId(fileUtils.getValue(item.getHmPlanId()));
					mrReq.setMemberHostPlanId(fileUtils.getValue(item.getMembHstPlnId()));
					mrReq.setRoutetoHostPlanId(fileUtils.getValue(item.getRoutHstPlnId()));
					mrReq.setFirstTimeSenttoHostPlanDt(fileUtils.getValue(item.getIntlHstPlnDt()));
					mrReq.setLastMRRProvEngmntReqID(fileUtils.getValue(item.getLastMrrProvEngmtRetId()));
					mrReq.setLastMedRecReqRcptDt(fileUtils.getValue(item.getLastMedRecReqtDt()));
					mrReq.setHostPlanClsrInd(fileUtils.getValue(item.getHstPlnClsInd()));

					LastMedRecReqServRangeDts lastMedRecReqServRangeDts = new LastMedRecReqServRangeDts();
					lastMedRecReqServRangeDts.setLastMedRecReqServBeginDt(fileUtils.getValue(item.getLastMedRecReqtBegDt()));
					lastMedRecReqServRangeDts.setLastMedRecReqServEndDt(fileUtils.getValue(item.getLastMedRecReqtEndDt()));
					mrReq.setLastMedRecReqServRangeDts(lastMedRecReqServRangeDts);

					mrReq.setITSSubscriberId(fileUtils.getValue(item.getItsSubscrId()));
					mrReq.setMemberDOB(fileUtils.getValue(item.getMembDob()));
					mrReq.setMMIId(fileUtils.getValue(item.getMmiId()));
					mrReq.setMemberFullName(fileUtils.getValue(item.getMembFullNm()));
					mrReq.setMemberGender(fileUtils.getValue(item.getMembGndr()));
					mrReq.setBillProvProprietaryId(fileUtils.getValue(item.getBillProvId()));
					mrReq.setRndrngProvProprietaryId(fileUtils.getValue(item.getRndrProvId()));
					mrReq.setBillProvNPI(fileUtils.getValue(item.getBillProvNpi()));
					mrReq.setRndrngProvNPI(fileUtils.getValue(item.getRndrProvNpi()));
					mrReq.setRndrngProvHostPlanId(fileUtils.getValue(item.getRndrProvHstPlnId()));
					mrReq.setBillProvZipCode(fileUtils.getValue(item.getBillProvZipCd()));
					mrReq.setRndrngProvZipCode(fileUtils.getValue(item.getRndrProvZipCd()));
					mrReq.setRndrngProvTxnmyCd(fileUtils.getValue(item.getRndrProvTnxmyCd()));
					mrReq.setSCCFIds(fileUtils.getValue(item.getSccfId()));

					MemberPCP5PartKey memberPCP5PartKey = new MemberPCP5PartKey();
					memberPCP5PartKey.setProvPlanCd(fileUtils.getValue(item.getProvPlnCd()));
					memberPCP5PartKey.setProductCd(fileUtils.getValue(item.getProvProdCd()));
					memberPCP5PartKey.setProvNum(fileUtils.getValue(item.getProvNum()));
					memberPCP5PartKey.setProvNumSuffix(fileUtils.getValue(item.getProvSufx()));
					memberPCP5PartKey.setProvNetwrkLocSeqNum(fileUtils.getValue(item.getProvNtwrkLoc()));
					mrReq.setMemberPCP5PartKey(memberPCP5PartKey);

					ServRangeDts servRangeDts = new ServRangeDts();
					servRangeDts.setServBeginDt(fileUtils.getValue(item.getServcBegDt()));
					servRangeDts.setServEndDt(fileUtils.getValue(item.getServcEndDt()));
					mrReq.setServRangeDts(servRangeDts);

					mrReq.setHomePlanClsrInd(fileUtils.getValue(item.getHmPlanClsInd()));
					mrReq.setProvEngagementInd(fileUtils.getValue(item.getProvEngmtIndc()));
					mrReq.setProvCntrctingSts(fileUtils.getValue(item.getProvPartStus()));
					mrReq.setHostPlanMedRecMatchInd(fileUtils.getValue(item.getMedRecMtchIndc()));
					mrReq.setRndrngProvTaxId(fileUtils.getValue(item.getRndrProvTaxId()));
					mrReq.setRndrngProvAddlInfo(fileUtils.getValue(item.getAddnlInfo()));
					mrReq.setHedisMRRMeasurementType(fileUtils.getValue(item.getHedisMeasmtTyp()));
					List<String> servDts = new ArrayList<>();
					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
					SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
					if(item.getServcDt() != null) {
						List<String> datesList = Arrays.asList(item.getServcDt().split("\\s*,\\s*"));
						for(String servDt:datesList) {
							servDts.add(dateFormat.format(format.parse(servDt)));	
						}
						
						if(servDts.size() <= 9) {
							for(int i = servDts.size(); i <= 9; i++) {
								servDts.add(null);
							}
						}
					} else{
						for(int i = 0; i <= 9; i++) {
							servDts.add(null);
						}
					}
					mrReq.setServDts(servDts);
					downloadFiles(item.getPexReqtMembQueueSkey(),item.getProvEngmtReqtId());
					mrReqList.add(mrReq);
				}
				medRecResponseObj.setMedRecReq(mrReqList);
				ObjectMapper mapper = new ObjectMapper();
				String mrJsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(medRecResponseObj);
				LOGGER.info("mr response JSON object: " + mrJsonString);

				// Write the response JSON into file.
				StringBuilder buffer = new StringBuilder();
				buffer.append(mrJsonString);
				fileUtils.writeToDatafile(buffer, ApplicationConstants.MR);

			} else {
				fileUtils.writeToZeroByteFile(ApplicationConstants.MR);
			}

		} catch (Exception e) {
			LOGGER.error("::::::::::::Error Occuring MedicalRecord Writter execute method ::::::::::::::::" +e.getMessage());
		}
		LOGGER.info(":::MedicalRecordItemWriterTasklet -> execute method -> End ::::::::::");
		return RepeatStatus.FINISHED;
	}
	private void downloadFiles(long pexReqtMembQueueSkey, String getProvEngmtReqtId ) {
		List<String> downloadedfiles = new ArrayList<>();
		List<FileAtchDtl> filesToDownload = fileAttchDao.findFilesToDownload(pexReqtMembQueueSkey);

		if(!filesToDownload.isEmpty()){
			for(FileAtchDtl fileDtl:filesToDownload){
				try {
					if(filesToDownload.size()>1){
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}else{
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(getProvEngmtReqtId+"_"+fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}
				} catch (ApplicationException e) {
					LOGGER.error(ExceptionUtils.getStackTrace(e));
				}
			}

			fileUtils.compressFiles(downloadedfiles, getProvEngmtReqtId);
			fileUtils.deleteFiles(downloadedfiles);
		}
	}

}
