package com.carefirst.icentric.batch.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

@Component
public class FileUtils {

	private static final Logger logger = LogManager.getLogger(FileUtils.class);

	@Value("${medvantage.outbound.path}")
	private String outBoundPath;

	@Value("${medvantage.outbound.archive.path}")
	private String archivePath;


	// File types are sc, ra and mr
	public List<FileSystemResource> getFilesToArchive(String fileType) {
		File directoryPath = new File(outBoundPath);
		List<FileSystemResource> fileSystemResourcePath = new ArrayList<>();
		try {

			File[] files = directoryPath.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return (name.toLowerCase().contains(fileType.toLowerCase()));
				}
			});
			if(files != null) {
				for (File file : files) {
					if (!file.getName().isEmpty()) {
						fileSystemResourcePath.add(new FileSystemResource(file.getPath()));
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while getFilesToArchive method " + e);
			e.printStackTrace();

		}
		return fileSystemResourcePath;
	}

	public String getValue(String value) {
		return (StringUtils.isEmpty(value) ? "" : value);
	}

	public void archiveOldOutboundFiles(String fileType, String fileName) throws IOException{
		logger.info(":::::::::::archiveOldOutboundFiles start>>>>> :::::::::::::: ");
		try {
			List<FileSystemResource> files = getFilesToArchive(fileType);
			logger.info(":::::::::::archiveOldOutboundFiles FileSystemResource files>>>> :::::::::::::: "+files.size());
			if(files != null) {
				for(FileSystemResource file:files){
					logger.info(":::::::::::archiveOldOutboundFiles FileSystemResource file>>>> :::::::::::::: "+file);
					Path fileToMovePath = Paths.get(file.getPath());
					logger.info(":::::::::::archiveOldOutboundFiles file fileToMovePath>>>> :::::::::::::: "+fileToMovePath);
					Path targetPath = Paths.get(archivePath);
					logger.info(":::::::::::archiveOldOutboundFiles file targetPath>>>> :::::::::::::: "+targetPath);
					if(fileName.equals(file.getFilename())) {
						Files.move(fileToMovePath, targetPath.resolve(fileToMovePath.getFileName()), StandardCopyOption.REPLACE_EXISTING);	
					}
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
			logger.error("Error occur while archiveOldOutboundFiles method " + ex.getMessage());
			logger.error(ExceptionUtils.getStackTrace(ex));
			throw ex;
		}

	}

	public void writeToDatafile(StringBuilder buffer, String capabilityId) throws IOException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
		String dateFormat = sdf.format(new Date().getTime());
		File f = new File(outBoundPath + File.separator + "690" + "_" + capabilityId.toLowerCase()  + "_" + dateFormat + ".json");

		try (BufferedWriter bwr = new BufferedWriter(new FileWriter(f))) {
			bwr.write(buffer.toString());
			bwr.flush();
		} catch (Exception e) {
			logger.error("Error while creating response file " + e);
		}

	}

	public void writeToZeroByteFile(String capabilityId){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
		String dateFormat = sdf.format(new Date().getTime());
		try {
			File f = new File(outBoundPath + File.separator + "690" + "_" + capabilityId.toLowerCase()  + "_" + dateFormat + ".json");
			f.createNewFile();
		}catch (Exception e) {
			logger.error("Error while creating ZeroByte file " + e);
		}

	}

	// util to zip files
	public void compressFiles(List<String> downloadedfiles, String zipflinename) {
		File directoryPath = new File(outBoundPath);
		File[] files = directoryPath.listFiles();
		List<File> zipFiles = new ArrayList<>();
		if(downloadedfiles.size()>1){
			for (File file : files) {
				for (String downloadedFile : downloadedfiles) {
					if (file.getName().equalsIgnoreCase(downloadedFile)) {
						zipFiles.add(file);
						break;
					}
				}
			}
			try {
				zipMethod(zipFiles, zipflinename);
			} catch (FileNotFoundException e) {
				logger.error("Error while zipping attachments " + e);
			} catch (IOException e) {
				logger.error("Error while zipping attachments " + e);
			}
		}
	}

	private void zipMethod(List<File> files, String zipflinename) throws FileNotFoundException, IOException {
		File output = new File(outBoundPath + File.separator + zipflinename + ".gz");
		GZIPOutputStream out = new GZIPOutputStream(new FileOutputStream(output));
		try {
			if(files.size()>1){
				for (File file : files) {
					FileInputStream in = new FileInputStream(file);
					byte[] buffer = new byte[1024];
					int len;
					while ((len = in.read(buffer)) != -1) {
						out.write(buffer, 0, len);
					}
					in.close();
				}
				out.close();
			}
		} catch (Exception e) {
			logger.error("Error while zipping attachments " + e);
		}
	}

	public void deleteFiles(List<String> downloadedfiles) {
		File directoryPath = new File(outBoundPath);
		File[] files = directoryPath.listFiles();
		if(downloadedfiles.size()>1){
			for (File file : files) {

				for (String downloadedFile : downloadedfiles) {
					if (file.getName().equalsIgnoreCase(downloadedFile)) {
						file.delete();
						break;
					}
				}
			}
		}
	}

	public void saveFileNetFile(String docTitle, byte[] docData) {
		File file = new File(outBoundPath + File.separator + docTitle);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(file);
			fos.write(docData);
		} catch (FileNotFoundException e) {
			logger.error("File not found" + e);
		} catch (IOException ioe) {
			logger.error("Exception while writing file " + ioe);
		} finally {
			// close the streams using close method
			try {
				if (fos != null) {
					fos.close();
				}
			} catch (IOException ioe) {
				logger.error("Error while closing stream: " + ioe);
			}
		}
	}

	public List<FileSystemResource> getFilesToSFTP(String fileType) {
		File directoryPath = new File(outBoundPath);
		List<FileSystemResource> fileSystemResourcePath = new ArrayList<>();
		try {

			File[] files = directoryPath.listFiles(new FilenameFilter() {
				@Override
				public boolean accept(File dir, String name) {
					return (name.toLowerCase().contains(fileType.toLowerCase()));
				}
			});
			if(files != null) {
				for (File file : files) {
					if (!file.getName().isEmpty()) {
						fileSystemResourcePath.add(new FileSystemResource(file.getPath()));
					}
				}
			}
		} catch (Exception e) {
			logger.error("Error while getFilesToSFTP method " + e);
			e.printStackTrace();

		}
		return fileSystemResourcePath;
	}

}
