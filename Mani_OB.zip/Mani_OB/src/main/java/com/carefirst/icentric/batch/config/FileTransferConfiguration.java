/**
 * 
 */
package com.carefirst.icentric.batch.config;

import java.io.Serializable;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author aac8362
 *
 */
@Configuration
@ConfigurationProperties(prefix = "sftp")
public class FileTransferConfiguration implements Serializable {

	private static final long serialVersionUID = 1L;

	private String host;
	private int port;
	private String vaultQuery;
	private String outDirectory;

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public String getVaultQuery() {
		return vaultQuery;
	}

	public void setVaultQuery(String vaultQuery) {
		this.vaultQuery = vaultQuery;
	}

	public String getOutDirectory() {
		return outDirectory;
	}

	public void setOutDirectory(String outDirectory) {
		this.outDirectory = outDirectory;
	}



}
