package com.carefirst.icentric.batch.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.carefirst.icentric.batch.entity.PexMembGapsDtl;

public interface PexMembGapsDtlDAO extends JpaRepository<PexMembGapsDtl, Long>{ 

	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Query(value="SELECT  GAP.PEX_MEMB_GAPS_DTLS_SKEY, GAP.ADDL_INFO_HOST_PLN, GAP.AUD_INSRT_ID, GAP.AUD_INSRT_TMSTP, GAP.AUD_UPDT_ID, GAP.AUD_UPDT_TMSTP, GAP.CLS_GAP_INFO_RCVD, GAP.CLS_SF_DT, GAP.GAP_ID, GAP.GAP_IDTFN_RTNL, GAP.GAP_MEAS_CD, GAP.GAP_MEAS_TYP, GAP.HCC_CLM_CD, GAP.HCC_CLM_TYP, GAP.HM_PLN_GAP_CLS_INDC, GAP.HM_PLN_GAP_CLS_TYP, GAP.HST_PLN_GAP_CLS_INDC, GAP.HST_PLN_GAP_CLS_TYP, GAP.MIS_DIAG_CD, GAP.MIS_DIAG_CD_DESC, GAP.MIS_DIAG_CD_SRVC_DT, GAP.MIS_HCC_CD, GAP.MIS_HCC_CD_DESC, GAP.MIS_PROV_NPI_DIAG_CD, GAP.PROS_RET_IDNT_CD, GAP.PROS_RET_IDNT_TYP, GAP.REQTD_ACTN, GAP.RSK_ADJ_GAP_CD, GAP.RSK_ADJ_GAP_TYP, GAP.SCCF_ID, GAP.PEX_REQT_MEMB_QUEUE_SKEY"
				+" from PCMH_RSTR.PEX_REQT_MEMB_QUEUE MEMQ ,PCMH_RSTR.PEX_MEMB_GAPS_DTLS GAP WHERE MEMQ.PEX_REQT_MEMB_QUEUE_SKEY = GAP.PEX_REQT_MEMB_QUEUE_SKEY AND MEMQ.PROV_ENGMT_REQT_ID=?1 AND MEMQ.CPBLTY_INDC_CD=?2 ORDER BY GAP.GAP_ID", nativeQuery=true)
	List<PexMembGapsDtl> findGaps(String provEngmtReqtId, String cpbltyIndcCd);
	
	/*@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Query(value="SELECT * from PCMH_RSTR.PEX_REQT_MEMB_QUEUE MEMQ ,PCMH_RSTR.PEX_MEMB_GAPS_DTLS GAP WHERE MEMQ.PEX_REQT_MEMB_QUEUE_SKEY = GAP.PEX_REQT_MEMB_QUEUE_SKEY AND MEMQ.PROV_ENGMT_REQT_ID=?1 AND MEMQ.CPBLTY_INDC_CD='SC'", nativeQuery=true)
	List<PexMembGapsDtl> findGapsSc(String provEngmtReqtId);*/
}
