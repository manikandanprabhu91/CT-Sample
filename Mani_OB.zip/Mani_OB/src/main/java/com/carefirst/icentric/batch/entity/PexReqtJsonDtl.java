package com.carefirst.icentric.batch.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the PEX_REQT_JSON_DTLS database table.
 * 
 */
@Entity
@Table(name="PEX_REQT_JSON_DTLS")
@NamedQuery(name="PexReqtJsonDtl.findAll", query="SELECT p FROM PexReqtJsonDtl p")
public class PexReqtJsonDtl implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="PEX_REQT_JSON_DTLS_PEXREQTJSONDTLSSKEY_GENERATOR", sequenceName="PEX_REQT_JSON_DTLS_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="PEX_REQT_JSON_DTLS_PEXREQTJSONDTLSSKEY_GENERATOR")
	@Column(name="PEX_REQT_JSON_DTLS_SKEY")
	private long pexReqtJsonDtlsSkey;

	@Column(name="AUD_INSRT_ID")
	private String audInsrtId;

	@Column(name="AUD_INSRT_TMSTP")
	private Timestamp audInsrtTmstp;

	@Column(name="AUD_UPDT_ID")
	private String audUpdtId;

	@Column(name="AUD_UPDT_TMSTP")
	private Timestamp audUpdtTmstp;

	@Lob
	@Column(name="REQT_JSON")
	private String reqtJson;

	//bi-directional many-to-one association to PexReqtMembQueue
	@ManyToOne
	@JoinColumn(name="PEX_REQT_MEMB_QUEUE_SKEY")
	private PexReqtMembQueue pexReqtMembQueue;

	public PexReqtJsonDtl() {
	}

	public long getPexReqtJsonDtlsSkey() {
		return this.pexReqtJsonDtlsSkey;
	}

	public void setPexReqtJsonDtlsSkey(long pexReqtJsonDtlsSkey) {
		this.pexReqtJsonDtlsSkey = pexReqtJsonDtlsSkey;
	}

	public String getAudInsrtId() {
		return this.audInsrtId;
	}

	public void setAudInsrtId(String audInsrtId) {
		this.audInsrtId = audInsrtId;
	}

	public Timestamp getAudInsrtTmstp() {
		return this.audInsrtTmstp;
	}

	public void setAudInsrtTmstp(Timestamp audInsrtTmstp) {
		this.audInsrtTmstp = audInsrtTmstp;
	}

	public String getAudUpdtId() {
		return this.audUpdtId;
	}

	public void setAudUpdtId(String audUpdtId) {
		this.audUpdtId = audUpdtId;
	}

	public Timestamp getAudUpdtTmstp() {
		return this.audUpdtTmstp;
	}

	public void setAudUpdtTmstp(Timestamp audUpdtTmstp) {
		this.audUpdtTmstp = audUpdtTmstp;
	}

	public String getReqtJson() {
		return this.reqtJson;
	}

	public void setReqtJson(String reqtJson) {
		this.reqtJson = reqtJson;
	}

	public PexReqtMembQueue getPexReqtMembQueue() {
		return this.pexReqtMembQueue;
	}

	public void setPexReqtMembQueue(PexReqtMembQueue pexReqtMembQueue) {
		this.pexReqtMembQueue = pexReqtMembQueue;
	}

}