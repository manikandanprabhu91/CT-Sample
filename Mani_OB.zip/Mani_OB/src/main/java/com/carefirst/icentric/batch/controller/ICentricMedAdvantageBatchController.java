package com.carefirst.icentric.batch.controller;

import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carefirst.icentric.batch.config.MedicalRecordJobScheduler;
import com.carefirst.icentric.batch.config.RiskAdjustmentJobScheduler;
import com.carefirst.icentric.batch.config.StarCareJobScheduler;
import com.carefirst.icentric.batch.model.JobResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * This class is used to trigger the Outbound job.
 * @author aad7740
 *
 */

@Validated
@RestController
@Api(value = "JobTrigger")
public class ICentricMedAdvantageBatchController {
	
	private static final Logger LOGGER = LogManager.getLogger(ICentricMedAdvantageBatchController.class);

	@Autowired
	MedicalRecordJobScheduler medicalRecordJobScheduler;
	
	@Autowired
	StarCareJobScheduler starCareJobScheduler;
	
	@Autowired
	RiskAdjustmentJobScheduler riskAdjustmentJobScheduler;
	
	@GetMapping("/medadvantage/outbound/medicalRecord")
	@ApiOperation(value = "Trigger MedAdvantage MedicalRecord Job", notes = "API to trigger medicalRecord job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> medicalRecordTriggerJobFromWeb(@RequestParam(name="ftpIndicator") String ftpIndicator) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger medicalRecord job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (medicalRecordJobScheduler.triggerJobFromWeb(ftpIndicator)) {
					LOGGER.info("Got MedicalRecord Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger medicalRecord job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger medicalRecord = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger medicalRecord job");
		}
		return responseEntity;
	}
	
	
	@GetMapping("/medadvantage/outbound/starcare")
	@ApiOperation(value = "Trigger starcare Job", notes = "API to trigger Starcare job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> starcare(@RequestParam(name="ftpIndicator") String ftpIndicator) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger starcare job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (starCareJobScheduler.triggerJobFromWeb(ftpIndicator)) {
					LOGGER.info("Got StarCare Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger starcare job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger starcare = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger starcare job");
		}
		return responseEntity;
	}
	
	
	
	@GetMapping("/medadvantage/outbound/riskAdjustment")
	@ApiOperation(value = "Trigger MedAdvantage RiskAdjustment Job", notes = "API to trigger RiskAdjustment job on adhoc basis", response = ResponseEntity.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Successful Request"),
			@ApiResponse(code = 400, message = "Invalid Request parameters"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	public ResponseEntity<Object> riskAdjustmentTriggerJobFromWeb(@RequestParam(name="ftpIndicator") String ftpIndicator) {
		if (LOGGER.isInfoEnabled()) {
			LOGGER.info("> trigger riskAdjustmentTriggerJobFromWeb job");
		}

		ResponseEntity<Object> responseEntity = null;
		long startTime = System.currentTimeMillis();
		try {
			if (riskAdjustmentJobScheduler.triggerJobFromWeb(ftpIndicator)) {
					LOGGER.info("Got RiskAdjustment Response Succesfully");
					JobResponse response = new JobResponse();
					response.setJobTriggerDate(new Date());
					responseEntity = new ResponseEntity<>(response,HttpStatus.OK);
				}
		} catch (Exception e) {
			LOGGER.error("Exception has occurred in trigger riskAdjustment job" + e.getMessage(), e);
			responseEntity = new ResponseEntity<>("Error Occured Triggering The Job", HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			long responseTime = System.currentTimeMillis() - startTime;
			LOGGER.info("Time taken to trigger riskAdjustment = " + responseTime + " milli seconds");
		}
		if (LOGGER.isInfoEnabled())

		{
			LOGGER.info("< trigger riskAdjustment job");
		}
		return responseEntity;
	}	
	
	
}
