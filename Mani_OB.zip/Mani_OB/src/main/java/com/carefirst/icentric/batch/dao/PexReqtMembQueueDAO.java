package com.carefirst.icentric.batch.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carefirst.icentric.batch.entity.PexReqtMembQueue;

public interface PexReqtMembQueueDAO extends JpaRepository<PexReqtMembQueue, Long>{

	@Query(value="select count(p.cpblty_indc_cd) FROM PCMH_RSTR.pex_reqt_memb_queue p where p.cpblty_indc_cd=?1",nativeQuery=true)
	int findCountofRecords(String capabilityCd);
	
	@Query(value="SELECT p FROM PexReqtMembQueue p WHERE p.cpbltyIndcCd = :capabilityCd AND p.reqtStusCd NOT IN :reqtStusCd")
	public List<PexReqtMembQueue> getPexReqtMembQueueRecordsBasedonStatus(@Param("capabilityCd") String  capabilityCd, 
			@Param("reqtStusCd") String reqtStusCd);
	
	@Query(value="SELECT REFNC_LKUP_CD FROM cp_ph2.refnc_data_lkup WHERE REFNC_LKUP_TYP = 'RSK_ADJ_GAP_TYP' AND REFNC_LKUP_CD=?1",nativeQuery=true)
	String findRiskAdjGapTypCd(String rskAdjGapCd);
	
	
}
