package com.carefirst.icentric.batch.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carefirst.icentric.batch.entity.PexReqtJsonDtl;

public interface PexReqtJsonDtlDAO extends JpaRepository<PexReqtJsonDtl, Long>{

}
