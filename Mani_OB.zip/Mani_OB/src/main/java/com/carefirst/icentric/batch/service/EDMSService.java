package com.carefirst.icentric.batch.service;

import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocResponse;
import com.carefirst.icentric.batch.exception.ApplicationException;

public interface EDMSService {
	
	public GetDocResponse downloadFile(String filenetId) throws ApplicationException;
}
