package com.carefirst.icentric.batch.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.carefirst.icentric.batch.entity.FileAtchDtl;

@Repository
public interface FileAtchDtlDAO  extends JpaRepository<FileAtchDtl, Long>{
	
	@Query(value="SELECT * FROM PCMH_RSTR.FILE_ATCH_DTLS WHERE ATCH_ASSCD_ENT_QLFR='PEX_REQT_MEMB_QUEUE_SKEY' AND ATCH_ASSCD_ENT_SKEY=?1 AND REFNC_FILE_TYP_CD='OUTBD' AND NVL(REFNC_ATCH_STUS_CD,'N')!='D'",nativeQuery=true)
	List <FileAtchDtl> findFilesToDownload(Long atchAsscdEntQlfr);		
	

}
