
package com.carefirst.icentric.batch.riskAdjustment.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@JsonPropertyOrder({
    "RiskAdjustmentGapReq"
})
public class RiskAdjustmentGapResponseObj {

    @JsonProperty("RiskAdjustmentGapReq")
    private List<RiskAdjustmentGapReq> riskAdjustmentGapReq = null;

    /**
     * No args constructor for use in serialization
     * 
     */
    public RiskAdjustmentGapResponseObj() {
    }

    /**
     * 
     * @param riskAdjustmentGapReq
     */
    public RiskAdjustmentGapResponseObj(List<RiskAdjustmentGapReq> riskAdjustmentGapReq) {
        super();
        this.riskAdjustmentGapReq = riskAdjustmentGapReq;
    }

    @JsonProperty("RiskAdjustmentGapReq")
    public List<RiskAdjustmentGapReq> getRiskAdjustmentGapReq() {
        return riskAdjustmentGapReq;
    }

    @JsonProperty("RiskAdjustmentGapReq")
    public void setRiskAdjustmentGapReq(List<RiskAdjustmentGapReq> riskAdjustmentGapReq) {
        this.riskAdjustmentGapReq = riskAdjustmentGapReq;
    }

}
