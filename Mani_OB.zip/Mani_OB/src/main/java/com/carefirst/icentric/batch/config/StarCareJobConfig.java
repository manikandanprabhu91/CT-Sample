/**
 * 
 */
package com.carefirst.icentric.batch.config;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.starcare.tasklet.SCJobCompletionListener;
import com.carefirst.icentric.batch.starcare.tasklet.StarCareItemWriterTasklet;

/**
 * @author aab0490
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class StarCareJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(StarCareJobConfig.class);
	
	@Autowired
	private JobBuilderFactory starCareJobBuilderfactory;

	@Autowired
	private StepBuilderFactory starCareStepBuilderfactory;

	@Bean
	public Job starcareBatchJob() throws ApplicationException {
		return starCareJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB StarCare").incrementer(new RunIdIncrementer())
				.start(readStarCareWritter()).listener(jobcompletionListener()).build();
	}

	@Bean
	public JobExecutionListener jobcompletionListener() {
		return new SCJobCompletionListener();
	}
	@Bean
	public Step readStarCareWritter() {
		LOGGER.info("readData - step1() start/end");
		return starCareStepBuilderfactory.get("step1").tasklet(starCareItemTasklet()).build();
	}
	
	@Bean
	public StarCareItemWriterTasklet starCareItemTasklet() {
		StarCareItemWriterTasklet tasklet = new StarCareItemWriterTasklet();
		return tasklet;
	}


}
