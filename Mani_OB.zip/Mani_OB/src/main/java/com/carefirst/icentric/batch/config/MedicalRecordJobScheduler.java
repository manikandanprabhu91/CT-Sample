package com.carefirst.icentric.batch.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.slf4j.MDC;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.utils.FileUtils;

/**
 * @author aaa6364
 *
 */
@Component
public class MedicalRecordJobScheduler implements SchedulingConfigurer {
	private static final Logger LOGGER = LogManager.getLogger(MedicalRecordJobScheduler.class);

	private final int POOL_SIZE = 10;

	@Autowired
	private JobLauncher jobLauncherMR;
	
	@Autowired
	private MedicalRecordJobConfig mrJobConfig;
	
	@Autowired
	private JobExplorer mrJobExplorer;

	private String ftpIndicator = null;

	/**
	 * This method is used to register the scheduled tasks
	 * 
	 * @param scheduledTaskRegistrar
	 */
	@Override
	public void configureTasks(ScheduledTaskRegistrar scheduledTaskRegistrar) {
		LOGGER.info("> configureTasks");
		ThreadPoolTaskScheduler threadPoolTaskScheduler = new ThreadPoolTaskScheduler();
		threadPoolTaskScheduler.setPoolSize(POOL_SIZE);
		threadPoolTaskScheduler.setThreadNamePrefix("my-scheduled-task-pool-");
		threadPoolTaskScheduler.initialize();

		scheduledTaskRegistrar.setTaskScheduler(threadPoolTaskScheduler);
		LOGGER.info("Current Thread : {}", Thread.currentThread().getName());
		LOGGER.info("< configureTasks");

	}


	/**
	 * This method is used to schedule the Starcare batch Job
	 * 
	 */
	@Scheduled(cron = "${medvantage.outbound.batch.mr.cron}")
	public void mrScheduler() {
			// set transaction ID for daily job run
			String transactionId = UUID.randomUUID().toString();
			MDC.put("transactionId", "MedicalRecord: " + transactionId);
			LOGGER.info("> MedicalRecord batchJob");
			Map<String, JobParameter> jobParamMap = new HashMap<>();
			jobParamMap.put("time", new JobParameter(System.currentTimeMillis()));
			jobParamMap.put("ftpIndicator", new JobParameter(ftpIndicator));
			JobParameters jobParams = new JobParameters(jobParamMap);
			try {
				while (true) {
					Set<org.springframework.batch.core.JobExecution> jobExecutions = mrJobExplorer
							.findRunningJobExecutions(mrJobConfig.medicalRecordBatchJob().getName());
					boolean runFilejob = !jobExecutions.isEmpty();
					if (runFilejob) {
						LOGGER.info("Job is already running waiting to restart");
						Thread.sleep(30000);
					} else {
						LOGGER.info("Starting the job");
						break;
					}
				}
//				archiveMRFiles();
				// Job is triggered to execute the tasks
				jobLauncherMR.run(mrJobConfig.medicalRecordBatchJob(), jobParams);
				this.ftpIndicator = null;
				LOGGER.info("< MedicalRecord batchJob");
			} catch (JobExecutionAlreadyRunningException | JobInstanceAlreadyCompleteException
					| JobParametersInvalidException | org.springframework.batch.core.repository.JobRestartException
					| InterruptedException | ApplicationException e) {
				LOGGER.error("Exception Occued Job :" + e.getMessage(), e);
			} catch (Exception e) {
				LOGGER.error("Exception Occued ::::: " + e.getMessage(), e);
				e.printStackTrace();
			}
			MDC.clear();
			MDC.remove("transactionId");
	}

	@Autowired
	FileUtils fileUtils;
	
//	private void archiveMRFiles() throws Exception {
//		LOGGER.info(":::::::::::archiveMRFiles start>>>>> :::::::::::::: ");
//		try {
//			fileUtils.archiveOldOutboundFiles("MR");
//		} catch (IOException e) {
//			LOGGER.error("Exception Occued while archiving files:" + e.getMessage(), e);
//		}
//	}

	public boolean triggerJobFromWeb(String ftpIndicator) throws Exception {
		LOGGER.info("> triggerJobFromWeb");
		Set<org.springframework.batch.core.JobExecution> jobExecutions = mrJobExplorer
				.findRunningJobExecutions(mrJobConfig.medicalRecordBatchJob().getName());
		boolean runFilejob = !jobExecutions.isEmpty();
		this.ftpIndicator = ftpIndicator;
		if (runFilejob) {
			LOGGER.info("< triggerJobFromWeb");
			throw new Exception("JOB is running. Please try again later");
		} else {
			ExecutorService executor = Executors.newSingleThreadExecutor();
			executor.execute(() -> {
				mrScheduler();
				LOGGER.info("< triggerJobFromWeb");
			});
		}
		return true;
	}

}
