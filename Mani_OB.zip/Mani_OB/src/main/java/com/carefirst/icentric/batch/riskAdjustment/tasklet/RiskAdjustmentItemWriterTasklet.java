package com.carefirst.icentric.batch.riskAdjustment.tasklet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import com.carefirst.broker.compensation.edms.gen.getdoc.GetDocResponse;
import com.carefirst.icentric.batch.constant.ApplicationConstants;
import com.carefirst.icentric.batch.dao.FileAtchDtlDAO;
import com.carefirst.icentric.batch.dao.PexMembGapsDtlDAO;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.entity.FileAtchDtl;
import com.carefirst.icentric.batch.entity.PexMembGapsDtl;
import com.carefirst.icentric.batch.entity.PexReqtMembQueue;
import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.riskAdjustment.model.LastMedRecReqServRangeDts;
import com.carefirst.icentric.batch.riskAdjustment.model.MemberPCP5PartKey;
import com.carefirst.icentric.batch.riskAdjustment.model.RiskAdjGap;
import com.carefirst.icentric.batch.riskAdjustment.model.RiskAdjustmentGapReq;
import com.carefirst.icentric.batch.riskAdjustment.model.RiskAdjustmentGapResponseObj;
import com.carefirst.icentric.batch.service.EDMSService;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class is used to generate RiskAdjustment json file
 * @author aad7740
 *
 */
public class RiskAdjustmentItemWriterTasklet  implements Tasklet, StepExecutionListener {

	private static final Logger LOGGER = LogManager.getLogger(RiskAdjustmentItemWriterTasklet.class);

	@Autowired
	PexReqtMembQueueDAO pexReqtMembQueueDAO;

	@Autowired
	FileAtchDtlDAO fileAttchDao;

	@Autowired
	EDMSService edmsService;

	@Autowired
	PexMembGapsDtlDAO pexMembGapsDtldao;

	@Autowired
	FileUtils fileUtils;


	@Override
	public void beforeStep(StepExecution stepExecution) {
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		return ExitStatus.COMPLETED;
	}

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		LOGGER.info(":::RiskAdjustmentItemWriterTasklet -> execute method -> start ::::::::::");
		try {
			List<PexReqtMembQueue> membQueues = pexReqtMembQueueDAO.getPexReqtMembQueueRecordsBasedonStatus(ApplicationConstants.RA, ApplicationConstants.CLOSED_STATUS);
			List<RiskAdjustmentGapReq> raGapReqList = new ArrayList<>();
			RiskAdjustmentGapResponseObj raGapResponseObj = new RiskAdjustmentGapResponseObj();
			Map<Long, String> engmentIdMap = new HashMap<>();
			if(!membQueues.isEmpty()) {
				for(PexReqtMembQueue item : membQueues) {
					RiskAdjustmentGapReq raGapReq = new RiskAdjustmentGapReq();
					raGapReq.setProvEngmntReqId(fileUtils.getValue(item.getProvEngmtReqtId()));
					raGapReq.setCapabilityInd(fileUtils.getValue(item.getCpbltyIndcCd()));
					raGapReq.setHomePlanId(fileUtils.getValue(item.getHmPlanId()));
					raGapReq.setMemberHostPlanId(fileUtils.getValue(item.getMembHstPlnId()));
					raGapReq.setRoutetoHostPlanId(fileUtils.getValue(item.getRoutHstPlnId()));
					raGapReq.setFirstTimeSenttoHostPlanDt(fileUtils.getValue(item.getIntlHstPlnDt()));
					raGapReq.setLastMRRProvEngmntReqID(fileUtils.getValue(item.getLastMrrProvEngmtRetId()));
					raGapReq.setLastMedRecReqRcptDt(fileUtils.getValue(item.getLastMedRecReqtDt()));

					LastMedRecReqServRangeDts lastMedRecReqServRangeDts = new LastMedRecReqServRangeDts();
					lastMedRecReqServRangeDts
					.setLastMedRecReqServBeginDt(fileUtils.getValue(item.getLastMedRecReqtBegDt()));
					lastMedRecReqServRangeDts.setLastMedRecReqServEndDt(fileUtils.getValue(item.getLastMedRecReqtEndDt()));
					raGapReq.setLastMedRecReqServRangeDts(lastMedRecReqServRangeDts);

					raGapReq.setITSSubscriberId(fileUtils.getValue(item.getItsSubscrId()));
					raGapReq.setMemberDOB(fileUtils.getValue(item.getMembDob()));
					raGapReq.setMMIId(fileUtils.getValue(item.getMmiId()));
					raGapReq.setMemberFullName(fileUtils.getValue(item.getMembFullNm()));
					raGapReq.setMemberGender(fileUtils.getValue(item.getMembGndr()));
					raGapReq.setNumofGapClosures(item.getCloseGapCnt() != null ? item.getCloseGapCnt().intValue() : 0);
					raGapReq.setBillProvProprietaryId(fileUtils.getValue(item.getBillProvId()));
					raGapReq.setRndrngProvProprietaryId(fileUtils.getValue(item.getRndrProvId()));
					raGapReq.setBillProvNPI(fileUtils.getValue(item.getBillProvNpi()));
					raGapReq.setRndrngProvNPI(fileUtils.getValue(item.getRndrProvNpi()));
					raGapReq.setRndrngProvHostPlanId(fileUtils.getValue(item.getRndrProvHstPlnId()));
					raGapReq.setBillProvZipCode(fileUtils.getValue(item.getBillProvZipCd()));
					raGapReq.setRndrngProvZipCode(fileUtils.getValue(item.getRndrProvZipCd()));
					raGapReq.setRndrngProvTxnmyCd(fileUtils.getValue(item.getRndrProvTnxmyCd()));
					raGapReq.setSCCFIds(fileUtils.getValue(item.getSccfId()));
					raGapReq.setRndrngProvTaxId(fileUtils.getValue(item.getRndrProvTaxId()));
					raGapReq.setRndrngProvAddlInfo(fileUtils.getValue(item.getAddnlInfo()));

					MemberPCP5PartKey memberPCP5PartKey = new MemberPCP5PartKey();
					memberPCP5PartKey.setProvPlanCd(fileUtils.getValue(item.getProvPlnCd()));
					memberPCP5PartKey.setProductCd(fileUtils.getValue(item.getProvProdCd()));
					memberPCP5PartKey.setProvNum(fileUtils.getValue(item.getProvNum()));
					memberPCP5PartKey.setProvNumSuffix(fileUtils.getValue(item.getProvSufx()));
					memberPCP5PartKey.setProvNetwrkLocSeqNum(fileUtils.getValue(item.getProvNtwrkLoc()));
					raGapReq.setMemberPCP5PartKey(memberPCP5PartKey);
					raGapReq.setPresentDiagnoses(fileUtils.getValue(item.getPrsntDiag()));
					raGapReq.setCurrentDiagnosesRndrngProvNPI(fileUtils.getValue(item.getRndrProvCurrDiag()) != null?item.getRndrProvCurrDiag() : "");
					raGapReq.setProvEngagementInd(fileUtils.getValue(item.getProvEngmtIndc()));
					raGapReq.setProvCntrctingSts(fileUtils.getValue(item.getProvPartStus()));
					List<RiskAdjGap> riskAdjGapsList = new ArrayList<>();
					List<PexMembGapsDtl> gapsDtls = pexMembGapsDtldao.findGaps(item.getProvEngmtReqtId(), item.getCpbltyIndcCd());
					for(PexMembGapsDtl membGap: gapsDtls) {
						RiskAdjGap ragap = new RiskAdjGap();
						if (membGap != null) {
							ragap.setGapId(membGap.getGapId() != null ? membGap.getGapId().intValue() : 0);
							ragap.setRiskAdjGapType(fileUtils.getValue(pexReqtMembQueueDAO.findRiskAdjGapTypCd(fileUtils.getValue(membGap.getRskAdjGapCd()))));
							ragap.setMissingDiagCd(fileUtils.getValue(membGap.getMisDiagCd()));
							ragap.setMissingDiagCdDesc(fileUtils.getValue(membGap.getMisDiagCdDesc()));
							ragap.setMissingHCCCd(fileUtils.getValue(membGap.getMisHccCd()));
							ragap.setMissingHCCCdDesc(fileUtils.getValue(membGap.getMisHccCdDesc()));
							ragap.setHCCClaimType(fileUtils.getValue(membGap.getHccClmCd()));
							ragap.setMissingDiagCdServDt(fileUtils.getValue(membGap.getMisDiagCdSrvcDt()));
							ragap.setMissingDiagCdProvNPI(fileUtils.getValue(membGap.getMisProvNpiDiagCd()));
							ragap.setGapIdentificationRationale(fileUtils.getValue(membGap.getGapIdtfnRtnl()));
							ragap.setProspRetrospId(fileUtils.getValue(membGap.getProsRetIdntCd()));
							ragap.setRequestedAction(fileUtils.getValue(membGap.getReqtdActn()));
							ragap.setHomePlanGaplvlClsrInd(fileUtils.getValue(membGap.getHmPlnGapClsIndc()));
							ragap.setInfoRcvdtocloseGap(fileUtils.getValue(membGap.getClsGapInfoRcvd()));
							ragap.setGapClsrSCCFId(fileUtils.getValue(membGap.getSccfId()));
							ragap.setClsrSFReceiptDt(fileUtils.getValue(membGap.getClsSfDt()));
							ragap.setHostPlanGaplvlClsrInd(fileUtils.getValue(membGap.getHstPlnGapClsIndc()));
							engmentIdMap.put(item.getPexReqtMembQueueSkey(),item.getProvEngmtReqtId());
							riskAdjGapsList.add(ragap);
						}
					}
					riskAdjGapsList.sort((RiskAdjGap s1, RiskAdjGap s2)->s1.getGapId()-s2.getGapId());
					raGapReq.setRiskAdjGaps(riskAdjGapsList);
					raGapReqList.add(raGapReq);
				}

				raGapResponseObj.setRiskAdjustmentGapReq(raGapReqList);
				ObjectMapper mapper = new ObjectMapper();
				String raJsonString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(raGapResponseObj);
				LOGGER.info("ra response JSON object: " + raJsonString);

				// Write the response JSON into file.
				StringBuilder buffer = new StringBuilder();
				buffer.append(raJsonString);
				fileUtils.writeToDatafile(buffer,  ApplicationConstants.RA);
				for (Map.Entry<Long, String> entry : engmentIdMap.entrySet()) {
					downloadFiles(entry.getKey(), entry.getValue());
				}

			} else {
				fileUtils.writeToZeroByteFile( ApplicationConstants.RA);
			}
		} catch (Exception e) {
			LOGGER.error("Error Occuring RiskAdjustmentItemWriterTasklet -> execute method:::: "+e.getMessage());
		}
		LOGGER.info(":::RiskAdjustmentItemWriterTasklet -> execute method -> End ::::::::::");
		return RepeatStatus.FINISHED;
	}
	private void downloadFiles(long pexReqtMembQueueSkey, String getProvEngmtReqtId ) {
		List<String> downloadedfiles = new ArrayList<>();
		List<FileAtchDtl> filesToDownload = fileAttchDao.findFilesToDownload(pexReqtMembQueueSkey);

		if(!filesToDownload.isEmpty()){
			for(FileAtchDtl fileDtl:filesToDownload){
				try {
					if(filesToDownload.size()>1){
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}else{
						GetDocResponse fileResp = edmsService.downloadFile(fileDtl.getAtchFilenetId());
						fileUtils.saveFileNetFile(getProvEngmtReqtId+"_"+fileResp.getDocTitle(),fileResp.getDocData());
						downloadedfiles.add(fileDtl.getAtchNm());
					}
				} catch (ApplicationException e) {
					LOGGER.error(ExceptionUtils.getStackTrace(e));
				}
			}

			fileUtils.compressFiles(downloadedfiles, getProvEngmtReqtId);
			fileUtils.deleteFiles(downloadedfiles);
		}
	}

}
