/**
 * 
 */
package com.carefirst.icentric.batch.config;


import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.carefirst.icentric.batch.exception.ApplicationException;
import com.carefirst.icentric.batch.medicalRecord.tasklet.MRJobCompletionListener;
import com.carefirst.icentric.batch.medicalRecord.tasklet.MedicalRecordItemWriterTasklet;

/**
 * @author aab0490
 *
 */
@Configuration
@EnableBatchProcessing
@ComponentScan(basePackageClasses = BatchConfigurer.class)
public class MedicalRecordJobConfig {
	private static final Logger LOGGER = LogManager.getLogger(MedicalRecordJobConfig.class);
	@Autowired
	private JobBuilderFactory mrJobBuilderfactory;

	@Autowired
	private StepBuilderFactory mrStepBuilderfactory;

	@Bean
	public Job medicalRecordBatchJob() throws ApplicationException {
		return mrJobBuilderfactory.get("MEDVANTAGE_PROCESS-JOB medicalRecord").incrementer(new RunIdIncrementer())
				.start(medRecWritter()).listener(mrJobCompletionListener()).build();
	}

	@Bean
	public JobExecutionListener mrJobCompletionListener() {
		return new MRJobCompletionListener();
	}

	@Bean
	public Step medRecWritter() {
		LOGGER.info("readData - step1() start/end");
		return mrStepBuilderfactory.get("step1").tasklet(medRecItemTasklet()).build();
	}
	
	@Bean
	public MedicalRecordItemWriterTasklet medRecItemTasklet() {
		MedicalRecordItemWriterTasklet tasklet = new MedicalRecordItemWriterTasklet();
		return tasklet;
	}


}
