package com.carefirst.icentric.batch.riskAdjustment.tasklet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.carefirst.icentric.batch.config.FileTransferConfiguration;
import com.carefirst.icentric.batch.constant.ApplicationConstants;
import com.carefirst.icentric.batch.dao.PexReqtMembQueueDAO;
import com.carefirst.icentric.batch.service.FileTransferService;
import com.carefirst.icentric.batch.utils.FileUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.Session;

@Component
public class RAJobCompletionListener extends JobExecutionListenerSupport {
	private static final Logger LOGGER = LogManager.getLogger(RAJobCompletionListener.class);

	@Value("${medvantage.outbound.path}")
	String out;

	@Autowired
	FileTransferService filetransfer;

	@Autowired
	FileTransferConfiguration configFileTransferConfiguration;

	@Autowired
	FileUtils fileUtils;

	@Autowired
	PexReqtMembQueueDAO memQueueDao;

	@Override
	public void afterJob(JobExecution jobExecution) {
		String ftpIndicator = jobExecution.getJobParameters().getString("ftpIndicator");
		String completionContent = "The job " + jobExecution.getJobInstance().getJobName();

		try {
			completionContent =completionContent + " with files "+  jobExecution.getJobParameters().getString("fileList") + "executed sucesssfully";
			int count = memQueueDao.findCountofRecords(ApplicationConstants.RA);
			if(count==0){
				fileUtils.writeToZeroByteFile(ApplicationConstants.RA);
			}

			if(ftpIndicator == null || ftpIndicator == "") {
				sftpFiles(fileUtils.getFilesToSFTP("RA"));
			}

		} catch (Exception e) {
			LOGGER.error(e);
		}

		LOGGER.info(completionContent);
	}

	private void sftpFiles(List<FileSystemResource> list) {

		Channel channel = null;
		ChannelSftp channelSftp = null;
		Session session = null;
		try {

			session = filetransfer.ftpServerConnection();
			channel = session.openChannel("sftp");
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			for(FileSystemResource item:list){
				byte[] payload = readBytesFromFile(out+File.separator+item.getFilename());
				if (null != payload) {
					boolean isTransferFile = filetransfer.transferFile(payload, configFileTransferConfiguration.getOutDirectory(), item.getFilename(), channel, channelSftp);
					if(isTransferFile) {
						fileUtils.archiveOldOutboundFiles("RA", item.getFilename());
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("::::::::::Error Occuring sftp failed Exception::::::::::::::"+e.getMessage());
		} finally {
			if(null!=channelSftp){
				channelSftp.exit();
			}
			LOGGER.info("sftp Channel exited.");
			if(null!=channel){
				channel.disconnect();
			}
			LOGGER.info("Channel disconnected.");
			if(null!=session){
				session.disconnect();
			}
			LOGGER.info("Host Session disconnected.");
		}

	}

	private static byte[] readBytesFromFile(String filePath) {

		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;

		try {

			File file = new File(filePath);
			bytesArray = new byte[(int) file.length()];

			//read file into bytes[]
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;
	}

}
